# Author: James Saludes, Guan-Hsin Wang(inspector),  Zijian Yue(inspector)
# Date: 2/4/2022

#import flask and support modules
from flask import Flask
from flask_cors import CORS


# import the DB interface
import os
import sys
# get current folder
cwd = os.getcwd()
sys.path.append(os.path.dirname(cwd + '/../database'))
from database.DatabaseManager import DataBaseManager


# create flask app
DbController = None
def create_app():

    app = Flask(__name__)
    cors = CORS(app, resources={r"/api": {"origins": "*"}})
    app.config['CORS_HEADERS'] = 'Content-Type'

    with app.app_context():
        # init the Databasemanager
        DbController = DataBaseManager()
    return app
app = create_app()


# import blueprints into routes.py
from blueprints import logreg, book, search, user_details, user_collections, recommend, admin, forum

# register and login
app.register_blueprint(logreg.router, url_prefix="/api")

# books 
app.register_blueprint(book.router, url_prefix="/api")

# search
app.register_blueprint(search.router, url_prefix="/api")

# user_details
app.register_blueprint(user_details.router, url_prefix="/api")

# user collections
app.register_blueprint(user_collections.router, url_prefix="/api")

# books recommendation
app.register_blueprint(recommend.router, url_prefix="/api")

# general information and management for the admin
app.register_blueprint(admin.router, url_prefix="/api")

# forum for discussion
app.register_blueprint(forum.router, url_prefix="/api")

if __name__ == "__main__":
    app.run(debug=True)