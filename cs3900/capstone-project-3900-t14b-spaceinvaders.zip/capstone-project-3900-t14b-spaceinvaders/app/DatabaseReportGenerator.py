# Author: Zijian Yue
# Date: 2/4/2022



# import the DB interface
import os
import sys
# get current folder
cwd = os.getcwd()
sys.path.append(os.path.dirname(cwd + '/../database'))
from database.DatabaseManager import DataBaseManager

import csv
DbContoller = DataBaseManager()


# dump everything in the DB to individual csv files
def dump_csv():
    # export users to csv
    with open('./report/users.csv', 'w', encoding='UTF8') as f:
        # create the csv writer
        writer = csv.writer(f)

        # write a row to the csv file
        writer.writerow(["UID", "ROLE", "PASSWORD", "USERNAME", "BIRTHDAY", "SELF_INTRODUCTION", "EMAIL", "PICTURE", "STATUS", "ADDED_TIME"])

        tupes = DbContoller.general_return_a_table("USERS")

        for item in tupes:
            writer.writerow(list(item))
        pass
    # export books to csv
    with open('./report/books.csv', 'w', encoding='UTF8') as f:
        # create the csv writer
        writer = csv.writer(f)

        # write a row to the csv file
        writer.writerow(["BID", "BOOKNAME", "AUTHOR", "YEAR", "COUNTRY", "PUBLISHERS", "SUMMARY", "RATING", "PICTURE", "TAGS", "ADDED_TIME"])

        tupes = DbContoller.general_return_a_table("BOOKS")

        for item in tupes:
            writer.writerow(list(item))
        pass
    # export collections to csv
    with open('./report/collections.csv', 'w', encoding='UTF8') as f:
        # create the csv writer
        writer = csv.writer(f)

        # write a row to the csv file
        writer.writerow(["CID", "COLLECTION_NAME", "PICTURE", "COMMENTS", "TIME_CREATED", "TAGS"])

        tupes = DbContoller.general_return_a_table("COLLECTIONS")

        for item in tupes:
            writer.writerow(list(item))
        pass
    # export collections to csv
    with open('./report/read.csv', 'w', encoding='UTF8') as f:
        # create the csv writer
        writer = csv.writer(f)

        # write a row to the csv file
        writer.writerow(["UID", "BID", "COMMENT", "RATING", "LAST_TIME_READ", "TOTAL_READING_TIME"])

        tupes = DbContoller.general_return_a_table("READ")

        for item in tupes:
            writer.writerow(list(item))
        pass
    # export collections to csv
    with open('./report/include.csv', 'w', encoding='UTF8') as f:
        # create the csv writer
        writer = csv.writer(f)

        # write a row to the csv file
        writer.writerow(["CID", "BID", "ADDED_TIME"])

        tupes = DbContoller.general_return_a_table("INCLUDE")

        for item in tupes:
            writer.writerow(list(item))
        pass
    # export collections to csv
    with open('./report/own.csv', 'w', encoding='UTF8') as f:
        # create the csv writer
        writer = csv.writer(f)

        # write a row to the csv file
        writer.writerow(["CID", "BID"])

        tupes = DbContoller.general_return_a_table("OWN")

        for item in tupes:
            writer.writerow(list(item))
        pass
     # export collections to csv
    with open('./report/report.csv', 'w', encoding='UTF8') as f:
        # create the csv writer
        writer = csv.writer(f)

        # write a row to the csv file
        writer.writerow(["RID", "REPORTING_UID", "REPORTED_UID", "REASON", "REPORTING_TIME", "ADMIN_MESSAGE", "REPORTED_BID"])

        tupes = DbContoller.general_return_a_table("REPORT")

        for item in tupes:
            writer.writerow(list(item))
        pass

    print("Csv files has been created successfully....")
    pass



dump_csv()






