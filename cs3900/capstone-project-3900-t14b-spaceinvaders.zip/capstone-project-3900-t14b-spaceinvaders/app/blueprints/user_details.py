# Author: Alex Piotrowski, James Saludes, Guan-Hsun Wang
# Date: 2/4/2022

# import flask and support modoles
from flask import request
from flask import Blueprint

from flask_cors import cross_origin
from json import dumps
import hashlib


# import the DB interface
import os
import sys
# get current folder
cwd = os.getcwd()
sys.path.append(os.path.dirname(cwd + '/../../database'))
from database.DatabaseManager import DataBaseManager


# name the logreg.py in Blueprint
router = Blueprint("user_details", __name__)
DbController = DataBaseManager()


# method = post
@router.route('/getSelfIntro', methods = ['POST', 'GET'])
@cross_origin()
def getSelfIntroByUserId():
    if request.method == 'POST':
    # retrive an user's information by user's id
        args = request.get_json()
        userId = str(args.get('userId'))

        if DbController.general_search("USERS", "UID", userId) is None:
            return dumps({"error": "User not found"})

    selfIntro = DbController.general_search("USERS", "UID", userId)[5]
    if selfIntro == "":
        selfIntro = "Self introduction field of the user table has not been set"
    elif selfIntro == "None":
        selfIntro = "This is None"
    return dumps({'error': "None", 'selfIntro': selfIntro})


#  method = post
@router.route('/setSelfIntro', methods = ['POST', 'GET'])
@cross_origin()
def setSelfIntro():
    # set the profile for an user
    if request.method == 'POST':
        args = request.get_json()
        userId = str(args.get('userId'))
        userSelfIntro = str(args.get('userSelfIntro'))

        DbController.user_update_user_table(userId, "SELF_INTRODUCTION", userSelfIntro)

        return dumps({"error": "None", "SELF_INTRODUCTION": userSelfIntro})
    return "Unexpected result"


# method = post
@router.route('/setImage', methods = ['POST', 'GET'])
@cross_origin()
def setImage():
    # set a image for an user
    if request.method == 'POST':
        args = request.get_json()
        userId = str(args.get('userId'))
        user_image = str(args.get('user_image'))

        DbController.user_update_user_table(userId, "PICTURE", user_image)

        return dumps({"error": "None", "user_image": user_image})
    return "Unexpected result"


# method = post
@router.route('/passwordChange', methods = ['POST', 'GET'])
@cross_origin()
def passwordChange():
    # change the password of a user
    if request.method == 'POST':
        args = request.get_json()
        userId = str(args.get('userId'))
        newPassword = str(args.get('newPassword'))

        # At this point, the user should already be logged in. no need to check if the user is in the database.
        DbController.user_update_user_table(userId, "PASSWORD", hashlib.sha256(newPassword.encode()).hexdigest())

        return dumps({"error": "None"})
    return "Unexpected result"


# Get request
@router.route('/set_birthday', methods = ['POST', 'GET'])
@cross_origin()
def set_birthday():
    if request.method == 'POST':
        args = request.get_json()

        userId = str(args.get('userId'))
        newBirthday = str(args.get('user_birthday'))

        # At this point, the user should already be logged in. no need to check if the user is in the database.
        DbController.user_update_user_table(userId, "BIRTHDAY", newBirthday)

        return dumps({"error": "None"})
    return "Unexpected result"


# Get request
@router.route('/user/get_goal', methods = ['GET'])
@cross_origin()
def get_goal():
    if request.method == 'GET':
        # retrieve useful information from the online form
        username = str(request.args.get('username'))

    # if the username does not exist in the database return error message
    if DbController.general_search("USERS", "USERNAME", username) is None:
        return dumps({"error": "Username does not exist"})

    goal = DbController.general_search("USERS", "USERNAME", username)[9]

    return dumps({'error': "None", 'goal': goal})


# Post request
@router.route('/user/set_goal', methods = ['POST'])
@cross_origin()
def set_goal():
    if request.method == 'POST':
        # retrieve useful information from the online form
        args = request.get_json()
        username = str(args.get('username'))
        goal = str(args.get('goal'))

    # if the username does not exist in the database return error message
    if DbController.general_search("USERS", "USERNAME", username) is None:
        return dumps({"error": "Username does not exist"})

    # retrieve the uid from the database(by matching the username)
    uid = DbController.general_search("USERS", "USERNAME", username)[0]

    # update the goal in user table
    result = DbController.user_update_user_table(uid, "GOAL", goal)

    if result != "Update is successful":
        return dumps({"error": result})
    else:
        return dumps({"error": "None"})


# method = get
@router.route('/user/get_birthday', methods = ['GET'])
@cross_origin()
def get_birthday():
    if request.method == 'GET':
        # retrieve useful information from the online form
        username = str(request.args.get('userId'))

    # if the username does not exist in the database return error message
    if DbController.general_search("USERS", "UID", username) is None:
        return dumps({"error": "Username does not exist"})

    birthday = DbController.general_search("USERS", "UID", username)[4]

    return dumps({'error': "None", 'birthday': birthday})


# method = get
@router.route('/full_details', methods = ['GET', 'POST'])
@cross_origin()
def get_user_detail():

    # retrieve useful information from the online form
    args = request.get_json()
    user_id = str(args.get('user_id'))



    # if the username does not exist in the database return error message
    if DbController.general_search("USERS", "UID", user_id) is None:
        return dumps({"error": "UID does not exist"})

    user = DbController.general_search("USERS", "UID", user_id)

    return dumps({'error': "None", 'user': user})


# POST method
@router.route('/follow', methods = ['POST'])
@cross_origin()
def follow_user():
    if request.method == 'POST':
        # retrieve useful information from the online form
        args = request.get_json()
        uid = str(args.get('uid'))
        uid_following = str(args.get('uid_following'))

        result = DbController.follow_follow_other_people(uid, uid_following)

        if result == "users cannot follow themselves":
            return dumps({"error": result})
        elif result == "user id does not exist":
            return dumps({"error": result})
        elif result == "uid_following does not exist":
            return dumps({"error": result})
        elif result == "This user has been follwed":
            return dumps({"error": result})

        return dumps({"error": "None"})


# POST method
@router.route('/unfollow', methods = ['POST'])
@cross_origin()
def unfollow_user():
    if request.method == 'POST':
        # retrieve useful information from the online form
        args = request.get_json()
        uid = str(args.get('uid'))
        uid_following = str(args.get('uid_following'))

        result = DbController.follow_unfollow_other_people(uid, uid_following)

        if result == "The record does not exist":
            return dumps({"error": "This user hasn't been followed yet"})

        return dumps({"error": "None"})


# GET method
# return a list of users which the given uid is following
@router.route('/checkfollowing', methods = ['GET'])
@cross_origin()
def check_following_list():
    if request.method == 'GET':
        # retrieve useful information from the online form
        uid = str(request.args.get('uid'))

        result = DbController.general_multipe_search("FOLLOW", "UID", uid)
        if result is None:
            return dumps({"error": "User has not followed anyone yet!"})

        returned_list = []
        for item in result:
            # for every user retrive the user information
            followed_user = item[1]
            user = DbController.general_search("USERS", "UID", followed_user)
            returned_user = {
                "uid": user[0],
                "username": user[3],
                "picture": user[7],
                "followed_time" : item[2]
            }
            returned_list.append(returned_user)
        return dumps({"error": "None", "following": returned_list})

# GET method
# Checks if user1 is following user2: Returns none
@router.route('/checkfollowship', methods = ['GET'])
@cross_origin()
def check_following():
    if request.method == 'GET':
        # retrieve useful information from the online form
        uid1 = str(request.args.get('uid1'))
        uid2 = str(request.args.get('uid2'))

        result = DbController.follow_check_following(uid1, uid2)

        if result is False:
            return dumps({"error": "User is not following this person","msg": result})

        return dumps({"error": "None", "msg": result})


# GET method
# return a list of users which the given uid is followed
@router.route('/checkfollower', methods = ['GET'])
@cross_origin()
def check_follower_list():
    if request.method == 'GET':
        # retrieve useful information from the online form
        uid = str(request.args.get('uid'))

        result = DbController.general_multipe_search("FOLLOW", "FOLLOWING_ID", uid)

        if result is None:
            return dumps({"error": "User has not been followed by anyone yet!"})
        returned_list = []
        for item in result:
            # for every user retrive the user information
            following_user = item[0]
            user = DbController.general_search("USERS", "UID", following_user)

            returned_user = {
                "uid": user[0],
                "username": user[3],
                "picture": user[7],
                "followed_time" : item[2]
            }
            returned_list.append(returned_user)

        return dumps({"error": "None", "following": returned_list})


# user report review
@router.route('/report/review', methods = ['POST'])
@cross_origin()
def report_review():
    # retrieve information from the form
    args = request.get_json()
    uid_reporting = str(args.get('uid_reporting'))
    uid_reported = str(args.get('uid_reported'))
    bid_reported = str(args.get('bid_reported'))
    reason = str(args.get('reason'))

    # verify the role of the user
    msg = DbController.report_review(uid_reporting, uid_reported, bid_reported, reason)

    if msg != "Success":
        return dumps({"error": msg})

    return dumps({"error": "None"})


# user report post comment
@router.route('/report/postcomment', methods = ['POST'])
@cross_origin()
def report_postcomment():
    # retrieve information from the form
    args = request.get_json()
    uid_reporting = str(args.get('uid_reporting'))
    uid_reported = str(args.get('uid_reported'))
    reported_postid = str(args.get('reported_postid'))
    reported_commentid = str(args.get('reported_commentid'))
    reason = str(args.get('reason'))

    # verify the role of the user
    msg = DbController.report_post_comment(uid_reporting, uid_reported, reason, reported_postid, reported_commentid)

    if msg != "Success":
        return dumps({"error": msg})

    return dumps({"error": "None"})

# method = get
@router.route('/user/get_latest_reviews', methods = ['GET'])
@cross_origin()
def get_user_latest_reviews():

    # retrieve useful information from the online form
    user_id = str(request.args.get('uid'))


    # if the username does not exist in the database return error message
    if DbController.general_search("USERS", "UID", user_id) is None:
        return dumps({"error": "UID does not exist"})

    user = DbController.general_search("USERS", "UID", user_id)

    # return list
    returned_books = []

    latest_reads = DbController.read_get_latest_reviews(user_id, 10)
    # create list of books
    if latest_reads:
        for read in latest_reads:
            book = DbController.general_search("BOOKS", "BID", read[0])
            if book:
                book_info = {
                    "bid": book[0],
                    "name": book[1],
                    "author": book[2],
                    "year": book[3],
                    "country": book[4],
                    "publisher": book[5],
                    "summary": book[6],
                    "rating": float(book[7]),
                    "picture": book[8],
                    "tags": book[9].split("+")
                }
                returned_books.append(book_info)



    return dumps({'error': "None", 'books': returned_books})
