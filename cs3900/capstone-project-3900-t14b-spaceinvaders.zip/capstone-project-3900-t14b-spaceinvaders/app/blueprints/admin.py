# Author: Guan-Hsin Wang, James Saludes, Zijian Yue
# Date: 2/4/2022

# import flask and support modules
from flask import request
from flask import Blueprint

from flask_cors import cross_origin
from json import dumps

import time
from datetime import datetime

# import the DB interface
import os
import sys
# get current folder
cwd = os.getcwd()
sys.path.append(os.path.dirname(cwd + '/../../database'))
from database.DatabaseManager import DataBaseManager

# create the router in Blueprint
router = Blueprint("admin", __name__)
DbController = DataBaseManager()

####################################################################################################################################
####################################################################################################################################

# process the case
@router.route('/admin/cases/process', methods = ['POST'])
@cross_origin()
def process_case():
    # retrieve information from the form
    args = request.get_json()
    uid = str(args.get('uid'))
    rid = str(args.get('rid'))
    admin_message = str(args.get('admin_message'))

    # verify the role of the user
    msg = DbController.general_search("USERS", "UID", uid)

    # return the whole table
    msg = DbController.report_process_case(uid, rid, admin_message)
    if msg != "Success":
        return dumps({"error": msg})

    return dumps({"error": "None"})


# return the report table to the admin
@router.route('/admin/cases', methods = ['GET'])
@cross_origin()
def view_cases():
    # retrieve useful information from the online form
    uid = str(request.args.get('uid'))

    # verify the role of the user
    msg = DbController.general_search("USERS", "UID", uid)

    # check the user is admin
    if msg == None:
        return dumps({'error' : 'User do not exist'})
    elif msg[1] != "admin":
        return dumps({'error' : 'User is not an admin'})

    # return the whole table
    msg = DbController.general_return_a_table("REPORT")
    returned_list = []
    for item in msg:
        returned_list.append({
          "case id" : item[0],
          "reporting_uid" : item[1],
          "reported_uid" : item[2],
          "reason" : item[3],
          "reporting_time" : item[4],
          "status" : item[5],
          "resolved_time" : item[6],
          "admin_message" : item[7],
        })
    # sort the list, so the latetst cases will be shown first
    returned_list.reverse()

    return dumps({"error": "None", "information": returned_list})

####################################################################################################################################
####################################################################################################################################

# insert a book into the DB
@router.route('/admin/addbook', methods = ['POST'])
@cross_origin()
def add_book():

    # retrieve information from the form
    args = request.get_json()
    uid = str(args.get('uid'))
    bookname = str(args.get('name'))
    author = str(args.get('author'))
    year = str(args.get('year'))
    country = str(args.get('country'))
    publishers = str(args.get('publishers'))
    summary = str(args.get('summary'))
    picture = str(args.get('picture'))   # link to a picture? 
    tags = str(args.get('tags'))

    # verify the role of the admin
    
    msg = DbController.general_search("USERS", "UID", uid)
    if msg == None:
        return dumps({'error' : 'User do not exist'})
    elif msg[1] != "admin":
        return dumps({'error' : 'User is not an admin'})

    # insert the book
    msg = DbController.book_create_new_book(bookname, author, year, country, publishers, summary, picture, tags)
    if msg == "Book already exists":
        return dumps({"error": "Book already exists"})
    return dumps({"error" : "None"})

####################################################################################################################################
####################################################################################################################################

# update the status of an user
@router.route('/admin/manage', methods = ['POST'])
@cross_origin()
def manager_user():

    # retrieve useful information from the online form
    args = request.get_json()
    uid = str(args.get('uid'))
    uid_to_update = str(args.get('uid_to_update'))
    new_status = str(args.get('new_status'))

    # verify the status
    if new_status != ("banned" or "active" or "warned" or "online"):
        return dumps({'error' : 'Status can only be banned or active or warned'})

    # verify the role of the admin
   
    msg = DbController.general_search("USERS", "UID", uid)
    if msg == None:
        return dumps({'error' : 'User do not exist'})
    elif msg[1] != "admin":
        return dumps({'error' : 'User is not an admin'})

    # verify the user
    msg = DbController.general_search("USERS", "UID", uid_to_update)
    if msg == None:
        return dumps({'error' : 'User do not exist'})
    elif msg[1] == "admin":
        return dumps({'error' : "Can not change admin's status"})

    DbController.user_update_user_table(uid_to_update, "STATUS", new_status)

    return dumps({'error' : 'None'})
    

####################################################################################################################################
####################################################################################################################################

######################################################
# Total books
# Total users
# Total collections
# Collections per user
# New books in last year/month
# New users in last year/month
# New collections created in last year/month
# New follows in last year/month
# Collection per user in last year/month
######################################################


Month_dict = {
    '01'  : "January",
    '02'  : "February",
    '03'  : "March",
    '04'  : "April",
    '05'  : "May",
    '06'  : "June",
    '07'  : "July",
    '08'  : "August",
    '09'  : "September",
    '10' : "October",
    '11' : "November",
    '12' : "December"
}


# return genera info of the system
@router.route('/information', methods = ['GET'])
@cross_origin()
def generate_report():
    # retrieve useful information from the online form
    uid = str(request.args.get('uid'))
    # verify the role of the user
    msg = DbController.general_search("USERS","UID",uid)

    if msg == None:
        return dumps({'error' : 'User do not exist'})
    elif msg[1] != "admin":
        return dumps({'error' : 'User is not an admin'})

    returned_list = []
    #Total books
    returned_list.append(DbController.book_get_total_number())
    #Total users
    returned_list.append(DbController.user_get_total_number())
    #Total collections
    returned_list.append(DbController.collections_get_total_number())
    #Average num of collections per user
    returned_list.append(DbController.collections_get_total_number() / DbController.user_get_total_number())
    #New users this Month
    returned_list.append(local_stats_to_total_count("USERS"))
    #New collections this Month
    returned_list.append(local_stats_to_total_count("COLLECTIONS"))
    #New follow this Month
    returned_list.append(local_stats_to_total_count("FOLLOW"))





    return dumps({"error": "None", "information": returned_list})

# retrive a table and convert the time information to a time serie
def local_stats_to_timeseries(table_name: str):
    addedtime_index = -1
    if table_name == "COLLECTIONS":
        addedtime_index = 4

    table = DbController.general_return_a_table(table_name)
    current_time = time.strftime("%Y/%m/%d")

    # create template
    current_month = int(current_time.split('/')[1])
    counter = 1
    returned_dict = {}
    while counter <= current_month:
        index = str(counter)
        if counter < 10:
            index = str(0) + str(counter)

        returned_dict[Month_dict[index]] = 0
        counter += 1

    # year of this year
    for item in table:
        # get the month of the current record
        month = item[addedtime_index].split('/')[1]
        # if the current year equals to the year of the record
        if current_time.split('/')[0] == item[addedtime_index].split('/')[0]:
            # convert the current month of numeral to letters
            # e.g. 01 = Jan, 02 = Feb etc
            month_letter = Month_dict[month]
            returned_dict[month_letter] += 1
    return returned_dict

# retrive a table and count the time information
def local_stats_to_total_count(table_name: str):
    totalcount = 0
    addedtime_index = -1

    if table_name == "COLLECTIONS":
        addedtime_index = 4

    table = DbController.general_return_a_table(table_name)

    if(table == None):
        return totalcount

    current_time = datetime.now().strftime("%Y/%m/%d")

    # year of this year
    for item in table:
        # get the month of the current record
        month = item[addedtime_index].split('/')[1]
        # if the current year equals to the year of the record
        if current_time.split('/')[1] == month:
            totalcount = totalcount + 1
    return totalcount
