# Author: Guan-Hsin Wang, James Saludes(inspector), Zijian Yue(inspector)
# Date: 2/4/2022

# import flask and support modules
from flask import request
from flask import Blueprint

from flask_cors import cross_origin
from json import dumps
import hashlib


# import the DB interface
import os
import sys
# get current folder
cwd = os.getcwd()
sys.path.append(os.path.dirname(cwd + '/../../database'))
from database.DatabaseManager import DataBaseManager


# create the router in Blueprint
router = Blueprint("logreg", __name__)
DbController = DataBaseManager()


# POST and get method 
# login a user into the system 
@router.route('/login', methods = ['POST', 'GET'])
@cross_origin()
def login():
    if request.method == 'POST':
        # retrieve information from the form
        args = request.get_json()
        username = str(args.get('username'))
        password = str(args.get('password'))


        # if the username is not in the database return error message
        if DbController.general_search("USERS", "USERNAME", username) is None:
            return dumps({"error": "User not found"})
        
        # check the status of an user is not banned
        if DbController.general_search("USERS", "USERNAME", username)[8] == 'banned':
            return dumps({"error": "Users has been banned!"})

        # if the username and password don't match return error message
        if DbController.general_search("USERS", "USERNAME", username)[2] != hashlib.sha256(password.encode()).hexdigest():
            return dumps({"error": "Username/ password incorrect"})

        # retrive needed information from the database
        user_details = DbController.general_search("USERS", "USERNAME", username)
        uid = user_details[0]
        role = user_details[1]
        username = user_details[3]
        user_image = user_details[7]
        # return the login user information to web
        return dumps({"error": "None",
                        "user_id": uid,
                      "role": role,
                        "username": username,
                        "user_image": user_image
        })
    # if the method is not post, prompot the systmetic error to the web
    return "Systematic Error, Unexpected result"


# Post method
# register a new user to the system
@router.route('/register', methods = ['POST', 'GET'])
@cross_origin()
def register():
    # register an user: store the information of the user to the database
    if request.method == 'POST':
        # retrieve useful information from the online form
        args = request.get_json()
        username = str(args.get('username'))
        password = str(args.get('password'))
        user_image = str(args.get('user_image'))
        email = str(args.get('email'))

        # if the username is already in the database return error message
        if DbController.general_search("USERS", "USERNAME", username) != None:
            return dumps({"error": "Username already exists"})

        # create new user in the database
        DbController.user_create_new_user(username, hashlib.sha256(password.encode()).hexdigest(), "", "", "user", email , user_image)

        # retrieve the uid from the database(by matching the username)
        uid = DbController.general_search("USERS", "USERNAME", username)[0]

        # infrom the web
        return dumps({'error': "None", 'uid': uid})