# Author: Guan-Hsun Wang, James(inspector), Zijian Yue

# import flask and support modules
from flask import request
from flask import Blueprint

from flask_cors import cross_origin
from json import dumps
import pandas as pd
import numpy as np
import random
from scipy.sparse import csr_matrix
from sklearn.neighbors import NearestNeighbors


# import the DB interface
import os
import sys
# get current folder
cwd = os.getcwd()
sys.path.append(os.path.dirname(cwd + '/../../database'))
from database.DatabaseManager import DataBaseManager

# create the router in Blueprint
router = Blueprint("forum", __name__)
DbController = DataBaseManager()

# POST method 
# create a new post in the forum
@router.route('/forum/post', methods = ['POST'])
@cross_origin()  
def create_a_post():
    # retrieve information from the form
    args = request.get_json()
    uid = str(args.get('uid'))
    title = str(args.get('title'))
    content = str(args.get('content'))
    
    
    msg = DbController.posts_create_new_post(uid, title, content)
    if msg == "User does not exist":
        return dumps({"error": msg})

    post_info = DbController.general_search("Posts", "title", title)
    pid = post_info[0]
    return dumps({"error": "None", "pid": pid})


# POST method 
# delete an owned post in the forum
@router.route('/forum/post/delete', methods = ['POST'])
@cross_origin()  
def delete_a_post():
    # retrieve information from the form
    args = request.get_json()
    uid = str(args.get('uid'))
    pid = str(args.get('pid'))
    
    msg = DbController.posts_delete_a_post(uid, pid)
    
    if msg != "success":
        return dumps({"error": msg})
    
    return dumps({"error": "None"})


# POST method 
# edit an owned post in the forum
@router.route('/forum/post/edit', methods = ['POST'])
@cross_origin()  
def edit_a_post():
    # retrieve information from the form
    args = request.get_json()
    uid = str(args.get('uid'))
    pid = str(args.get('pid'))
    new_content = str(args.get('new_content'))
    
    msg = DbController.posts_update_post(pid, uid, new_content)
    
    if msg != "success":
        return dumps({"error": msg})
    
    return dumps({"error": "None"})


# GET method 
# delete a comment to the post in the forum
@router.route('/forum/post/search', methods = ['GET'])
@cross_origin()  
def return_a_post():
    # get info from the input
    pid = str(request.args.get('pid'))
    
    # search for the post
    post_info = DbController.general_search("Posts", "PID", pid)
    if post_info == None:
        return dumps ({"error" : "posts does not exist"})
    username = DbController.general_search("USERS", "UID", post_info[1])[3]

    # get the post ready
    post_info = {
        "post_id"     : post_info[0],
        "user_id"     : post_info[1],
        "username": username,
        "title"       : post_info[2],
        "content"     : post_info[3],
        "time_created": post_info[5],
        "edited "     : post_info[6],
        "time_edited" : post_info[7],
    }
    
    # get the comments ready 
    comments_info = DbController.general_multipe_search("Comments", "PID", pid)
    comments_list = []
    if comments_info:
        for comments in comments_info:
            username = DbController.general_search("USERS", "UID", comments[1])[3]
            comments_list.append({
                "comment_id"   : comments[0],
                "username": username,
                "uid"          : comments[1],
                "pid"          : comments[2],
                "content"      : comments[3],
                "time_created" : comments[4],
                "edited"       : comments[5],
                "time_edited"  : comments[6],
            })
        
    # return the post with comments
    return dumps({"error": "none", "post": post_info, "comments": comments_list})


# POST method 
# add a comment to the post in the forum
@router.route('/forum/comment/add', methods = ['POST'])
@cross_origin()  
def add_a_comment():
    # retrieve information from the form
    args = request.get_json()
    uid = str(args.get('uid'))
    pid = str(args.get('pid'))
    content = str(args.get('content'))
    
    msg = DbController.comments_create_new_comment(uid, pid, content)
    
    if msg != "success":
        return dumps({"error": msg})
    
    return dumps({"error": "None"})


# POST method 
# edit a comment to the post in the forum
@router.route('/forum/comment/edit', methods = ['POST'])
@cross_origin()  
def edit_a_comment():
    # retrieve information from the form
    args = request.get_json()
    uid = str(args.get('uid'))
    pid = str(args.get('pid'))
    new_content = str(args.get('new_content'))
    comment_id = str(args.get('comment_id'))
    
    msg = DbController.comments_update_a_comment(uid, comment_id, pid, new_content)
    
    if msg != "success":
        return dumps({"error": msg})
    
    return dumps({"error": "None"})


# POST method 
# delete a comment to the post in the forum
@router.route('/forum/comment/delete', methods = ['POST'])
@cross_origin()  
def delete_a_comment():
    # retrieve information from the form
    args = request.get_json()
    uid = str(args.get('uid'))
    pid = str(args.get('pid'))
    comment_id = str(args.get('comment_id'))
    
    msg = DbController.comments_delete_a_comment(uid, comment_id, pid)
    
    if msg != "success":
        return dumps({"error": msg})
    
    return dumps({"error": "None"})

# GET method 
# get all the post in the forum
@router.route('/forum/get_posts', methods = ['GET'])
@cross_origin()  
def get_all_posts():
    # get post table
    posts = DbController.general_return_a_table("POSTS")
    # no post
    if len(posts) == 0:
        return dumps({"error": "None", "posts": []})
    
    post_list = []
    # get the info of each post
    for post in posts:
        username = DbController.general_search("USERS", "UID", post[1])[3]
        post_info = {
            "pid": post[0],
            "title": post[2],
            "posted_at": post[5],
            "username": username,
            "content": post[3],
            "comments": int(post[4]) - 1
        }
        post_list.append(post_info)
    
    # the latest post appears first
    post_list.reverse()
    return dumps({"error": "None", "posts": post_list})

# GET method 
# get all the comments in the post
@router.route('/forum/get_posts_comments', methods = ['GET'])
@cross_origin()  
def get_all_posts_comments():
    # get info from the input
    pid = str(request.args.get('pid'))
    
    # get post table
    post = DbController.general_search("POSTS", "PID", pid)
    # no post
    if post is None:
        return dumps({"error": "No such post"})
    
    # get comments
    comments = DbController.general_multipe_search("COMMENTS", "PID", pid)
    # no comment
    if comments is None:
        return dumps({"error": "None", "comments": []})
    
    comment_list = []
    # get the info of each comment
    for comment in comments:
        username = DbController.general_search("USERS", "UID", comment[1])[3]
        comment_info = {
            "username": username,
            "commented_at": comment[4],
            "content": comment[3]
        }
        comment_list.append(comment_info)
    
    return dumps({"error": "None", "comments": comment_list})