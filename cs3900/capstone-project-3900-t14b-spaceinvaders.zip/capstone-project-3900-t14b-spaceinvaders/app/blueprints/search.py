# Author: James Saludes
# Date: 2/4/2022

# import flask and support modules
from flask import request
from flask import Blueprint

from flask_cors import cross_origin
from json import dumps


# import the DB interface
import os
import sys
# get current folder
cwd = os.getcwd()
sys.path.append(os.path.dirname(cwd + '/../../database'))
from database.DatabaseManager import DataBaseManager


# create the router in Blueprint
router = Blueprint("search", __name__)
DbController = DataBaseManager()

# Searches database for search query; returns lists of books, users, collections matching search query
@router.route('/search', methods = ['GET'] )
@cross_origin()
def search():
    if request.method == 'GET':
        # retrieve useful information from the online form
        searchterm = str(request.args.get('term'))
        sorting = str(request.args.get('sortby'))
        # name, author, rating, year
        # collection - name, creator, name, when it was created
        # user - username, username, username, age
        book_sortby = ""
        collection_sortby = ""
        user_sortby = ""
        if sorting == 'name':
            book_sortby = "name"
            collection_sortby = "collection_name"
            user_sortby = "username"
        elif sorting == 'author':
            book_sortby = "author"
            collection_sortby = "creator"
            user_sortby = 'username'
        elif sorting == 'rating':
            book_sortby = "rating"
            collection_sortby = "collection_name"
            user_sortby = "username"
        elif sorting == 'year':
            book_sortby = "year"
            collection_sortby = "time_created"
            user_sortby = "age"

        book_result = DbController.string_search("BOOKS", ["BOOKNAME", "AUTHOR"], searchterm)
        user_result = DbController.string_search("USERS", ["USERNAME"], searchterm)
        collection_result = DbController.string_search("COLLECTIONS", ["COLLECTION_NAME"], searchterm)

        # format the returned search and pass it to the front end

        # initialise lists of search results; Empty list returned if no search results match query
        # process database results into lists 

        returned_books = []
        if book_result != None:
            for tupes in book_result:
                returned_books.append({
                        "type" : "book",
                        "bid": tupes[0],
                        "name" : tupes[1],
                        "author" : tupes[2],
                        "rating": float(tupes[7]),
                        "year": tupes[3],
                        "tags": tupes[9].split("+"),
                })

        returned_users = []
        if user_result != None:
            for tupes in user_result:
                age = tupes[4]
                if age != "":
                    age = str(DbController.user_get_age(tupes[0]))
                returned_users.append({
                        "type" : "user",
                        "uid" : tupes[0],
                        "username": tupes[3],
                        "self_intro" : tupes[5],
                        "picture" : tupes[7],
                        "status": tupes[8],
                        "age": age
                })

        returned_collections = []
        if collection_result != None:
            for tupes in collection_result:
                book_count = DbController.collections_bookcount(tupes[0])
                own_record = DbController.general_search("OWN", "CID", tupes[0])
                users_record = DbController.general_search("USERS", "UID", own_record[1])
                generated_tags = DbController.collections_get_tag(tupes[0])[0]

                returned_collections.append({
                        "type" : "collection",
                        "collection_id": tupes[0],
                        "collection_name": tupes[1],
                        "username": users_record[3],
                        "picture" : tupes[2],
                        "comments" : tupes[3],
                        "time_created" : tupes[4],
                        "tags": generated_tags.split('+'),
                        "book_count": str(book_count[0]),
                        "uid": own_record[1],
                        "creator": users_record[3]
                })

        returned_books = sorted(returned_books, key=lambda x: x[book_sortby], reverse=True)
        returned_users = sorted(returned_users, key=lambda x: x[user_sortby], reverse=True)
        returned_collections = sorted(returned_collections, key=lambda x: x[collection_sortby], reverse=True)

        # return the result lists
        return dumps({
            "error": "None",
            "books": returned_books,
            "users": returned_users,
            "collections": returned_collections
        })