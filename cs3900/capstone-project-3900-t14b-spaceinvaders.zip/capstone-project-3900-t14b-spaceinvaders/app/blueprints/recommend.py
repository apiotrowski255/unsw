# Author: Guan-Hsun Wang, James(inspector), Zijian Yue(inspector)
# Date: 2/4/2022

# import flask and support modules
from flask import request
from flask import Blueprint

from flask_cors import cross_origin
from json import dumps
import pandas as pd
import numpy as np
import random
from scipy.sparse import csr_matrix
from sklearn.neighbors import NearestNeighbors


# import the DB interface
import os
import sys
# get current folder
cwd = os.getcwd()
sys.path.append(os.path.dirname(cwd + '/../../database'))
from database.DatabaseManager import DataBaseManager


# create the router in Blueprint
router = Blueprint("recommend", __name__)
DbController = DataBaseManager()




# get method
# return all related info for a book
@router.route('/browse', methods = ['GET'])
@cross_origin()
def recommend():
    if request.method == 'GET':

        # retrieve useful information from the online form
        uid = str(request.args.get('uid'))
        mode = str(request.args.get('mode'))
        tag = str(request.args.get('tag'))

        returned_books = []


        #Initial Page load state returns empty list
        if(mode == 'initial'):
            #running initial page load state
            return dumps({"error": "None", "books": returned_books})

        # select which recommender code to use from frontend using mode variable
        if(mode == 'random'):
            #running random recommender
            returned_books = random_recommend('')
            return dumps({"error": "None", "books": returned_books})

        if(mode == 'rating'):
            books = DbController.general_search("READ", "UID", uid)
            if books is None:
                return dumps({"error": "Read list is empty. Please add more books to your read list.", "books": returned_books})

            #running rating recommender
            return recommend_books()

        if(mode == 'tag'):
            result = random_recommend(tag)
            if result == 'No such tag':
                return dumps({"error": result, "books": returned_books})
            
            return dumps({"error": "None", "books": result})

        if(mode == 'following'):
            if len(DbController.general_return_a_table("FOLLOW")) == 0:
                #If follow table is empty
                return dumps({"error": "Not following anyone. Please follow at least one user.", "books": returned_books})

            #running followers recommender
            return recommend_books_on_followed()


        #exit default path
        return dumps({"error": "Incorrect mode", "books": returned_books})


# aggregated algo to help the user
# 3 random books and 7 random high rating books
def random_recommend(tags:str):
    if tags == '':
        # get all books which rated 4 ~ 5
        books = DbController.book_get_four_five()
        high_rating_books = []
        # create rand index = 7
        if len(books) >= 7:
            index = random.sample(range(len(books)), 7)
            for i in index:
                high_rating_books.append(books[i])
        elif len(books) > 0:
            for i in range(len(books)):
                high_rating_books.append(books[i])

        # 10 random books
        book_list_rand = DbController.book_get_random(10)

        # set(10 books) - set(7) = set(?)[0:3]
        random_books = [item for item in book_list_rand if item not in high_rating_books]

        # create dict for finalised 10 books
        overall = random_books + high_rating_books
        if len(overall) > 10:
            overall = overall[0:10]
        returned_books = []
        
        for book in overall:
            book_info = {
                "bid": book[0],
                "name": book[1],
                "author": book[2],
                "year": book[3],
                "country": book[4],
                "publisher": book[5],
                "summary": book[6],
                "rating": float(book[7]),
                "picture": book[8],
                "tags": book[9].split("+"),
            }
            returned_books.append(book_info)
    else:
        # recommend top 10 highest rating books with the given tag
        books = DbController.book_get_books_by_tag(tags)
        
        #If no books exist with given tag
        if books is None:
            return "No such tag"
        high_rating_books = []
        # create rand index = 7
        if len(books) > 20:
            # random choose 5 books from top 20 rated book
            index = random.sample(range(20), 5)
            for i in index:
                high_rating_books.append(books[i])
        elif len(books) > 5:
            # random choose 5 books
            index = random.sample(range(len(books)), 5)
            for i in index:
                high_rating_books.append(books[i])
        else:
            for i in range(len(books)):
                high_rating_books.append(books[i])

        # 10 random books
        book_list_rand = DbController.book_get_random(10)

        # set(10 books) - set(7) = set(?)[0:3]
        random_books = [item for item in book_list_rand if item not in high_rating_books][0:10-len(high_rating_books)]

        # create dict for finalised 10 books
        overall = random_books + high_rating_books

        returned_books = []

        for book in overall:
            book_info = {
                "bid": book[0],
                "name": book[1],
                "author": book[2],
                "year": book[3],
                "country": book[4],
                "publisher": book[5],
                "summary": book[6],
                "rating": float(book[7]),
                "picture": book[8],
                "tags": book[9].split("+"),
            }
            returned_books.append(book_info)

    returned_books = sorted(returned_books, key=lambda x: float(x['rating']), reverse=True)
    return returned_books

# get method 
# return all related info for a book
@router.route('/browse/default', methods = ['GET'])
@cross_origin()  
def recommend_books():
    if request.method == 'GET':
        # if there is no records yet, randomly select books for users
        if len(DbController.general_return_a_table("READ")) == 0:
            total = DbController.book_get_total_number()
            bids = DbController.book_get_random(10)
            returned_books = []
            for bid in bids:

                book = DbController.general_search("BOOKS", "BID", bid[0])

                book_info = {
                    "bid": book[0],
                    "name": book[1],
                    "author": book[2],
                    "year": book[3],
                    "country": book[4],
                    "publisher": book[5],
                    "summary": book[6],
                    "rating": float(book[7]),
                    "picture": book[8],
                    "tags": book[9].split("+"),
                }
                returned_books.append(book_info)
            return dumps({"error": "None", "books": returned_books})

        # retrieve useful information from the online form
        uid = str(request.args.get('uid'))
        print("Running /browse in recommend_books functions (recommend.py)")
        # select a book randomly which has been read by the user
        books = DbController.read_get_books_by_user(uid)

        # the user hasn't read any book
        # use random_recommend() for recommendation
        if len(books) == 0:
            return dumps({"error": "None", "books": random_recommend('')})

        else:
            index = 0
            # keep looping until the chosen book is rated >= 3(4) by the user
            used_index = []
            found_index = False
            while len(used_index) != len(books):
                index = np.random.randint(len(books))
                read = DbController.read_get_a_record(uid, str(books[index]))
                if float(read[3]) >= 3:
                    found_index = True
                    break
                if index not in used_index:
                    used_index.append(index)

            # the user hasn't rated >= 3
            # use random_recommend() for recommendation
            if not found_index:
                return dumps({"error": "None", "books": random_recommend('')})

            # get ratings
            ratings = DbController.read_get_all_rating()
            ratings = pd.DataFrame(ratings, columns=['bid', 'uid', 'rating'])
            ratings = ratings.astype(float)

            # create a pivot table to get the rating of each book
            rating_pivot = ratings.pivot_table(index='bid', columns='uid', values='rating').fillna(0)
            # create a sparse matrix to fit in the model
            sparse_matrix = csr_matrix(rating_pivot.values)
            
            # Nearest neighbors model with brute force search and cosine similarity
            # n_jobs=-1 means using all processors
            model = NearestNeighbors(algorithm='brute', metric='cosine', n_jobs=-1)
            model.fit(sparse_matrix)
            
            # get k nearest neighbors and their distances
            distances, indices = model.kneighbors(rating_pivot.iloc[index,:].values.reshape(1, -1), n_neighbors=int(rating_pivot.shape[0] / 2 + 1))
            
            recommended_bids = []
            # get recommended bids
            for bid in rating_pivot.index[indices.flatten()]:
                recommended_bids.append(str(bid))
            
            # randomly choose 1 recommended book
            # use this book to get other recommendation
            if len(recommended_bids) > 10:
                recommended_bids = recommended_bids[0:10]
            index = np.random.randint(len(recommended_bids))
            distances, indices = model.kneighbors(rating_pivot.iloc[index,:].values.reshape(1, -1), n_neighbors=int(rating_pivot.shape[0] / 2))
            
            recommended_bids.clear()
            returned_books = []
            # get recommended bids
            for bid in rating_pivot.index[indices.flatten()]:
                recommended_bids.append(str(bid))

            # recommend first 10 books
            if len(recommended_bids) > 10:
                recommended_bids = recommended_bids[0:10]

            for i in range(len(recommended_bids)):
                recommended_bids[i] = str(int((float(recommended_bids[i]))))


            # get info of recommended books
            for bid in recommended_bids:
                book = DbController.book_table_search("BID", bid)
                if book:
                    book_info = {
                        "bid": book[0],
                        "name": book[1],
                        "author": book[2],
                        "year": book[3],
                        "country": book[4],
                        "publisher": book[5],
                        "summary": book[6],
                        "rating": float(book[7]),
                        "picture": book[8],
                        "tags": book[9].split("+")
                    }
                    returned_books.append(book_info)
            
            # if less than 10 books
            # add more books
            if len(returned_books) < 10:
                other_books = random_recommend('')
                for item in other_books:
                    if item not in returned_books:
                        returned_books.append(item)
                    if len(returned_books) == 10:
                        break
            
            returned_books = sorted(returned_books, key=lambda x: float(x['rating']), reverse=True)
            return dumps({"error": "None", "books": returned_books})

# get method 
# return all related info for a book
@router.route('/browse/followedusers', methods = ['GET'])
@cross_origin()  
def recommend_books_on_followed():
    if request.method == 'GET':
        # retrieve useful information from the online form
        uid = str(request.args.get('uid'))
        
        followings = DbController.general_multipe_search("FOLLOW", "UID", uid)
        if followings is None:
            return dumps({"error": "No user following", "books": []})
        
        following_uid = np.random.randint(len(followings))
        following_uid = followings[following_uid][1]
        
        # select a book randomly which has been read by the user
        books = DbController.read_get_books_by_user(following_uid)
        # the user hasn't read any book
        # use random_recommend() for recommendation
        if len(books) == 0:
            return dumps({"error": "None", "books": random_recommend('')})

        else:
            index = 0
            uid = following_uid
            # keep looping until the chosen book is rated >= 1(2) by the user
            used_index = []
            found_index = False
            while len(used_index) != len(books):
                index = np.random.randint(len(books))
                read = DbController.read_get_a_record(uid, str(books[index]))
                if float(read[3]) >= 1:
                    found_index = True
                    break
                if index not in used_index:
                    used_index.append(index)

            # the user hasn't rated >= 3
            # use random_recommend() for recommendation
            if not found_index:
                return dumps({"error": "No tags recommended by", "books": random_recommend('')})

            # get ratings
            ratings = DbController.read_get_all_rating()
            ratings = pd.DataFrame(ratings, columns=['bid', 'uid', 'rating'])
            ratings = ratings.astype(float)

            # create a pivot table to get the rating of each book
            rating_pivot = ratings.pivot_table(index='bid', columns='uid', values='rating').fillna(0)
            print(rating_pivot)
            # create a sparse matrix to fit in the model
            sparse_matrix = csr_matrix(rating_pivot.values)

            # Nearest neighbors model with brute force search and cosine similarity
            # n_jobs=-1 means using all processors
            model = NearestNeighbors(algorithm='brute', metric='cosine', n_jobs=-1)
            model.fit(sparse_matrix)

            chosen_book = np.random.randint(len(books))
            index = int(books[chosen_book])
            print(index)
            print(rating_pivot.loc[2684,:])
            # get k nearest neighbors and their distances
            distances, indices = model.kneighbors(rating_pivot.loc[index,:].values.reshape(1, -1), n_neighbors=int(rating_pivot.shape[0] / 2 + 1))

            recommended_bids = []
            # get recommended bids
            for bid in rating_pivot.index[indices.flatten()]:
                recommended_bids.append(str(bid))

            # randomly choose 1 recommended book
            # use this book to get other recommendation
            recommended_bids = recommended_bids[0:10]
            index = np.random.randint(rating_pivot.shape[0])
            distances, indices = model.kneighbors(rating_pivot.iloc[index,:].values.reshape(1, -1), n_neighbors=int(rating_pivot.shape[0] / 2 + 1))

            recommended_bids.clear()
            returned_books = []
            # get recommended bids
            for bid in rating_pivot.index[indices.flatten()]:
                recommended_bids.append(str(bid))

            # recommend first 10 books
            if len(recommended_bids) > 10:
                recommended_bids = recommended_bids[0:10]

            for i in range(len(recommended_bids)):
                recommended_bids[i] = str(int((float(recommended_bids[i]))))

            # get info of recommended books
            for bid in recommended_bids:
                book = DbController.book_table_search("BID", bid)
                if book:
                    book_info = {
                        "bid": book[0],
                        "name": book[1],
                        "author": book[2],
                        "year": book[3],
                        "country": book[4],
                        "publisher": book[5],
                        "summary": book[6],
                        "rating": float(book[7]),
                        "picture": book[8],
                        "tags": book[9].split("+")
                    }
                    returned_books.append(book_info)

            # if less than 10 books
            # add more books
            if len(returned_books) < 10:
                other_books = random_recommend('')
                for item in other_books:
                    if item not in returned_books:
                        returned_books.append(item)
                    if len(returned_books) == 10:
                        break

            returned_books = sorted(returned_books, key=lambda x: float(x['rating']), reverse=True)
            return dumps({"error": "None", "books": returned_books})