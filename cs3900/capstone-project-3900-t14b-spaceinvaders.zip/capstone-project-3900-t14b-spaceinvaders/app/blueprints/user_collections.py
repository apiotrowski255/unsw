# Author: Guan-Hsin Wang, James Saludes, Zijian Yue
# Date: 2/4/2022

# import flask and support modoles
from flask import request
from flask import Blueprint

from flask_cors import cross_origin
from json import dumps


# import the DB interface
import os
import sys
# get current folder
cwd = os.getcwd()
sys.path.append(os.path.dirname(cwd + '/../../database'))
from database.DatabaseManager import DataBaseManager


# name the logreg.py in Blueprint
router = Blueprint("user_collections", __name__)
DbController = DataBaseManager()


# Post request
@router.route('/user/collection/create', methods = ['POST'])
@cross_origin()
def create_collection():
    if request.method == 'POST':
        # retrieve useful information from the online form
        args = request.get_json()
        username = str(args.get('username'))
        collection_name = str(args.get('collection_name'))
        picture = str(args.get('picture'))
        comments = str(args.get('comments'))
        tags = str(args.get('tags'))
        
        # if the username does not exist in the database return error message
        if DbController.general_search("USERS", "USERNAME", username) is None:
            return dumps({"error": "Username does not exist"})
        
        # retrieve the uid from the database(by matching the username)
        uid = DbController.general_search("USERS", "USERNAME", username)[0]
        
        # create new collection then link with user and books
        DbController.collections_create_and_link_new_collection(uid, collection_name, picture, comments, tags, [])
        
        return dumps({"error": "None"})


#Post request
@router.route('/user/collection/delete', methods = ['POST'])
@cross_origin()
def delete_collection():
    # delete a collection and remove all the records related to this collection
    if request.method == 'POST':

        args = request.get_json()
        cid = str(args.get('cid'))

        msg = DbController.collections_delete_collection(cid)

        #check deletion error
        if msg == "Error: Collection does not exist":
            return dumps({"error": "Collection does not exist"})
        return dumps({"error": "None"})


# Get request
@router.route('/user/collection/show', methods = ['GET'])
@cross_origin()
def get_users_collections():
    if request.method == 'GET':
        # retrieve useful information from the online form
        uid = str(request.args.get('uid'))
        # get collection via cid
        collections = DbController.collections_search_collections("UID", uid)
        returned_collections = []

        if collections is not None:
            for tupes in collections:
                book_count = DbController.collections_bookcount(tupes[0])
                own_record = DbController.general_search("OWN", "CID", tupes[0])
                users_record = DbController.general_search("USERS", "UID", uid)
                generated_tags = DbController.collections_get_tag(tupes[0])

                returned_collections.append({
                    "type": "collection",
                    "collection_id": tupes[0],
                    "collection_name": tupes[1],
                    "username": users_record[3],
                    "picture": tupes[2],
                    "comments": tupes[3],
                    "time_created": tupes[4],
                    "tags": generated_tags,
                    "book_count": str(book_count[0]),
                    "uid": uid
                })
                
        if collections is None:
            return dumps({"error": "No collection for the user"})
        else:
            return dumps({"error": "None", "collections": returned_collections})


# Get request
@router.route('/user/collection', methods=['GET'])
@cross_origin()
def get_collection():
    if request.method == 'GET':
        # retrieve useful information from the online form
        cid = str(request.args.get('cid'))
        # get collection via cid
        collections = DbController.collections_search_collections("CID", cid)
        returned_collections = []
        if collections is not None:
            for tupes in collections:

                book_count = DbController.collections_bookcount(tupes[0])
                own_record = DbController.general_search("OWN", "CID", tupes[0])
                users_record = DbController.general_search("USERS", "UID", own_record[1])
                generated_tags = DbController.collections_get_tag(tupes[0])

                returned_collections.append({
                    "type": "collection",
                    "collection_id": tupes[0],
                    "collection_name": tupes[1],
                    "username": users_record[3],
                    "picture": tupes[2],
                    "comments": tupes[3],
                    "time_created": tupes[4],
                    "tags": generated_tags,
                    "book_count": str(book_count[0]),
                    "uid": own_record[1],
                })
        if collections is None:
            return dumps({"error": "No collection"})
        else:
            return dumps({"error": "None", "collections": returned_collections})


# Post request
# Adding books into a collection
@router.route('/user/collection/addbooks', methods = ['POST'])
@cross_origin()
def collection_addbooks():
    if request.method == 'POST':
        # retrieve useful information from the online form
        args = request.get_json()
        cid = str(args.get('cid'))
        bids = [str(x) for x in args.get('bids')]
        
        msg = DbController.collections_add_new_books(cid, bids)
        if msg == "Failed, book id does not exists":
            return dumps({"error": "Adding non-existed books into a list"})
        return dumps({"error": "None"})


# Post request
# Deleting singular book from a collection
@router.route('/user/collection/deletebook', methods = ['POST'])
@cross_origin()
def collection_deletebook():
    if request.method == 'POST':
        # retrieve information from the online form
        args = request.get_json()
        cid = str(args.get('cid'))
        bid = str(args.get('bid'))
        msg = DbController.collections_delete_books(cid, [bid])
        if msg == "Failed book id does not exist":
            return dumps({"error": "Deleting non-existing book"})
        return dumps({"error": "None"})


# Post request
# Changing name of a collection
@router.route('/user/collection/changename', methods = ['POST'])
@cross_origin()
def collection_changename():
    if request.method == 'POST':
        # retrieve useful information from the online form
        args = request.get_json()
        cid = str(args.get('cid'))
        name = str(args.get('name'))
        msg = DbController.collections_update_collection_table(cid, "COLLECTION_NAME", name)
        if msg == "Collection does not exists":
            return dumps({"error": "Updating non-existed collection"})
        elif msg == "Field does not exist":
            return dumps({"error": "Updating non-existed field"})
        return dumps({"error": "None"})


# Get request
# return all books inside a collection
@router.route('/user/collection/collectionbooks', methods = ['GET'])
@cross_origin()
def get_books_in_a_collection():
    if request.method == 'GET':
        # retrieve useful information from the online form
        cid = str(request.args.get('cid'))
    else:
        return dumps({"error": "wrong methods"})

    # retrive all the books in that collections with the given cid

    list_books = DbController.collections_search_book_and_added_time(cid)

    # no such collection
    if list_books is None:
         return dumps({"error": "No such collection"})
     # sort the list using time index, the element of the list is list(tuple)
    list_books.sort(key=lambda x: x[-1], reverse=True)
    returned_books = []
    for tupes in list_books:
        returned_books.append({
            "type": "book",
            "bid": tupes[0],
            "name": tupes[1],
            "author": tupes[2],
            "rating": float(tupes[7]),
            "tags": tupes[9].split("+"),
        })

    return dumps({"error": "None", "books": returned_books})

