# Author: Guan-Hsin Wang, James Saludes(inspector), Zijian Yue(inspector)
# Date: 2/4/2022

# import flask and support modules
from flask import request
from flask import Blueprint

from flask_cors import cross_origin
from json import dumps

from datetime import datetime


# import the DB interface
import os
import sys
# get current folder
cwd = os.getcwd()
sys.path.append(os.path.dirname(cwd + '/../../database'))
from database.DatabaseManager import DataBaseManager


# create the router in Blueprint
router = Blueprint("books", __name__)
DbController = DataBaseManager()

# get method

# return all related info for a book
@router.route('/book', methods = ['GET'])
@cross_origin()
def get_one_book():
    # get the bid from the web
    if request.method == 'GET':

        # retrieve useful information from the online form
        bid = str(request.args.get('bid'))

        book = DbController.general_search("BOOKS", "BID", bid)
        if book == None:
            return dumps({"error": "This book doesn't exist"})

        # querries
        book = DbController.general_search("BOOKS", "BID", bid)

        # reviews
        reviews = DbController.general_multipe_search("READ", "BID", bid)
        if reviews is None:
            return dumps({
            "error": "None",
            "book": {
                'bid': bid,
                "name" : book[1],
                "image": book[8],
                "author" : book[2],
                "publisher": book[5],
                "reads": 0,
                "summary": book[6],
                "rating": float(book[7]),
                "tags": book[9].split("+"),
                "reviews" : [],
            }
        })

        review_list = []
        for individual in reviews:
            if individual[2] != '':
                username = DbController.general_search("USERS", "UID", individual[0])[3]
                review_list.append( {"username": username, "uid": individual[0], "bid": bid, "ratings" : float(individual[3]), "review" : individual[2]} )
        return dumps({
            "error": "None",
            "book": {
                'bid': bid,
                "image": book[8],
                "name" : book[1],
                "author" : book[2],
                "publisher": book[5],
                "summary": book[6],
                "rating": float(book[7]),
                "tags": book[9].split("+"),
                "reviews" : review_list,
                "reads": len(reviews),
            }
        })

# get method

# return all related info for a book
@router.route('/book/rate_review', methods = ['POST'])
@cross_origin()
def user_rate():
    if request.method == 'POST':
        # retrieve useful information from the online form
        args = request.get_json()
        username = str(args.get('username'))
        bid = str(args.get('bookid'))
        review = str(args.get('review'))
        rating = str(args.get('rating'))

        # search for uid
        uid = DbController.general_search("USERS", "USERNAME", username)
        if uid == None:
            return dumps({"error" : "User does not exist"})
        uid = uid[0]

        # retrive reads table information
        record = DbController.read_get_a_record(uid,bid)
        if record != None:
            return dumps({"error" : "User has already rated and reviewed this book"})

        now = datetime.now()
        dt_string = now.strftime("%d/%m/%Y %H:%M:%S")


        # else help user update the table
        DbController.read_create_new_record(uid, bid, review, rating, dt_string, "")
        DbController.book_update_the_rating(bid)

        return dumps({"error" : "None"})
