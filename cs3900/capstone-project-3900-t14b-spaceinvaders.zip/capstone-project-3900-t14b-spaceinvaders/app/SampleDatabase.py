# import the DB interface
import os
import sys
# get current folder
cwd = os.getcwd()
sys.path.append(os.path.dirname(cwd + '/../database'))
from database.DatabaseManager import DataBaseManager

DbContoller = DataBaseManager()

# create 3 users
uid = "1"
username = "username1"
birthday = "01-01-0001"
password = 'password1'
profile_pic = "pic1"
role = "admin"
email = "1@ggmail.com"
self_intro = "intro1"
DbContoller.user_create_new_user(username, password, birthday, profile_pic, role, email, self_intro)

uid = "2"
username = "username2"
birthday = "01-01-0002"
password = "password2"
profile_pic = "pic2"
role = "user"
email = "2@ggmail.com"
self_intro = "intro2"
DbContoller.user_create_new_user(username, password, birthday, profile_pic, role, email, self_intro)

uid = "3"
username = "username3"
birthday = "01-01-0003"
password = "password3"
profile_pic = "pic3"
role = "user"
email = "3@ggmail.com"
self_intro = "intro3"
DbContoller.user_create_new_user(username, password, birthday, profile_pic, role, email, self_intro)

# create three books
bookname = 'bookname1'
author = 'author1'
year = 'year1'
country = 'country1'
publisher = 'publisher1'
summary = 'summary1'
picture = 'picture1'
tags = 'tagsA+tagsB+tagsD'
DbContoller.book_create_new_book(bookname, author, year, country, publisher, summary, picture, tags)


bookname = 'bookname2'
author = 'author2'
year = 'year2'
country = 'country2'
publisher = 'publisher2'
summary = 'summary2'
picture = 'picture2'
tags = 'tagsD'
DbContoller.book_create_new_book(bookname, author, year, country, publisher, summary, picture, tags)


bookname = 'bookname3'
author = 'author3'
year = 'year3'
country = 'country3'
summary = 'summary3'
publisher = 'publisher3'
picture = 'picture3'
tags = 'tagsA+tagsB+tagsC'
DbContoller.book_create_new_book(bookname, author, year, country, publisher, summary, picture, tags)


bookname = 'bookname4'
author = 'author4'
year = 'year4'
country = 'country4'
summary = 'summary4'
publisher = 'publisher4'
picture = 'picture4'
tags = 'tagsB'
DbContoller.book_create_new_book(bookname, author, year, country, publisher, summary, picture, tags)


bookname = 'bookname5'
author = 'author5'
year = 'year5'
country = 'country5'
summary = 'summary5'
publisher = 'publisher5'
picture = 'picture5'
tags = 'tagsB+tagsC'
DbContoller.book_create_new_book(bookname, author, year, country, publisher, summary, picture, tags)


bookname = 'bookname6'
author = 'author6'
year = 'year6'
country = 'country6'
summary = 'summary6'
publisher = 'publisher6'
picture = 'picture6'
tags = 'tagsB+tagsC+tagsE'
DbContoller.book_create_new_book(bookname, author, year, country, publisher, summary, picture, tags)


bookname = 'bookname8'
author = 'author8'
year = 'year8'
country = 'country8'
summary = 'summary8'
publisher = 'publisher8'
picture = 'picture8'
tags = 'tagsB+tagsC'
DbContoller.book_create_new_book(bookname, author, year, country, publisher, summary, picture, tags)

bookname = 'bookname9'
author = 'author9'
year = 'year9'
country = 'country9'
summary = 'summary9'
publisher = 'publisher9'
picture = 'picture9'
tags = 'tagsB+tagsC'
DbContoller.book_create_new_book(bookname, author, year, country, publisher, summary, picture, tags)

bookname = 'bookname10'
author = 'author10'
year = 'year10'
country = 'country10'
summary = 'summary10'
publisher = 'publisher10'
picture = 'picture10'
tags = 'tagsB+tagsC+tagsE'
DbContoller.book_create_new_book(bookname, author, year, country, publisher, summary, picture, tags)

i = 0
while i < 10:
    DbContoller.read_create_new_record("1", str(i), "review", str(i / 2), "", "")
    DbContoller.book_update_the_rating(str(i))
    i += 1
    
DbContoller.read_create_new_record("2", "1", "review", "2", "", "")
DbContoller.book_update_the_rating("1")

DbContoller.collections_create_and_link_new_collection("1", "first collection", "pic", "my first books", "", ["1", "2", "3","4","5"])

DbContoller.collections_create_and_link_new_collection("1", "2nd collection", "pic", "my 2nd books", "", ["2"])

