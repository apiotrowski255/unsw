import React, { useEffect, useState } from "react";
import axios from "axios";
import config from "../config";
import {
  picture0,
  picture1,
  picture2,
  picture3,
  picture4,
  picture5,
  picture6,
  picture7,
} from "../images/images";
import { Card } from "@mui/material";
import { useLocation } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import { Paper, Button } from "@mui/material";
import Container from "@mui/material/Container";

import UserSettingsForm from "../components/User/UserSettingsForm";
import ResultGrid from "../components/results/ResultGrid";
import { getUserId } from "../Helpers";

// custom css
import "./user.css";

// The images
const images = [
  picture0,
  picture1,
  picture2,
  picture3,
  picture4,
  picture5,
  picture6,
  picture7,
];

/*
The user page
 */
export default function User() {
  // The default values
  const [profileDetails, setProfileDetails] = useState({
    profile_id: -1,
    profile_role: "Regular User",
    profile_username: "username",
    profile_birthday: "No birthday has been set",
    profile_self_intro: "",
    profile_email: "",
    profile_picture: "1",
    profile_status: "Online",
    profile_goal: "No goal has been set",
  });
  // The collections the user has
  const [collectionResults, setCollectionResults] = useState({
    collections: null,
  });
  // Whether the user is following the user
  const [followResults, setFollowResults] = useState({
    isFollowing: null,
  });
  // Gets the image of the user
  const getImage = (user_image) => {
    if (
      user_image === "0" ||
      user_image === "1" ||
      user_image === "2" ||
      user_image === "3" ||
      user_image === "4" ||
      user_image === "5" ||
      user_image === "6" ||
      user_image === "7"
    ) {
      user_image = images[parseInt(user_image)];
    } else {
      // default to using user_image 0
      user_image = images[0];
    }
    return user_image;
  };
  // The default image is 1
  const image = getImage("1");
  // Gets the user id from the url
  const location = useLocation();
  let userId = location.pathname.split("/").pop();
  const isMyProfile = userId === "user";
  // Checks whether we are viewing the default (the users page)
  if (userId === "user") {
    userId = getUserId();
  }
  const updateResults = () => {
    axios
      .get(`${config.backendurl}/api/user/collection/show`, {
        params: {
          uid: userId,
        },
      })
      .then((r) => {
        // Stores the collection data
        if (r.data.error === "None") {
          setCollectionResults(r.data);
        } else {
          setCollectionResults({ collections: [] });
        }
      })
      .catch((err) => {
        console.log("Error", err);
      });
  };
  // Gets the latest read/reviewed books of the user
  const getLatestReads = () => {
    axios
      .get(`${config.backendurl}/api/user/get_latest_reviews`, {
        params: {
          uid: userId,
        },
      })
      .then((r) => {
        if (r.data.error === "None") {
          setRecentBooks({ books: r.data.books });
        } else {
          setRecentBooks({ books: [] });
        }
      })
      .catch((err) => {
        console.log("Error", err);
      });
  };
  // Gets the users details and stores them
  const get_profile_user_details = () => {
    if (profileDetails.profile_id === -1) {
      axios
        .post(`${config.backendurl}/api/full_details`, {
          user_id: userId,
        })
        .then((response) => {
          setProfileDetails({
            profile_id: response.data.user[0],
            profile_role:
              response.data.user[1] === ""
                ? "Regular user"
                : response.data.user[1],
            profile_username: response.data.user[3],
            profile_birthday:
              response.data.user[4] === ""
                ? "No birthday has been set"
                : response.data.user[4],
            profile_self_intro: response.data.user[5],
            profile_email: response.data.user[6],
            profile_picture:
              response.data.user[7] === null ? "1" : response.data.user[7],
            profile_status: response.data.user[8],
            profile_goal:
              response.data.user[9] === null
                ? "No goal has been set"
                : response.data.user[9],
          });
        });
      // Updates everything
      updateResults();
      checkFollowing();
      getLatestReads();
    }
  };
  useEffect(get_profile_user_details);
  // Checks whether the user is following the user they are viewing
  const checkFollowing = () => {
    axios
      .get(`${config.backendurl}/api/checkfollowship`, {
        params: {
          uid1: getUserId(),
          uid2: userId,
        },
      })
      .then((r) => {
        setFollowResults({
          isFollowing: r.data.msg,
        });
      });
  };
  // Stores the recent books
  const [recentBooks, setRecentBooks] = useState([]);
  // When the user clicks on follow user
  const followUser = (event) => {
    event.preventDefault();
    if (getUserId() === profileDetails.profile_id) {
      window.alert("Unable to follow yourself");
    } else {
      axios
        .post(`${config.backendurl}/api/follow`, {
          uid: localStorage.getItem("user_id"),
          uid_following: profileDetails.profile_id,
        })
        .then((r) => {
          console.log(r.data);
        })
        .catch((err) => {
          console.log("Error", err);
        });
    }
    setFollowResults({
      isFollowing: true,
    });
  };
  // When the user clicks unfollows the user
  const unfollowUser = (event) => {
    event.preventDefault();

    axios
      .post(`${config.backendurl}/api/unfollow`, {
        uid: localStorage.getItem("user_id"),
        uid_following: profileDetails.profile_id,
      })
      .then((r) => {
        console.log(r.data);
      })
      .catch((err) => {
        console.log("Error", err);
      });
    setFollowResults({
      isFollowing: false,
    });
  };

  return (
    <Container>
      <Card sx={{ minWidth: 275, margin: 2 }}>
        <CardContent>
          <div className="imageNextText">
            <div className="image">
              <img
                src={image}
                width="200"
                height="200"
                alt="User Profile Image"
              />
            </div>
            <div className="text">
              <h1>{profileDetails.profile_username}</h1>
              <div>
                {profileDetails.profile_self_intro !== "None" && (
                  <Typography>
                    Self introduction: {profileDetails.profile_self_intro}
                  </Typography>
                )}
                <Typography>
                  Monthly goal: {profileDetails.profile_goal} per month!
                </Typography>
              </div>
            </div>
          </div>
          <Typography sx={{ fontSize: 14 }} color="text.secondary" gutterBottom>
            Email: {profileDetails.profile_email}
          </Typography>
          <Typography sx={{ fontSize: 14 }} color="text.secondary" gutterBottom>
            Birthday: {profileDetails.profile_birthday}
          </Typography>
        </CardContent>
        <CardActions>
          {!isMyProfile && !followResults.isFollowing && (
            <Button size="medium" variant="outlined" onClick={followUser}>
              Follow
            </Button>
          )}
          {!isMyProfile && followResults.isFollowing && (
            <Button size="medium" variant="outlined" onClick={unfollowUser}>
              Unfollow
            </Button>
          )}
        </CardActions>
      </Card>

      <Card sx={{ minWidth: 275, margin: 2 }}>
        <CardContent>
          <Typography sx={{ fontSize: 20, mb: -1.2 }}>Recent Reads</Typography>
        </CardContent>
      </Card>

      {/* Recent reads as a grid*/}
      <Container sx={{ py: 4 }} maxWidth="md">
        <ResultGrid results={recentBooks} />
      </Container>

      <br></br>

      <Card sx={{ minWidth: 275, margin: 2 }}>
        <CardContent>
          <Typography sx={{ fontSize: 20, mb: -1.2 }}>Collections</Typography>
        </CardContent>
      </Card>

      {/* all the collections the user has */}
      <Container sx={{ py: 4 }} maxWidth="md">
        <ResultGrid results={collectionResults} />
      </Container>

      {isMyProfile && (
        <UserSettingsForm
          userId={userId}
          profileDetails={profileDetails}
          setProfileDetails={setProfileDetails}
        />
      )}
    </Container>
  );
}
