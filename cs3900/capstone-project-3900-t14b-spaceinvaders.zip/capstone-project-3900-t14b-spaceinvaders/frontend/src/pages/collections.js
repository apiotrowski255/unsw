import React, { useEffect, useState } from "react";
import axios from "axios";
import config from "../config";
import ResultGrid from "../components/results/ResultGrid";
import { Fab, Menu, TextField } from "@mui/material";
import AddIcon from "@mui/icons-material/Add";
import Typography from "@mui/material/Typography";
import MenuItem from "@mui/material/MenuItem";
import Button from "@mui/material/Button";
import { useLocation } from "react-router-dom";
import { getUsername, getUserId } from "../Helpers";

export default function Collections() {
  const [results, setResults] = useState({
    collections: null,
  });

  const [anchorEl, setAnchorEl] = useState(null);
  const [newCollectionName, setNewCollectionName] = useState("");
  const location = useLocation();
  // Gets the id of the book from the url
  const collectionId = location.pathname.split("/").pop();
  let userId = collectionId;
  if (collectionId === "collections") {
    userId = getUserId();
  }

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };
  const updateResults = () => {
    axios
      .get(`${config.backendurl}/api/user/collection/show`, {
        params: {
          uid: userId,
        },
      })
      .then((r) => {
        console.log(r.data);
        if (r.data.error === "None") {
          setResults(r.data);
        } else {
          setResults({ books: [] });
        }
      })
      .catch((err) => {
        console.log("Error", err);
      });
  };

  useEffect(() => {
    if (
      results.collections === null ||
      (results.collection != null && results.collections.length === 0)
    ) {
      updateResults();
    }
  });
  const newCollection = () => {
    axios
      .post(`${config.backendurl}/api/user/collection/create`, {
        username: getUsername(),
        collection_name: newCollectionName,
        picture: "",
        comments: "",
        tags: "",
        list_bids: [],
      })
      .then((r) => {
        console.log(r.data);
        if (r.data.error === "None") {
          setResults(r.data);
        } else {
          setResults({ books: [] });
        }
        updateResults();
      })
      .catch((err) => {
        console.log("Error", err);
      });
  };

  const handleChange = (event) => {
    setNewCollectionName(event.target.value);
  };
  return (
    <div>
      <ResultGrid results={results} />
      <Fab
        style={{ position: "absolute", bottom: 16, right: 16 }}
        onClick={handleClick}
        color="primary"
        aria-label="add"
      >
        <AddIcon />
      </Fab>
      <Menu
        anchorEl={anchorEl}
        keepMounted
        open={!!anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "center",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "right",
        }}
      >
        <MenuItem>
          <TextField
            value={newCollectionName}
            onChange={handleChange}
            label="Collection name"
          />
        </MenuItem>
        <MenuItem>
          <Button onClick={newCollection}>Create Collection</Button>
        </MenuItem>
      </Menu>
    </div>
  );
}
