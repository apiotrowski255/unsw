import axios from "axios";
import React, { useEffect, useState } from "react";
import config from "../config";
import Container from "@mui/material/Container";
import ResultGrid from "../components/results/ResultGrid";
import { getUserId } from "../Helpers";

/*
Following page for showing the users the user follows
 */
export default function Following() {
  // Stores the following users
  const [followingResults, setFollowingResults] = useState({
    set: -1,
    followings: null,
  });

  const updateResults = () => {
    if (followingResults.set === -1) {
      axios
        .get(`${config.backendurl}/api/checkfollowing`, {
          params: {
            uid: getUserId(),
          },
        })
        .then((r) => {
          if (r.data.error === "None") {
            setFollowingResults({ followings: r.data.following, set: 1 });
          } else {
            setFollowingResults({ followings: [] });
          }
        })
        .catch((err) => {
          console.log("Error", err);
        });
    }
  };
  useEffect(updateResults);
  return (
    <div>
      <h1>Following</h1>

      <Container sx={{ py: 4 }} maxWidth="md">
        <ResultGrid results={followingResults} />
      </Container>
    </div>
  );
}
