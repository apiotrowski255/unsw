import React, { useEffect, useState } from "react";
import axios from "axios";
import config from "../config";
import ResultGrid from "../components/results/ResultGrid";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import MenuItem from "@mui/material/MenuItem";
import Alert from "@mui/material/Alert";
import Grid from "@mui/material/Grid";
import { getUserId } from "../Helpers";
// Tags textmenu
const tags = [
  {
    value: "Fiction",
    label: "Fiction",
  },
  {
    value: "Biography",
    label: "Biography",
  },
  {
    value: "Crime",
    label: "Crime",
  },
  {
    value: "Religion",
    label: "Religion",
  },
  {
    value: "Non-Fiction",
    label: "Non-Fiction",
  },
  {
    value: "History",
    label: "History",
  },
  {
    value: "Business & Economics",
    label: "Business & Economics",
  },
];
/*
The discover/recommended books page
 */
export default function Discover() {
  const [results, setResults] = useState({
    books: [],
  });
  // Alert for if user has no inputs for recommend
  const [alert, setAlert] = useState(false);
  const [errorContent, setErrorContent] = useState("");
  // Default state is to recommend random books
  const [recMode, setRecMode] = useState("random");
  const [tag, setTag] = useState("Fiction");
  // Handle change in the recommender mode
  const handleSelectMode = (event) => {
    setRecMode(event.target.value);
  };
  // Handle tage change
  const handleChange = (event) => {
    event.preventDefault();
    setTag(event.target.value);
    setRecMode("tag");
  };
  // Gets the recommended books updated
  const updateResults = () => {
    axios
      .get(`${config.backendurl}/api/browse`, {
        params: {
          tag: tag,
          mode: recMode,
          uid: getUserId(),
        },
      })
      .then((r) => {
        console.log(r.data);
        if (r.data.error === "None") {
          setResults(r.data);
          setAlert(true);
        } else {
          setResults({ books: [] });
          setAlert(true);
        }
        setErrorContent(r.data.error);
      })
      .catch((error) => {
        alert(error);
      });
  };

  useEffect(
    () => {
      {
        updateResults();
      }
    },
    //Dependancy Array
    [recMode, tag]
  );
  return (
    <div>
      <Grid
        direction="column"
        alignItems="center"
        justifyContent="center"
        spacing={5}
        style={{ padding: "10px" }}
      >
        <TextField
          id="Select Tag"
          select
          label="Recommendation scheme"
          value={recMode}
          onChange={handleSelectMode}
          style={{ padding: "10px", width: "200px" }}
        >
          <MenuItem key="tag" value="tag">
            Tag
          </MenuItem>
          <MenuItem key="followers" value="following">
            Following
          </MenuItem>
          <MenuItem key="rating" value="rating">
            Previous reads
          </MenuItem>
          <MenuItem key="random" value="random">
            Random
          </MenuItem>
        </TextField>

        <TextField
          id="Select Tag"
          select
          label="Select"
          value={tag}
          onChange={handleChange}
          helperText="...or get recommended books based on a tag"
          style={{ padding: "10px" }}
        >
          {tags.map((option) => (
            <MenuItem key={option.value} value={option.value}>
              {option.label}
            </MenuItem>
          ))}
        </TextField>
      </Grid>
      {errorContent !== "None" && <Alert severity="info">{errorContent}</Alert>}
      <ResultGrid results={results} />
    </div>
  );
}
