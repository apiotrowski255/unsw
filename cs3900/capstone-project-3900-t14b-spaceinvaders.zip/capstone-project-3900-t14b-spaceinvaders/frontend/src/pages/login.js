import React, { useState } from "react";
import axios from "axios";
import config from "../config";
import { Grid, TextField } from "@mui/material";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import { useNavigate } from "react-router-dom";
// The css for the log in button
import "./login.css";

/*
The Log in page for logging in a user that has already registered
 */
export default function Login() {
  // Stores the login details
  const [values, setValues] = React.useState({
    username: "",
    password: "",
    error: false,
  });
  // Storing the changes the user makes in the text boxes
  const handleChange = (prop) => (event) => {
    setValues({ ...values, [prop]: event.target.value, ["error"]: false });
  };

  const navigate = useNavigate();
  // If the user clicks the register button redirects them to the correct page
  const registerClick = () => {
    navigate("/register");
  };
  // For when the user attempts to log in
  const handleSubmit = (event) => {
    event.preventDefault();
    axios
      .post(`${config.backendurl}/api/login`, {
        username: values.username,
        password: values.password,
      })
      .then(function (response) {
        // If the user logs in successfully stores the user details in their browser storage
        // This is a simply way of doing this without any security
        // Alternative method would be storing the JWT  with this information and having the backend decode it
        // in it but that is out of scope for this course
        if (response.data.error === "None") {
          localStorage.setItem("user_id", response.data.user_id);
          localStorage.setItem("username", response.data.username);
          localStorage.setItem("user_image", response.data.user_image);
          localStorage.setItem("role", response.data.role);
          localStorage.setItem(
            "token",
            response.data.user_id +
              response.data.username +
              response.data.user_image
          );
          navigate("/discover");
        } else {
          setValues({ ...values, ["error"]: true });
        }
      })
      .catch(function (error) {
        console.log(error);
      });
  };
  return (
    <div>
      <Grid
        container
        justifyContent="center"
        alignItems="center"
        direction="column"
        style={{ minHeight: "100vh" }}
        spacing={5}
      >
        <Grid item>
          <Typography variant="h5" color="primary">
            Login to Bookshelf
          </Typography>
        </Grid>
        <Grid item>
          <Grid
            container
            direction="column"
            alignItems="center"
            justifyContent="center"
            style={{ minWidth: "250px" }}
          >
            <TextField
              error={values.username === "" || values.error}
              helperText={
                (values.username === "" && "You must enter a username") ||
                (values.error && "Incorrect username or password")
              }
              variant="outlined"
              value={values.username}
              onChange={handleChange("username")}
              label="Username"
              fullWidth
              style={{ marginBottom: "1em" }}
            />
            <TextField
              error={values.password.length < 6}
              helperText={
                values.password.length < 6 &&
                "Password must be at least 6 characters"
              }
              variant="outlined"
              value={values.password}
              onChange={handleChange("password")}
              type="password"
              label="Password"
              fullWidth
              style={{ marginBottom: "1em" }}
            />
            <Grid item>
              <Button
                onClick={handleSubmit}
                size="large"
                variant="contained"
                color="primary"
                disabled={values.password.length < 6 || values.username === ""}
              >
                Login
              </Button>
            </Grid>
            <Grid item style={{ marginTop: "15px" }}>
              <Button
                onClick={registerClick}
                size="large"
                variant="contained"
                color="primary"
              >
                Register
              </Button>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </div>
  );
}
