import React, { useEffect, useState } from "react";
import { Card, Grid, Paper } from "@mui/material";

import Avatar from "@mui/material/Avatar";
import Typography from "@mui/material/Typography";
import StyledPaper from "../components/StyledPaper";
import BookCard from "../components/Book/BookCard";
import Review from "../components/Book/Review";
import config from "../config";
import axios from "axios";
import { useLocation } from "react-router-dom";
import Button from "@mui/material/Button";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import Alert from '@mui/material/Alert';

function getUsername() {
  return localStorage.getItem("username");
}

function getUserId() {
  return localStorage.getItem("user_id");
}

export default function AddBook() {
  const [book, setBook] = useState({
    bookname: "",
    author: "",
    year: "",
    country: "",
    publisher: "",
    summary: "",
    picture: "",
    tags: "",
  });

  const [error, setError] = useState({
    error: ""
  })

  const handleChange = (prop) => (event) => {
    setBook({ ...book, [prop]: event.target.value, ["error"]: false });
  };

  const registerClick = (event) => {
    event.preventDefault();
    axios
      .post(`${config.backendurl}/api/admin/addbook`, {
        uid: getUserId(),
        name: book.bookname,
        author: book.author,
        year: book.year,
        country: book.country,
        publishers: book.publisher,
        summary: book.summary,
        picture: book.picture,
        tags: book.tags,
      })
      .then(function (response) {
        if (response.data.error === "None") {
          setError({error: ""})
        } else {
          setError({error: "Error with adding the book - It appears you are not admin."})
        }
      })
      .catch(function (error) {
        console.log(error);
      });
  };

  return (
    <Grid
      container
      justifyContent="center"
      alignItems="left"
      direction="column"
      style={{ minHeight: "20vh" }}
      spacing={5}
      margin={5}
    >
      <Grid item>
        <Typography variant="h5" color="primary">
          Add a new book to bookShelf!
        </Typography>
      </Grid>
      <TextField
        error={book.bookname === ""}
        id="filled-basic"
        label="Book name"
        variant="filled"
        onChange={handleChange("bookname")}
        fullWidth
        style={{ marginBottom: "1em", maxWidth: 600 }}
      />
      <TextField
        error={book.author === ""}
        id="filled-basic"
        label="Author"
        variant="filled"
        onChange={handleChange("author")}
        fullWidth
        style={{ marginBottom: "1em", maxWidth: 600 }}
      />
      <TextField
        error={book.year === ""}
        id="filled-basic"
        label="year"
        variant="filled"
        onChange={handleChange("year")}
        fullWidth
        style={{ marginBottom: "1em", maxWidth: 600 }}
      />
      <TextField
        error={book.country === ""}
        id="filled-basic"
        label="Country"
        variant="filled"
        onChange={handleChange("country")}
        fullWidth
        style={{ marginBottom: "1em", maxWidth: 600 }}
      />
      <TextField
        error={book.publisher === ""}
        id="filled-basic"
        label="Publisher"
        variant="filled"
        onChange={handleChange("publisher")}
        fullWidth
        style={{ marginBottom: "1em", maxWidth: 600 }}
      />
      <TextField
        error={book.summary === ""}
        id="filled-basic"
        label="summary"
        variant="filled"
        onChange={handleChange("summary")}
        fullWidth
        style={{ marginBottom: "1em", maxWidth: 600 }}
        multiline
        rows={4}
      />
      <TextField
        error={book.picture === ""}
        id="filled-basic"
        label="link to picture"
        variant="filled"
        onChange={handleChange("picture")}
        fullWidth
        style={{ marginBottom: "1em", maxWidth: 600 }}
      />
      <TextField
        error={book.tags === ""}
        id="filled-basic"
        label="tags"
        variant="filled"
        onChange={handleChange("tags")}
        fullWidth
        style={{ marginBottom: "1em", maxWidth: 600 }}
      />
      {error.error != "" && (
        <Alert severity="error">{error.error}</Alert>
      )}
      <Grid item style={{ marginTop: "10px" }}>
        <Button
          onClick={registerClick}
          size="large"
          variant="contained"
          color="primary"
        >
          Submit book
        </Button>
      </Grid>
    </Grid>
  );
}
