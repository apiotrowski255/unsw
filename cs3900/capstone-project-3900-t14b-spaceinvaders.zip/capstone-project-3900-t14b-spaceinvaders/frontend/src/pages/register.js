import React, { useState } from "react";
import axios from "axios";
import config from "../config";
import { Grid, TextField } from "@mui/material";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import { useNavigate } from "react-router-dom";

/*
The register page with validation of the input email, username and confirmation passwords
 */
export default function Register() {
  const [values, setValues] = useState({
    email: "",
    username: "",
    password: "",
    confirmPassword: "",
    error: false,
  });

  const navigate = useNavigate();
  // Registers the user
  const register_user = () => {
    axios
      .post(`${config.backendurl}/api/register`, {
        email: values.email,
        username: values.username,
        password: values.password,
      })
      .then(function (response) {
        if (response.data.error !== "None") {
          setValues({ ...values, ["error"]: true });
        } else {
          navigate("/login");
        }
      })
      .catch(function (error) {
        console.log(error);
      });
  };
  // Handles changes to the user input
  const handleChange = (prop) => (event) => {
    setValues({ ...values, [prop]: event.target.value, ["error"]: false });
  };
  // Uses Regex to validate the email the user inputs
  const isEmailInvalid = () => {
    const pattern = new RegExp(
      /^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i
    );
    return !pattern.test(values.email);
  };

  return (
    <Grid
      container
      justifyContent="center"
      alignItems="center"
      direction="column"
      style={{ minHeight: "100vh" }}
      spacing={5}
    >
      <Grid item>
        <Typography variant="h5" color="primary">
          Register for Bookshelf
        </Typography>
      </Grid>
      <Grid item>
        <Grid
          container
          direction="column"
          alignItems="center"
          justifyContent="center"
          style={{ minWidth: "250px" }}
        >
          <TextField
            error={isEmailInvalid()}
            helperText={
              isEmailInvalid() && "Please enter a valid email address"
            }
            variant="outlined"
            value={values.email}
            onChange={handleChange("email")}
            label="Email"
            fullWidth
            style={{ marginBottom: "1em" }}
          />
          <TextField
            error={values.username === "" || values.error}
            helperText={
              (values.username === "" && "You must enter a username") ||
              (values.error && "Username has already been taken")
            }
            variant="outlined"
            value={values.username}
            onChange={handleChange("username")}
            label="Username"
            fullWidth
            style={{ marginBottom: "1em" }}
          />
          <TextField
            error={values.password.length < 6}
            helperText={
              values.password.length < 6 &&
              "Password must be at least 6 characters"
            }
            variant="outlined"
            value={values.password}
            onChange={handleChange("password")}
            type="password"
            label="Password"
            fullWidth
            style={{ marginBottom: "1em" }}
          />
          <TextField
            error={values.password !== values.confirmPassword}
            helperText={
              values.password !== values.confirmPassword &&
              "Passwords do not match"
            }
            variant="outlined"
            value={values.confirmPassword}
            onChange={handleChange("confirmPassword")}
            type="password"
            label="Confirm Password"
            fullWidth
            style={{ marginBottom: "1em" }}
          />

          <Button
            onClick={register_user}
            size="large"
            variant="contained"
            color="primary"
            disabled={
              values.password.length < 6 ||
              values.username === "" ||
              isEmailInvalid() ||
              values.password !== values.confirmPassword
            }
          >
            Register
          </Button>
        </Grid>
      </Grid>
    </Grid>
  );
}
