import React, { useEffect, useState } from "react";
import { Card, Grid } from "@mui/material";
import Typography from "@mui/material/Typography";
import ForumResult from "../components/Forum/ForumResult";
import axios from "axios";
import config from "../config";
import NewForumPost from "../components/Forum/NewForumPost";

/*
The forum page for displaying all the forum posts
 */
export default function Forum() {
  // For storing the posts in the forum
  const [posts, setPosts] = useState({ posts: [], unset: true });
  const updateResults = () => {
    axios
      .get(`${config.backendurl}/api/forum/get_posts`)
      .then((r) => {
        console.log(r.data);
        if (r.data.error === "None") {
          setPosts(r.data);
        }
      })
      .catch((error) => {
        alert(error);
      });
  };

  useEffect(() => {
    if (posts.unset) {
      updateResults();
    }
  }, [posts, setPosts]);
  return (
    <Grid style={{ padding: "10px" }}>
      <Grid item style={{ paddingTop: "10px" }}>
        <Card
          style={{
            height: "70px",
            paddingLeft: "20px",
            alignContent: "center",
            alignItems: "center",
          }}
        >
          <Typography variant="h3" component="div">
            Forum
          </Typography>
        </Card>
      </Grid>
      <Grid item>
        <NewForumPost />
      </Grid>
      {posts.posts.map((post) => {
        return (
          <Grid item>
            <ForumResult post={post} />
          </Grid>
        );
      })}
    </Grid>
  );
}
