import React, { useState } from "react";
import axios from "axios";
import config from "../config";
import { Grid, TextField } from "@mui/material";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import { getUserId } from "../Helpers";
import Alert from "@mui/material/Alert";

export default function BanUser() {
  const [values, setValues] = useState({
    user_id: "",
    confirmed: false,
  });

  const [error, setError] = useState({
    error: "",
  });

  const handleClick = (event) => {
    event.preventDefault();
    // Expects the flask url to be /api/register
    axios
      .post(`${config.backendurl}/api/admin/manage`, {
        uid: getUserId(),
        uid_to_update: values.user_id,
        new_status: "banned",
      })
      .then(function (response) {
        console.log(response);
        if (response.data.error === "None") {
          console.log("User has been banned");
          setError({ error: "" });
        } else if (response.data.error === "User is not an admin") {
          setError({ error: "You are not an admin" });
        } else {
          setError({ error: response.data.error });
        }
      })
      .catch(function (error) {
        console.log(error);
      });
  };

  const handleChange = (prop) => (event) => {
    setValues({ ...values, [prop]: event.target.value });
  };

  return (
    <Grid
      container
      justifyContent="center"
      alignItems="left"
      direction="column"
      style={{ minHeight: "10vh" }}
      spacing={5}
      margin={5}
    >
      <Grid item>
        <Typography variant="h5" color="primary">
          Banning user page
        </Typography>
      </Grid>
      <TextField
        error={values.user_id === ""}
        id="filled-basic"
        label="User Id to ban"
        variant="filled"
        onChange={handleChange("user_id")}
        fullWidth
        style={{ marginBottom: "1em", maxWidth: 600 }}
      />
      {error.error != "" && <Alert severity="error">{error.error}</Alert>}
      <Grid item style={{ marginTop: "15px" }}>
        <Button
          onClick={handleClick}
          size="large"
          variant="contained"
          color="primary"
        >
          Submit Ban
        </Button>
      </Grid>
    </Grid>
  );
}
