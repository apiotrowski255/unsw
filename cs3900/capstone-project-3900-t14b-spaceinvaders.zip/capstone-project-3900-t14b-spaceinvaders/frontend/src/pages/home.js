import React from "react";
import { Discover } from "./pages";

/*
The home page is the discover page this is just so it works logged in or not
 */
export default function Home() {
  return <Discover />;
}
