import axios from "axios";
import React, { useEffect, useState } from "react";
import config from "../config";
import { useLocation, useParams } from "react-router-dom";
import Container from "@mui/material/Container";
import ResultGrid from "../components/results/ResultGrid";
import Typography from "@mui/material/Typography";
import Alert from "@mui/material/Alert";
import { styled } from '@mui/material/styles';
import Grid from '@mui/material/Grid';
import Paper from '@mui/material/Paper';
import Box from '@mui/material/Box';


function getId() {
  return localStorage.getItem("user_id");
}


const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}));

export default function Stats() {
  const [results, setResults] = useState({
    set: -1,
    error: "None",
    total_books: -1,
    total_users: -1,
    total_collections: -1,
    avg_collections: -1,
    new_users_month: -1,
    new_collections_month: -1,
    new_follows_month: -1,
  });

  const [profileDetails, setProfileDetails] = useState({
    profile_id: -1,
    role: "None"
  });



  let userId = getId();
  const updateResults = () => {
    if (results.set === -1) {
      axios
        .get(`${config.backendurl}/api/information`, {
          params: {
            uid: userId,
            information: {},
          },
        })
        .then((r) => {

          if (r.data.error === "None") {
            setResults({
              total_books: r.data.information[0],
              total_users: r.data.information[1],
              total_collections: r.data.information[2],
              avg_collections: r.data.information[3],
              new_users_month: r.data.information[4],
              new_collections_month: r.data.information[5],
              new_follows_month: r.data.information[6],
              error: r.data.error
            });
          } else {
            console.log(results);
            setResults({...results, ['error']: r.data});
          }
          get_profile_user_details();
        })
        .catch((err) => {
          console.log("Error", err);
        });
    }
  };

  const get_profile_user_details = () => {
    console.log(profileDetails.profile_id)
    if (profileDetails.profile_id === -1) {
      axios
        .post(`${config.backendurl}/api/full_details`, {
          user_id: userId,
        })
        .then((response) => {


          setProfileDetails({
            role: response.data.user[1]
          });
        });
        //updateResults();
      }
    };
    console.log("results.error");
    console.log(results.error);



    useEffect(updateResults);

  return (
    <div>
      <h1>Statistics</h1>

      {profileDetails.role !== "admin" && <Alert severity="error">{"Need admin privileges to access this page"}</Alert>}

      {results.error === "None" && <Container sx={{ py: 4 }} maxWidth="md">
      <Box sx = {{width: '100%'}}>
      <Grid container rowSpacing={1}>
        <Grid item xs={6}>
          <Item>
            Total Books: {results.total_books}
          </Item>
        </Grid>
        <Grid item xs={6}>
          <Item>
            Total Users: {results.total_users}
          </Item>
        </Grid>
        <Grid item xs={6}>
          <Item>
            Total Collections: {results.total_collections}
            </Item>
        </Grid>
        <Grid item xs={6}>
          <Item>
          Average collections per user: {results.avg_collections}
          </Item>
      </Grid>
      </Grid>
      <Grid container2 rowSpacing={1}>
      <Grid item xs={6}>
        <Item>
          New users this month: {results.new_users_month}
          </Item>
      </Grid>
      <Grid item xs={6}>
        <Item>
          New collections made this month: {results.new_collections_month}
          </Item>
      </Grid>
      <Grid item xs={6}>
        <Item>
          New follows this month: {results.new_follows_month}
          </Item>
      </Grid>
        </Grid>
        </Box>
      </Container>}
    </div>
  );
}
