import React from "react";
import { Navigate, useLocation, useNavigate } from "react-router-dom";

// Logs out the user by removing their details from storage and redirects them to the login page
export default function Logout() {
  const logout = () => {
    localStorage.setItem("user_id", "");
    localStorage.setItem("username", "");
    localStorage.setItem("user_image", "");
    localStorage.setItem("token", "");
  };
  logout();
  let location = useLocation();
  return <Navigate to="/login" state={{ from: location }} />;
}
