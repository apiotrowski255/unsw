import React, { useEffect, useState } from "react";
import axios from "axios";
import config from "../config";
import ResultGrid from "../components/results/ResultGrid";
import { useLocation } from "react-router-dom";
import { Card, TextField } from "@mui/material";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import { getUsername } from "../Helpers";

// The collection pages for displaying the books in a collections and
// editing the title of the collection
export default function Collection() {
  const [results, setResults] = useState({
    books: null,
    unset: true,
  });
  // Stores the collection data
  const [collection, setCollection] = useState({});
  // Stores whether the user is editing the title
  const [editing, setEditing] = useState(false);
  // Stores the value of the edited title
  const [value, setValue] = useState("");

  const location = useLocation();
  // Gets the id of the collection from the url
  const collectionId = location.pathname.split("/").pop();

  // For getting the information about the collection and the books in the collection
  const updateResults = () => {
    // Gets the books in the collection
    axios
      .get(`${config.backendurl}/api/user/collection/collectionbooks`, {
        params: {
          cid: collectionId,
        },
      })
      .then((r) => {
        console.log(r.data);
        if (r.data.error === "None") {
          setResults(r.data);
        } else {
          setResults({ books: [] });
        }
      })
      .catch((err) => {
        console.log("Error", err);
      });
    // Gets the collection name and user that owns it
    axios
      .get(`${config.backendurl}/api/user/collection`, {
        params: {
          cid: collectionId,
        },
      })
      .then((r) => {
        console.log(r.data);
        if (r.data.error === "None") {
          setCollection(r.data.collections[0]);
        } else {
          setCollection({});
        }
      })
      .catch((err) => {
        console.log("Error", err);
      });
  };
  // Handles the clicking of the save/edit title button
  const handleClick = () => {
    if (!editing) {
      setValue(collection.collection_name);
      setEditing(true);
    } else {
      if (value !== "") {
        axios
          .post(`${config.backendurl}/api/user/collection/changename`, {
            cid: collection.collection_id,
            name: value,
          })
          .then((r) => {
            console.log(r.data);
          })
          .catch((err) => {
            console.log("Error", err);
          });
      }
      setEditing(false);
      setCollection((prevState) => ({
        ...prevState,
        collection_name: value,
      }));
      setTimeout(updateResults, 500);
    }
  };
  // Stores the value as the user types in the new name
  const handleChange = (event) => {
    setValue(event.target.value);
  };

  useEffect(() => {
    if (results.books === null) {
      updateResults();
    }
  });
  return (
    <div>
      <Card style={{ padding: "10px", margin: "10px" }}>
        {!editing && (
          <Typography variant="h3" component="div">
            {collection.collection_name}
          </Typography>
        )}
        {editing && (
          <TextField
            fullWidth
            InputProps={{ style: { fontSize: 40 } }}
            value={value}
            onChange={handleChange}
          />
        )}
        {collection.username === getUsername() && (
          <Button onClick={handleClick}>
            {!editing && "Edit name"}
            {editing && "Save"}
          </Button>
        )}
      </Card>
      <ResultGrid
        results={results}
        owner={collection.username}
        cid={collection.collection_id}
      />
    </div>
  );
}
