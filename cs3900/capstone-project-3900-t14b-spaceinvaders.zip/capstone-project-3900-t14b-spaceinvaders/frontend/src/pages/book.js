import React, { useEffect, useState } from "react";
import { Grid } from "@mui/material";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import StyledPaper from "../components/StyledPaper";
import BookCard from "../components/Book/BookCard";
import Review from "../components/Book/Review";
import config from "../config";
import axios from "axios";
import { useLocation } from "react-router-dom";
import Button from "@mui/material/Button";
import ReviewForm from "../components/Book/ReviewForm";
import { getUsername } from "../Helpers";

/*
The book page shows information for the book given the id of the book is in the url
 */
export default function Book() {
  // Default state of the page before it retrieves the info from the backend
  const [book, setBook] = useState({
    name: "",
    author: "",
    publisher: "",
    bid: -1,
    rating: "",
    summary: "",
    reads: 0,
    tags: [],
    reviews: [],
  });
  // Stores whether the user has reviewed the book already
  const [hasReviewed, setHasReviewed] = useState(false);
  const location = useLocation();
  // Gets the id of the book from the url
  const bookId = location.pathname.split("/").pop();
  // Calls the backend for the information
  const updateBookInfo = () => {
    axios
      .get(`${config.backendurl}/api/book?bid=${bookId}`)
      .then((r) => {
        console.log(r.data);
        if (r.data.error === "None") {
          setBook(r.data.book);
          // Loops through the reviews to see if the user has already reviewed the book
          r.data.book.reviews.map((review) => {
            if (review.username === getUsername()) {
              setHasReviewed(true);
            }
          });
        }
      })
      .catch((err) => {
        console.log("Error", err);
      });
  };
  // Stores whether the user is currently writing a review
  const [reviewing, setReviewing] = useState(false);
  // Resets the reviewing state
  const resetReviewing = () => {
    setReviewing(false);
    updateBookInfo();
  };
  // Gets the books information
  useEffect(() => {
    if (book.bid === -1) {
      updateBookInfo();
    }
  });
  return (
    <Box sx={{ flexGrow: 1, overflow: "hidden", px: 3 }}>
      <BookCard book={book} />

      <StyledPaper
        sx={{
          my: 1,
          mx: "auto",
          p: 2,
        }}
      >
        <Grid container wrap="nowrap" justifyContent="space-between">
          <Typography variant="h5" component="div">
            Reviews
          </Typography>
          <Button
            disabled={hasReviewed}
            onClick={() => {
              if (!hasReviewed) {
                setReviewing(!reviewing);
              } else {
                setReviewing(false);
              }
            }}
          >
            Write a review
          </Button>
        </Grid>
      </StyledPaper>
      {reviewing && <ReviewForm book={book} resetReviewing={resetReviewing} />}
      {book.reviews.map((review) => {
        return <Review key={review.username} review={review} />;
      })}
    </Box>
  );
}
