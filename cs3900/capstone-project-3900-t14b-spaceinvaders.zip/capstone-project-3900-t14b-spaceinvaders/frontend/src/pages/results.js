import React, { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import axios from "axios";
import config from "../config";
import ResultGrid from "../components/results/ResultGrid";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";

/*
The results or search page
 */
export default function Results() {
  // The params of the page which includes the search term
  const [searchParams, setSearchParams] = useSearchParams();
  const search = searchParams.get("search");
  // The sort by profile
  const [sortBy, setSortBy] = useState("name");
  // Stores the last requested sort by so when the sortby is changed it can call the backend for an update
  const [lastSortBy, setLastSortBy] = useState("none");

  // Handling the changing of the sortby
  const handleChangeSort = (event) => {
    setSortBy(event.target.value);
  };
  // Default empty results
  const [results, setResults] = useState({
    books: [],
    collections: [],
    users: [],
  });

  const [lastSearch, setLastSearch] = useState("");

  const updateResults = () => {
    axios
      .get(`${config.backendurl}/api/search?term=${search}&sortby=${sortBy}`)
      .then((r) => {
        console.log(r.data);
        if (r.data.error === "None") {
          setResults(r.data);
        } else {
          setResults({ books: [] });
        }
        setLastSearch(search);
        setLastSortBy(sortBy);
      })
      .catch((err) => {
        console.log("Error", err);
      });
  };

  useEffect(() => {
    if (search !== lastSearch || sortBy !== lastSortBy) {
      updateResults();
    }
  });

  return (
    <div>
      <div style={{ margin: "20px", width: "200px" }}>
        <FormControl fullWidth>
          <InputLabel id="demo-simple-select-label">Sort by</InputLabel>
          <Select
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            value={sortBy}
            label="Sort by"
            onChange={handleChangeSort}
          >
            <MenuItem value="name">Name</MenuItem>
            <MenuItem value="author">Author</MenuItem>
            <MenuItem value="rating">Rating</MenuItem>
            <MenuItem value="year">Year</MenuItem>
          </Select>
        </FormControl>
      </div>
      <ResultGrid results={results} />
    </div>
  );
}
