import Login from "./login";
import Register from "./register";
import Discover from "./discover";
import Book from "./book";
import AddBook from "./addbook";
import Collection from "./collection";
import Following from "./following";
import Follower from "./follower";
import ForumPost from "./forumpost";
import Forum from "./forum";
import User from "./user";
import BanUser from "./banuser"
import Home from "./home";
import Collections from "./collections";
import Logout from "./logout";
import Stats from "./stats"

// Stores all the pages available for easier import in the App.js

export {
    Login,
    Register,
    Discover,
    AddBook,
    Book,
    Collection,
    Following,
    Follower,
    ForumPost,
    Forum,
    User,
    BanUser,
    Home,
    Collections,
    Logout,
    Stats
}
