import React, { useEffect, useState } from "react";
import { Card, Grid, TextField } from "@mui/material";
import Typography from "@mui/material/Typography";
import ForumComment from "../components/Forum/ForumComment";
import axios from "axios";
import config from "../config";
import { useLocation, useNavigate } from "react-router-dom";
import NewForumComment from "../components/Forum/NewForumComment";
import IconButton from "@mui/material/IconButton";
import EditIcon from "@mui/icons-material/Edit";
import DoneIcon from "@mui/icons-material/Done";
import DeleteOutlinedIcon from "@mui/icons-material/DeleteOutlined";
import { getUserId, getUsername } from "../Helpers";

/*
The forum post page for commenting on a post and viewing the contents of the post
Includes editting and reporting posts/comments
 */
export default function ForumPost() {
  // Stores the post details and comments
  const [post, setPost] = useState({
    post: {},
    comments: [],
    unset: true,
  });
  // Gets the id of the post from the url
  const location = useLocation();
  const postId = location.pathname.split("/").pop();

  // Gets the post details
  const updateResult = () => {
    axios
      .get(`${config.backendurl}/api/forum/post/search`, {
        params: { pid: postId },
      })
      .then((r) => {
        console.log(r.data);
        if (r.data.error === "none") {
          setPost(r.data);
          setEditContent(r.data.post.content);
        }
      })
      .catch((error) => {
        alert(error);
      });
  };
  // Stores whether the user is editting the post
  const [editting, setEditting] = useState(false);
  // Stores the new contents of the post
  const [editContent, setEditContent] = useState(post.post.content);
  // Handles storing the new contents
  const handleEditContent = (e) => {
    setEditContent(e.target.value);
  };
  // Handles the presses of the edit/confirm button
  const handleEdit = (e) => {
    if (editting && editContent !== "") {
      axios
        .post(`${config.backendurl}/api/forum/post/edit`, {
          uid: getUserId(),
          pid: postId,
          new_content: editContent,
        })
        .then((r) => {
          console.log(r.data);
          window.location.reload(false);
        })
        .catch((err) => {
          console.log("Error", err);
        });
    }

    setEditting(!editting);
  };
  // For navigating back to the forum page when a post is deleted
  const navigate = useNavigate();
  const deletePost = (e) => {
    axios
      .post(`${config.backendurl}/api/forum/post/delete`, {
        uid: getUserId(),
        pid: postId,
      })
      .then((r) => {
        console.log(r.data);
        navigate(`/forum`);
      })
      .catch((err) => {
        console.log("Error", err);
      });
  };
  // Gets the post information and its comments
  useEffect(
    () => {
      if (post.unset) {
        updateResult();
      }
    },
    //Dependancy Array
    [post, setPost]
  );
  return (
    <Grid style={{ padding: "10px" }}>
      <Grid item style={{ paddingTop: "10px" }}>
        <Card
          style={{
            padding: "15px",
            alignContent: "center",
            alignItems: "center",
          }}
        >
          <Grid container direction="column" alignContent="space-between">
            <Grid item>
              <Typography
                variant="h4"
                component="div"
                style={{ fontWeight: 600 }}
              >
                {post.post.title}
              </Typography>
            </Grid>
            <Grid item>
              {!editting && (
                <Typography variant="h7" component="div">
                  {post.post.content}
                </Typography>
              )}
              {editting && (
                <TextField value={editContent} onChange={handleEditContent} />
              )}
            </Grid>

            <Grid item style={{ position: "absolute", right: "20px" }}>
              {post.post.username === getUsername() && (
                <div>
                  <IconButton onClick={handleEdit}>
                    {!editting && <EditIcon />}
                    {editting && <DoneIcon />}
                  </IconButton>
                  <IconButton onClick={deletePost}>
                    <DeleteOutlinedIcon />
                  </IconButton>
                </div>
              )}
            </Grid>
            <Grid item>
              <Typography
                variant="h8"
                component="div"
                style={{ color: "grey" }}
              >
                By {post.post.username}
              </Typography>
            </Grid>
          </Grid>
        </Card>
      </Grid>
      <NewForumComment pid={postId} />
      {post.comments.map((comment) => {
        return (
          <Grid key={comment.comment_id} item>
            <ForumComment comment={comment} />
          </Grid>
        );
      })}
    </Grid>
  );
}
