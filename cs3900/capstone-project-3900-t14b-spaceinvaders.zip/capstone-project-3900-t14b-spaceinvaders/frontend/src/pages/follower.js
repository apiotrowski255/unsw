import axios from "axios";
import React, { useEffect, useState } from "react";
import config from "../config";
import { useLocation, useParams } from "react-router-dom";
import Container from "@mui/material/Container";
import ResultGrid from "../components/results/ResultGrid";
import { getUserId } from "../Helpers";

/*
The followers page for displaying who follows the user
 */
export default function Follower() {
  // The Storing of all the followers
  const [followerResults, setFollowerResults] = useState({
    set: -1,
    followings: null,
  });
  // Updates the list of followers if its not set yet
  const updateResults = () => {
    if (followerResults.set === -1) {
      axios
        .get(`${config.backendurl}/api/checkfollower`, {
          params: {
            uid: getUserId(),
          },
        })
        .then((r) => {
          if (r.data.error === "None") {
            setFollowerResults({ followings: r.data.following, set: 1 });
          } else {
            setFollowerResults({ followings: [] });
          }
        })
        .catch((err) => {
          console.log("Error", err);
        });
    }
  };
  useEffect(updateResults);

  return (
    <div>
      <h1>Followers</h1>

      <Container sx={{ py: 4 }} maxWidth="md">
        <ResultGrid results={followerResults} />
      </Container>
    </div>
  );
}
