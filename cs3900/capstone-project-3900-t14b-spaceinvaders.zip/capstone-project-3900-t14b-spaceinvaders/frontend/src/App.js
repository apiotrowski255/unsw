import React from "react";
import { Routes, Route } from "react-router-dom";
import "./App.css";
import {
  Login,
  Register,
  Discover,
  AddBook,
  Book,
  Collection,
  Following,
  Follower,
  ForumPost,
  Forum,
  BanUser,
  User,
  Home,
  Collections,
  Logout,
  Stats,
} from "./pages/pages";
import Navbar from "./components/navbar";
import PrivateRoute from "./components/PrivateRoute";
import Results from "./pages/results";

/* Defines all the routes of the app ie the urls available*/
function App() {
  return (
    <div>
      <Navbar />
      <Routes>
        {/* The Login page */}
        <Route path="/login" element={<Login />} />
        {/* The register page */}
        <Route path="/register" element={<Register />} />
        {/* The logout page */}
        <Route
          path="/logout"
          element={
            <PrivateRoute>
              <Logout />
            </PrivateRoute>
          }
        />
        {/* The discover page */}
        <Route path="/discover" element={<Discover />} />
        {/* The search results page */}
        <Route path="/results" element={<Results />} />
        {/* Add book page*/}
        <Route path="/addbook" element={
            <PrivateRoute>
              <AddBook />
            </PrivateRoute>} />
        {/* A book page */}
        <Route path="/book/:id" element={<Book />} />
        {/* A collection page */}
        <Route path="/collection/:id" element={<Collection />} />
        {/* A collections page */}
        <Route path="/collections" element={<Collections />} />
        <Route path="/collections/:id" element={<Collections />} />
        {/* A following page */}
        <Route
          path="/following"
          element={
            /* Some routes are private so are enclosed with the Private route to ensure only logged in users can access them*/
            <PrivateRoute>
              <Following />
            </PrivateRoute>
          }
        />
        {/* A following page */}
        <Route
          path="/followers"
          element={
            <PrivateRoute>
              <Follower />
            </PrivateRoute>
          }
        />
        {/* A forum post page */}
        <Route
          path="/forum/:id"
          element={
            <PrivateRoute>
              <ForumPost />
            </PrivateRoute>
          }
        />
        {/* A forum page only registered users can access the forum */}
        <Route
          path="/forum"
          element={
            <PrivateRoute>
              <Forum />
            </PrivateRoute>
          }
        />
        <Route
          path="/admin/stats"
          element={
            <PrivateRoute>
              <Stats />
            </PrivateRoute>
          }
        />
        {/* Other users pages will be this one */}
        <Route path="/user/:id" element={<User />} />
        {/* The current users page will be this one */}
        <Route
          path="/user"
          element={
            <PrivateRoute>
              <User />
            </PrivateRoute>
          }
        />
         <Route path="/banuser" element={
           <PrivateRoute>
          <BanUser/>
          </PrivateRoute>} />
        <Route path="/" element={<Home />} />
      </Routes>
    </div>
  );
}

export default App;
