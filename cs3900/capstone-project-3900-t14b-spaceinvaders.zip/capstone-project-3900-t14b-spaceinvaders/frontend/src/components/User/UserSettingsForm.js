import { Button, TextField } from "@mui/material";
import React, { useState } from "react";
import axios from "axios";
import config from "../../config";

export default function UserSettingsForm({
  userId,
  profileDetails,
  setProfileDetails,
}) {
  const [formValues, setValues] = useState({
    password: "",
    birthday: "",
    self_intro: "",
    goal: "",
    error: false,
  });

  const getNextImage = () => {
    var currentImage = profileDetails.profile_picture;
    var nextImage = parseInt(currentImage) + 1;
    if (nextImage > 7) {
      nextImage = 0;
    }
    nextImage = String(nextImage);
    return nextImage;
  };

  function setSelfIntro(selfIntro) {
    axios
      .post(`${config.backendurl}/api/setSelfIntro`, {
        userId: userId,
        userSelfIntro: selfIntro,
      })
      .then((response) => {
        console.log(response.data);
        setProfileDetails({
          ...profileDetails,
          ["profile_self_intro"]: selfIntro,
        });
      });
  }

  function setBirthday(birthday) {
    axios
      .post(`${config.backendurl}/api/set_birthday`, {
        userId: userId,
        user_birthday: birthday,
      })
      .then((response) => {
        console.log(response.data);
        setProfileDetails({
          ...profileDetails,
          ["profile_birthday"]: birthday,
        });
      });
  }

  function setPassword(password) {
    axios
      .post(`${config.backendurl}/api/passwordChange`, {
        userId: userId,
        newPassword: password,
      })
      .then((response) => {
        console.log(response.data);
      });
  }

  function setGoal(goal) {
    axios
      .post(`${config.backendurl}/api/user/set_goal`, {
        username: profileDetails.profile_username,
        goal: goal,
      })
      .then((response) => {
        console.log(response.data);
        setProfileDetails({
          ...profileDetails,
          ["profile_goal"]: goal,
        });
      });
  }

  const handleChange = (prop) => (event) => {
    setValues({ ...formValues, [prop]: event.target.value, ["error"]: false });
  };
  const changeImage = (event) => {
    event.preventDefault();
    axios
      .post(`${config.backendurl}/api/setImage`, {
        userId: userId,
        user_image: getNextImage(),
      })
      .then(function (response) {
        if (response.data.error === "None") {
          setProfileDetails({
            ...profileDetails,
            ["user_image"]: response.data.user_image,
          });
        } else {
        }
      })
      .catch(function (error) {
        console.log(error);
      });
  };

  const changeBio = (event) => {
    event.preventDefault();
    setSelfIntro(formValues.self_intro);
  };

  const changeBirthday = (event) => {
    event.preventDefault();
    setBirthday(formValues.birthday);
  };

  const changePassword = (event) => {
    event.preventDefault();
    setPassword(formValues.password);
  };

  const changeGoal = (event) => {
    event.preventDefault();
    setGoal(formValues.goal);
  };

  const isNumberInvalid = () => {
    const pattern = new RegExp("[0-9]+", "g");
    return !pattern.test(formValues.goal);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    axios
      .post(`${config.backendurl}/api/passwordChange`, {
        userId: userId,
        newPassword: "123456",
      })
      .then(function (response) {
        if (response.data.error === "None") {
        } else {
        }
      })
      .catch(function (error) {
        console.log(error);
      });
  };

  return (
    <div>
      <h2>Edit profile</h2>
      <br />
      <TextField
        variant="outlined"
        type="password"
        label="Change Password"
        size="small"
        onChange={handleChange("password")}
        fullWidth
        style={{ marginBottom: "1em", maxWidth: 250 }}
      />
      <Button
        onClick={changePassword}
        size="large"
        variant="contained"
        color="primary"
      >
        Change Password
      </Button>
      <br />
      <TextField
        variant="outlined"
        type="text"
        label="Change birthday"
        size="small"
        defaultValue={profileDetails.profile_birthday}
        onChange={handleChange("birthday")}
        style={{ marginBottom: "1em", maxWidth: 500 }}
      />
      <Button
        onClick={changeBirthday}
        size="large"
        variant="contained"
        color="primary"
      >
        Change Birthday
      </Button>
      <br />
      <TextField
        variant="outlined"
        type="bio"
        label="Change Bio"
        size="small"
        multiline
        rows={4}
        defaultValue={profileDetails.profile_self_intro}
        onChange={handleChange("self_intro")}
        fullWidth
        style={{ marginBottom: "1em", maxWidth: 500 }}
      />
      <Button
        onClick={changeBio}
        size="large"
        variant="contained"
        color="primary"
      >
        Change Bio
      </Button>
      <br />
      <TextField
        variant="outlined"
        error={isNumberInvalid()}
        helperText={
          isNumberInvalid() &&
          "Please enter a number of books you would like to set as a goal per month"
        }
        defaultValue="0"
        type="number"
        label="Change Goal"
        onChange={handleChange("goal")}
        size="small"
        style={{ marginBottom: "1em", maxWidth: 250 }}
      />
      <Button
        onClick={changeGoal}
        size="large"
        variant="contained"
        color="primary"
      >
        Change Goal
      </Button>
    </div>
  );
}
