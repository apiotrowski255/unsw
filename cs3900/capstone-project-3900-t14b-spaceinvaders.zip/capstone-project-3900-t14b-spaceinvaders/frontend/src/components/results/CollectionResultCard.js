import { Card, createTheme, Grid, Rating, ThemeProvider } from "@mui/material";
import React from "react";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import { useNavigate } from "react-router-dom";
import IconButton from "@mui/material/IconButton";
import DeleteOutlinedIcon from "@mui/icons-material/DeleteOutlined";
import axios from "axios";
import config from "../../config";
import { getUsername } from "../../Helpers";

/*
A collection result card that shows the title and user of a collection
 */
export default function CollectionResultCard({ collection }) {
  const navigate = useNavigate();
  const onClick = (e) => {
    navigate(`/collection/${collection.collection_id}`);
  };
  const username = getUsername();
  // If the user owns the collection they are able to delete it using a delete button
  const deleteCollection = (e) => {
    e.stopPropagation();
    axios
      .post(`${config.backendurl}/api/user/collection/delete`, {
        cid: collection.collection_id,
      })
      .then((r) => {
        console.log(r.data);
        // Reloads the page to update the pages info as the item has now been deleted
        window.location.reload(false);
      })
      .catch((err) => {
        console.log("Error", err);
      });
  };
  return (
    <Box
      key={collection.collection_id}
      onClick={onClick}
      style={{ padding: "10px", cursor: "pointer" }}
    >
      <Card style={{ height: "200px", width: "300px", padding: "20px" }}>
        <Grid
          container
          flex
          justifyContent="space-between"
          alignContent="space-between"
        >
          <Grid item>
            <Grid
              container
              direction="column"
              justifyContent="space-evenly"
              alignContent="space-evenly"
            >
              <Grid item>
                <Typography
                  variant="h5"
                  component="div"
                  style={{ fontWeight: 600 }}
                >
                  {collection.collection_name}
                </Typography>
              </Grid>
              <Typography
                variant="h6"
                component="div"
                style={{ color: "grey" }}
              >
                By {collection.username}
              </Typography>
              <Typography variant="h6" component="div">
                Number of books: {collection.book_count}
              </Typography>
              <Grid item xs>
                <Grid container spacing={2}>
                  {collection.tags.map((tag) => {
                    return (
                      <Grid key={tag} item>
                        <Button variant="outlined" disabled>
                          {tag}
                        </Button>
                      </Grid>
                    );
                  })}
                </Grid>
              </Grid>
            </Grid>
          </Grid>
          {collection.username === username && (
            <Grid item style={{}}>
              <IconButton onClick={deleteCollection}>
                <DeleteOutlinedIcon />
              </IconButton>
            </Grid>
          )}
        </Grid>
      </Card>
    </Box>
  );
}
