import { Card, Grid } from "@mui/material";
import React from "react";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import { useNavigate } from "react-router-dom";
import CardContent from "@mui/material/CardContent";

export default function RecentReadResultCard({ review }) {
  const navigate = useNavigate();
  const onClick = (e) => {
    navigate(`/book/${review.bid}`);
  };

  let test = review.summary;
  let short_summary = test.slice(0, 50);
  short_summary += "...";
  return (
    <Grid item xs={3}>
      <Box
        key={review.bid}
        onClick={onClick}
        style={{ padding: "10px", cursor: "pointer" }}
      >
        <Card sx={{ maxWidth: 300 }}>
          <CardContent>
            <img src={review.picture} height="200" alt="book image"></img>
            <Typography variant="h6" component="div">
              {review.bookname}
            </Typography>
            <Typography color="text.secondary" variant="body2">
              Author: {review.author}
              <br></br>
              Publisher: {review.publisher}
            </Typography>
            <Typography variant="body2">Rating: {review.rating}</Typography>
            <Typography variant="body2">Summary: {short_summary}</Typography>
            <Card sx={{ maxWidth: 100, margin: 1 }}>
              <CardContent>
                <Typography
                  color="text.secondary"
                  variant="body2"
                  align="center"
                  Typography
                  sx={{ mb: -1.2 }}
                >
                  {review.tags}
                </Typography>
              </CardContent>
            </Card>
          </CardContent>
        </Card>
      </Box>
    </Grid>
  );
}
