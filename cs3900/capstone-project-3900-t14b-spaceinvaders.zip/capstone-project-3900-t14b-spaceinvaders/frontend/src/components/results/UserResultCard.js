import { Card, Grid } from "@mui/material";
import React from "react";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import { useNavigate } from "react-router-dom";

import Avatar from "@mui/material/Avatar";
/*
For displaying the basic info of a user
 */
export default function UserResultCard({ user }) {
  const navigate = useNavigate();
  // Redirects to that users page
  const onClick = (e) => {
    navigate(`/user/${user.uid}`);
  };
  return (
    <Box
      key={user.username}
      onClick={onClick}
      style={{ padding: "10px", cursor: "pointer" }}
    >
      <Card
        style={{
          justifyContent: "center",
          justifyItems: "center",
          height: "200px",
          width: "300px",
          padding: "20px",
        }}
      >
        <Grid
          container
          alignItems="center"
          justifyContent="space-around"
          alignContent="center"
        >
          <Grid item>
            <Avatar style={{ height: 100, width: 100 }}>
              {user.username && user.username !== ""
                ? user.username[0].toLocaleUpperCase()
                : ""}
            </Avatar>
          </Grid>
          <Grid item>
            <Grid
              container
              direction="column"
              justifyContent="space-evenly"
              alignContent="space-evenly"
            >
              <Typography variant="h5" component="div">
                {user.username}
              </Typography>

              <Typography variant="h6" component="div">
                {user.status}
              </Typography>
            </Grid>
          </Grid>
        </Grid>
      </Card>
    </Box>
  );
}
