import { Grid } from "@mui/material";
import BookResultCard from "./BookResultCard";
import React from "react";
import UserResultCard from "./UserResultCard";
import CollectionResultCard from "./CollectionResultCard";
import FollowingResultCard from "./FollowingResultCard";
import RecentReadResultCard from "./RecentReadResultCard";

/*
For Displaying the results of a search in a grid format
 */
export default function ResultGrid({ results, owner, cid }) {
  return (
    <Grid
      container
      justifyContent="center"
      justifyItems="center"
      sx={{ flexGrow: 1 }}
    >
      {results.books &&
        results.books.map((book) => (
          <BookResultCard key={book.bid} book={book} owner={owner} cid={cid} />
        ))}
      {results.users &&
        results.users.map((user) => (
          <UserResultCard key={user.username} user={user} owner={owner} />
        ))}
      {results.collections &&
        results.collections.map((collection) => (
          <CollectionResultCard
            key={collection.collection_name}
            collection={collection}
            owner={owner}
          />
        ))}
      {results.followings &&
        results.followings.map((following) => (
          <FollowingResultCard
            key={following.username}
            following={following}
            owner={owner}
          />
        ))}
      <Grid container spacing={1}>
        {results.latest_reviews &&
          results.latest_reviews.map((review) => (
            <RecentReadResultCard
              key={review.bid}
              review={review}
              owner={owner}
            />
          ))}
      </Grid>
    </Grid>
  );
}
