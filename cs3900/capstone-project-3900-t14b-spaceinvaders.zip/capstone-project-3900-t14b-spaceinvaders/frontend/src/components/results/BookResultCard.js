import { Card, createTheme, Grid, Rating, ThemeProvider } from "@mui/material";
import React from "react";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import { useNavigate } from "react-router-dom";
import IconButton from "@mui/material/IconButton";
import DeleteOutlinedIcon from "@mui/icons-material/DeleteOutlined";
import axios from "axios";
import config from "../../config";
import { getUsername } from "../../Helpers";

/*
A card that shows the limited amount of info on a book as a result in the grid view
 */
export default function BookResultCard({ book, owner, cid }) {
  const navigate = useNavigate();
  // Redirects to the book page
  const onClick = (e) => {
    navigate(`/book/${book.bid}`);
  };
  // If this book result is in a collection the user is able to delete it using this function
  // Only if the cid (collection id) is specified)
  const deleteBookFromCollection = (e) => {
    e.stopPropagation();
    axios
      .post(`${config.backendurl}/api/user/collection/deletebook`, {
        cid: cid,
        bid: book.bid,
      })
      .then((r) => {
        console.log(r.data);
        window.location.reload(false);
      })
      .catch((err) => {
        console.log("Error", err);
      });
  };
  return (
    <Box
      key={book.name}
      onClick={onClick}
      style={{ padding: "10px", cursor: "pointer" }}
    >
      <Card style={{ height: "200px", width: "350px", padding: "20px" }}>
        <Grid
          container
          flex
          justifyContent="space-evenly"
          alignContent="space-evenly"
        >
          <Grid item>
            <Grid
              container
              direction="column"
              justifyContent="space-evenly"
              alignContent="space-evenly"
            >
              <Typography
                sx={{
                  display: "-webkit-box",
                  overflow: "hidden",
                  WebkitBoxOrient: "vertical",
                  WebkitLineClamp: 3,
                }}
                variant="h5"
                component="div"
              >
                {book.name}
              </Typography>
              <Typography variant="h6" component="div">
                {book.author}
              </Typography>
              <Typography variant="h6" component="div">
                Rating:
                <Rating
                  name="half-rating-read"
                  defaultValue={2.5}
                  value={book.rating}
                  precision={0.1}
                  readOnly
                />
              </Typography>
              <Grid item xs>
                <Grid container spacing={2}>
                  {book.tags.map((tag) => {
                    return (
                      <Grid key={tag} item>
                        <Button variant="outlined" disabled>
                          {tag}
                        </Button>
                      </Grid>
                    );
                  })}
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
        {owner === getUsername() && (
          <IconButton onClick={deleteBookFromCollection}>
            <DeleteOutlinedIcon />
          </IconButton>
        )}
      </Card>
    </Box>
  );
}
