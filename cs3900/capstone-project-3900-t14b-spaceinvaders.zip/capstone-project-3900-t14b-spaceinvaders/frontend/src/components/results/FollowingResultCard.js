import { Card, Grid } from "@mui/material";
import React from "react";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import { useNavigate } from "react-router-dom";

/*
For displaying information about a user your following/followed by
 */
export default function FollowingResultCard({ following }) {
  const navigate = useNavigate();
  // Redirects to the users page
  const onClick = (e) => {
    navigate(`/user/${following.uid}`);
  };
  return (
    <Box
      key={following.uid}
      onClick={onClick}
      style={{ padding: "10px", cursor: "pointer" }}
    >
      <Card style={{ height: "200px", width: "300px", padding: "20px" }}>
        <Grid
          container
          flex
          justifyContent="space-evenly"
          alignContent="space-evenly"
        >
          <Grid item>
            <Grid
              container
              direction="column"
              justifyContent="space-evenly"
              alignContent="space-evenly"
            >
              <Typography variant="h5" component="div">
                {following.username}
              </Typography>
              <Typography variant="h6" component="div">
                Followed on: {following.followed_time}
              </Typography>
            </Grid>
          </Grid>
        </Grid>
      </Card>
    </Box>
  );
}
