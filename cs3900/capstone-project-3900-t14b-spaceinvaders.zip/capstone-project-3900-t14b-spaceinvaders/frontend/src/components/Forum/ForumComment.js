import { Card, Grid, TextField } from "@mui/material";
import Typography from "@mui/material/Typography";
import React, { useState } from "react";
import Box from "@mui/material/Box";
import { useNavigate } from "react-router-dom";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import EditIcon from "@mui/icons-material/Edit";
import DoneIcon from "@mui/icons-material/Done";
import axios from "axios";
import config from "../../config";
import DeleteOutlinedIcon from "@mui/icons-material/DeleteOutlined";
import { getUserId, getUsername } from "../../Helpers";

/*
A singular forum comment with the ability to report if the user didnt create it
or edit/delete if the user did create it
 */
export default function ForumComment({ comment }) {
  // Boolean for storing whether the user is editting this comment currently
  const [editting, setEditting] = useState(false);
  // Stores the user editted comment before it is sent to the backend
  const [edittedComment, setEdittedComment] = useState(comment.content);
  const handleEditComment = (e) => {
    setEdittedComment(e.target.value);
  };

  // If the user is editting and presses the tick button the comment is sent to store in the backend
  const handleEdit = (e) => {
    if (editting && edittedComment !== "") {
      axios
        .post(`${config.backendurl}/api/forum/comment/edit`, {
          uid: getUserId(),
          pid: comment.pid,
          comment_id: comment.comment_id,
          new_content: edittedComment,
        })
        .then((r) => {
          console.log(r.data);
          // Reloads the page to update the information on the page
          window.location.reload(false);
        })
        .catch((err) => {
          console.log("Error", err);
        });
    }

    setEditting(!editting);
  };
  // Deletes the comment from the backend then reloads the page to show this update
  const deleteComment = (e) => {
    axios
      .post(`${config.backendurl}/api/forum/comment/delete`, {
        uid: getUserId(),
        pid: comment.pid,
        comment_id: comment.comment_id,
      })
      .then((r) => {
        console.log(r.data);
        window.location.reload(false);
      })
      .catch((err) => {
        console.log("Error", err);
      });
  };
  // Handles the reporting of comments by sending relevant info to the backend
  const handleReport = (event) => {
    axios
      .post(`${config.backendurl}/api/report/postcomment`, {
        uid_reporting: getUserId(),
        uid_reported: comment.uid,
        reported_postid: comment.pid,
        reported_commentid: comment.comment_id,
        reason: prompt("Enter reason of this report"),
      })
      .then((r) => {
        console.log(r.data);
      })
      .catch((err) => {
        console.log("Error", err);
      });
    alert("Reported");
  };
  return (
    <Box key={comment} style={{ padding: "10px" }}>
      <Card
        style={{
          padding: "15px",
          alignContent: "center",
          alignItems: "center",
        }}
      >
        <Grid container direction="column">
          <Grid item>
            {!editting && (
              <Typography variant="h5" component="div">
                {comment.content}
              </Typography>
            )}
            {editting && (
              <TextField value={edittedComment} onChange={handleEditComment} />
            )}
          </Grid>

          <Grid item style={{ position: "absolute", right: "20px" }}>
            {comment.username !== getUsername() && (
              <Button onClick={handleReport}>Report</Button>
            )}
            {comment.username === getUsername() && (
              <div>
                <IconButton onClick={handleEdit}>
                  {!editting && <EditIcon />}
                  {editting && <DoneIcon />}
                </IconButton>
                <IconButton onClick={deleteComment}>
                  <DeleteOutlinedIcon />
                </IconButton>
              </div>
            )}
          </Grid>
          <Grid item>
            <Typography variant="h8" component="div" style={{ color: "grey" }}>
              By {comment.username}
            </Typography>
          </Grid>
        </Grid>
      </Card>
    </Box>
  );
}
