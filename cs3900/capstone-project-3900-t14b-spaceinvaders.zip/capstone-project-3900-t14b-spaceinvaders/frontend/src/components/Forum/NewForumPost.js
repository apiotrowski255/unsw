import { Card, Grid, TextField } from "@mui/material";
import React, { useState } from "react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import axios from "axios";
import config from "../../config";
import Typography from "@mui/material/Typography";
import { useNavigate } from "react-router-dom";
import { getUserId } from "../../Helpers";

/*
A form card for creating a new post
 */
export default function NewForumPost() {
  const [title, setTitle] = useState();
  const [content, setContent] = useState();
  const handleTitleChange = (e) => {
    if (e.target.value.length < 50) {
      setTitle(e.target.value);
    }
  };
  const navigate = useNavigate();
  // Handles sending the new post to the backend and redirecting the user to the new forum post page
  const handleClick = () => {
    if (title !== "" && content !== "") {
      axios
        .post(`${config.backendurl}/api/forum/post`, {
          uid: getUserId(),
          title: title,
          content: content,
        })
        .then((r) => {
          console.log(r.data);
          navigate(`/forum/${r.data.pid}`);
        })
        .catch((err) => {
          console.log("Error", err);
        });
    }
  };
  // Handles changing of the content
  const handleContentChange = (e) => {
    setContent(e.target.value);
  };

  return (
    <Box style={{ padding: "10px" }}>
      <Card
        style={{
          padding: "15px",
          alignContent: "center",
          alignItems: "center",
        }}
      >
        <Typography variant="h5" component="div">
          New post
        </Typography>
        <TextField
          fullWidth
          InputProps={{ style: { fontSize: 30 } }}
          style={{ paddingBottom: "15px" }}
          value={title}
          label="Title"
          onChange={handleTitleChange}
        />
        <TextField
          fullWidth
          InputProps={{ style: { fontSize: 13 } }}
          value={content}
          label="Content"
          onChange={handleContentChange}
        />
        <Button onClick={handleClick}>Submit</Button>
      </Card>
    </Box>
  );
}
