import { Card, Grid, TextField } from "@mui/material";
import React, { useState } from "react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import axios from "axios";
import config from "../../config";
import Typography from "@mui/material/Typography";
import { useNavigate } from "react-router-dom";
import { getUserId } from "../../Helpers";

/*
A Card for the user to write a new comment on the forum post
*/
export default function NewForumComment({ pid }) {
  const [comment, setComment] = useState("");
  const handleClick = () => {
    if (comment !== "") {
      axios
        .post(`${config.backendurl}/api/forum/comment/add`, {
          uid: getUserId(),
          pid: pid,
          content: comment,
        })
        .then((r) => {
          console.log(r.data);
          setComment("");

          window.location.reload(false);
        })
        .catch((err) => {
          console.log("Error", err);
        });
    }
  };
  const handleCommentChange = (e) => {
    setComment(e.target.value);
  };

  return (
    <Box style={{ padding: "10px" }}>
      <Card
        style={{
          padding: "15px",
          alignContent: "center",
          alignItems: "center",
        }}
      >
        <TextField
          fullWidth
          InputProps={{ style: { fontSize: 13 } }}
          value={comment}
          label="Add a Comment..."
          onChange={handleCommentChange}
        />
        <Button onClick={handleClick}>Comment</Button>
      </Card>
    </Box>
  );
}
