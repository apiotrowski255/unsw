import { Card, Grid } from "@mui/material";
import Typography from "@mui/material/Typography";
import React from "react";
import Box from "@mui/material/Box";
import { useNavigate } from "react-router-dom";
/*
 A clickable card containing the forum post title, username and number of comments
 */
export default function ForumResult({ post }) {
  const navigate = useNavigate();
  // Redirects to the post to comment and view others comments
  const onClick = (e) => {
    navigate(`/forum/${post.pid}`);
  };
  return (
    <Box
      key={post}
      onClick={onClick}
      style={{ padding: "10px", cursor: "pointer" }}
    >
      <Card
        style={{
          height: "70px",
          padding: "15px",
          alignContent: "center",
          alignItems: "center",
        }}
      >
        <Typography variant="h4" component="div" style={{ fontWeight: 600 }}>
          {post.title}
        </Typography>

        <Grid
          container
          direction="column"
          alignContent="space-between"
          alignItems="center"
        >
          <Grid item>
            <Typography variant="h8" component="div" style={{ color: "grey" }}>
              By {post.username}
            </Typography>

            <Typography
              style={{ right: "30px", position: "absolute" }}
              variant="h8"
              component="div"
            >
              Comments: {post.comments}
            </Typography>
          </Grid>
        </Grid>
      </Card>
    </Box>
  );
}
