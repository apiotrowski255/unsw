// This is used to determine if a user is authenticated and
// if they are allowed to visit the page they navigated to.

// If they are: they proceed to the page
// If not: they are redirected to the login page.
import React from 'react'
import {Navigate, useLocation} from 'react-router-dom'

function getToken(){
  return localStorage.getItem('token')
}


const PrivateRoute: React.FC<{ children: JSX.Element }> = ({ children }) => {
  const token = getToken();
  const auth = token === '';
  let location = useLocation();

  if (auth) {
    return <Navigate to="/login" state={{ from: location }} />;
  }

  return children;
};


export default PrivateRoute