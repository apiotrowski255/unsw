import { Grid, Rating } from "@mui/material";
import Avatar from "@mui/material/Avatar";
import Typography from "@mui/material/Typography";
import StyledPaper from "../StyledPaper";
import React, { useState } from "react";
import Button from "@mui/material/Button";
import axios from "axios";
import config from "../../config";
import { getUserId } from "../../Helpers";
/*
A singular review
 */
export default function Review({ review }) {
  const userId = getUserId();

  /*
  Sends a report to the backend for admins to review
  */
  const handleReport = (event) => {
    // event.preventDefault();
    axios
      .post(`${config.backendurl}/api/report/review`, {
        uid_reporting: userId,
        // not sure how to get uid bid
        uid_reported: review.uid,
        bid_reported: review.bid,
        reason: prompt("Enter reason of this report"),
      })
      .then((r) => {
        console.log(r.data);
      })
      .catch((err) => {
        console.log("Error", err);
      });
    alert("Reported");
  };
  return (
    <StyledPaper
      sx={{
        my: 1,
        mx: "auto",
        p: 2,
      }}
    >
      <Grid container wrap="nowrap" spacing={2}>
        <Grid item>
          <Avatar>{review.username[0]}</Avatar>
        </Grid>
        <Grid item xs>
          <Grid container direction="column">
            <Grid container>
              <Typography variant="h6" component="div">
                {review.username}
              </Typography>
              <Rating
                name="half-rating-read"
                defaultValue={0}
                value={review.ratings}
                precision={0.5}
                readOnly
              />
            </Grid>
            <Typography>{review.review}</Typography>
            <Button onClick={handleReport}>Report this review</Button>
          </Grid>
        </Grid>
      </Grid>
    </StyledPaper>
  );
}
