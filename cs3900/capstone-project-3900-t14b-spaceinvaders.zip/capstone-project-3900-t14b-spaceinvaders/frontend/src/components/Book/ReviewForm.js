import StyledPaper from "../StyledPaper";
import { Grid, Rating, TextField } from "@mui/material";
import Typography from "@mui/material/Typography";
import React, { useState } from "react";
import Button from "@mui/material/Button";
import axios from "axios";
import config from "../../config";
import { getUsername } from "../../Helpers";

/*
A form the user
 */
export default function ReviewForm({ book, resetReviewing }) {
  const [review, setReview] = useState("");
  const [rating, setRating] = useState(5.0);
  const username = getUsername();

  const [typedSomething, setTypedSomething] = useState(false);
  const [error, setError] = useState("");
  const submitReview = () => {
    axios
      .post(`${config.backendurl}/api/book/rate_review`, {
        username: username,
        bookid: book.bid,
        review: review,
        rating: rating,
      })
      .then((r) => {
        console.log(r.data);
        if (r.data.error === "None") {
          resetReviewing();
        } else {
          setError(r.data.error);
        }
      })
      .catch((err) => {
        console.log("Error", err);
      });
  };

  const handleReviewChange = (event) => {
    setRating(event.target.value);
  };
  const handleChange = (event) => {
    setTypedSomething(true);
    setReview(event.target.value);
  };
  return (
    <StyledPaper
      sx={{
        my: 1,
        mx: "auto",
        p: 2,
      }}
    >
      <Grid container direction="column" wrap="nowrap">
        <TextField
          error={
            typedSomething &&
            (error !== "" || review === "" || review.length > 200)
          }
          helperText={
            typedSomething &&
            ((review === "" && "Review must contain some text") ||
              (review.length > 200 && "Review cannot exceed 200 characters") ||
              (error !== "" && error))
          }
          variant="outlined"
          value={review}
          onChange={handleChange}
          label="Review"
          fullWidth
          style={{ marginBottom: "1em" }}
        />
        <Grid container>
          <Typography>Rating: </Typography>
          <Rating
            name="half-rating-read"
            defaultValue={5.0}
            value={rating}
            onChange={handleReviewChange}
            precision={0.5}
          />
        </Grid>
        <Button
          onClick={submitReview}
          size="large"
          variant="contained"
          color="primary"
          disabled={review === "" || review.length > 200}
        >
          Submit
        </Button>
      </Grid>
    </StyledPaper>
  );
}
