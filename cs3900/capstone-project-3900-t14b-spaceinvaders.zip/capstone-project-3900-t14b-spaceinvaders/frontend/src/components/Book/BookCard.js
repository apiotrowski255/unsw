import { Divider, Grid, Rating, Select } from "@mui/material";
import Avatar from "@mui/material/Avatar";
import Typography from "@mui/material/Typography";
import React, { useEffect, useState } from "react";
import StyledPaper from "../StyledPaper";
import Button from "@mui/material/Button";
import BookmarkBorderIcon from "@mui/icons-material/BookmarkBorder";

import Box from "@mui/material/Box";
import axios from "axios";
import config from "../../config";
import MenuItem from "@mui/material/MenuItem";
import { getUserId } from "../../Helpers";
/*
The card that appears at the top of the book page that displays the information for the book
 */
export default function BookCard({ book }) {
  const [results, setResults] = useState({
    collections: [],
    unset: true,
  });

  const userId = getUserId();
  /*
  Gets the information about the book requested from the backend
  */
  const updateResults = () => {
    axios
      .get(`${config.backendurl}/api/user/collection/show`, {
        params: {
          uid: userId,
        },
      })
      .then((r) => {
        console.log(r.data);
        if (r.data.error === "None") {
          setResults(r.data);
        } else {
          setResults({ collections: [] });
        }
      })
      .catch((err) => {
        console.log("Error", err);
      });
  };

  useEffect(() => {
    if (results.unset) {
      updateResults();
    }
  });
  /*
  For adding books to a users collection
   */
  const handleChange = (event) => {
    axios
      .post(`${config.backendurl}/api/user/collection/addbooks`, {
        cid: event.target.value,
        bids: [book.bid],
      })
      .then((r) => {
        console.log(r.data);
      })
      .catch((err) => {
        console.log("Error", err);
      });
  };
  return (
    <StyledPaper
      sx={{
        my: 1,
        mx: "auto",
        p: 2,
      }}
    >
      <Grid container wrap="nowrap" spacing={2}>
        <Grid item>
          <Box
            component="img"
            sx={{
              height: 300,
            }}
            alt="Book image"
            src={book.image}
          />
        </Grid>
        <Grid item xs>
          <Grid
            container
            justifyContent="space-between"
            wrap="nowrap"
            direction={"column"}
            spacing={2}
          >
            <Grid item xs>
              <Grid container justifyContent="space-between">
                <Typography variant="h4" component="div">
                  {book.name}
                </Typography>
              </Grid>
            </Grid>
            <Grid item xs>
              <Grid container justifyContent="space-between">
                <Typography variant="h6" component="div">
                  Author: {book.author}
                </Typography>

                <Typography variant="h6" component="div">
                  Read by:{" "}
                  {(book.reads === 0 && "No users") ||
                    (book.reads === 1 && "1 user") ||
                    (book.reads > 1 && `${book.reads} users`)}
                </Typography>
              </Grid>
            </Grid>
            <Grid item xs>
              <Typography variant="h6" component="div">
                Publisher: {book.publisher}
              </Typography>
            </Grid>
            <Grid item xs>
              <Typography>
                Rating:
                <Rating
                  name="half-rating-read"
                  defaultValue={2.5}
                  value={book.rating}
                  precision={0.1}
                  readOnly
                />
              </Typography>
            </Grid>
            <Grid item xs>
              <Typography>Summary: {book.summary}</Typography>
            </Grid>
            <Grid item xs>
              <Grid container spacing={2}>
                {book.tags.map((tag) => {
                  return (
                    <Grid key={tag} item>
                      <Button variant="outlined" disabled>
                        {tag}
                      </Button>
                    </Grid>
                  );
                })}
              </Grid>
            </Grid>
            {getUserId() !== "" && (
              <Grid item xs>
                <Select
                  labelId="add-select-label"
                  id="simple-select"
                  value="Add to collection"
                  style={{ width: "300px" }}
                  label="Add to Collection"
                  onChange={handleChange}
                >
                  <MenuItem disabled value="Add to collection">
                    Add to collection
                  </MenuItem>
                  <Divider />
                  {results.collections.map((collection) => {
                    return (
                      <MenuItem
                        key={collection.collection_name}
                        value={collection.collection_id}
                      >
                        {collection.collection_name}
                      </MenuItem>
                    );
                  })}
                </Select>
              </Grid>
            )}
          </Grid>
        </Grid>
      </Grid>
    </StyledPaper>
  );
}
