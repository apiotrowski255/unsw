/* Getter for the user id  */
export function getUserId() {
  return localStorage.getItem("user_id");
}
/* Getter for the username */
export function getUsername() {
  return localStorage.getItem("username");
}
