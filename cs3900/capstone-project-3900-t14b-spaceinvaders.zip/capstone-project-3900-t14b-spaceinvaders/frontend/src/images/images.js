import picture0 from "./1.png";
import picture1 from "./2.png";
import picture2 from "./3.png";
import picture3 from "./4.png";
import picture4 from "./5.png";
import picture5 from "./6.png";
import picture6 from "./7.png";
import picture7 from "./8.png";
import booklogo from "./book.png";

export {
  picture0,
  picture1,
  picture2,
  picture3,
  picture4,
  picture5,
  picture6,
  picture7,
  booklogo,
};
