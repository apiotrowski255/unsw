/* The configuration for where the backend url is this is so if the server was moved to production it can be run easily */
const config = {
  backendurl: "http://localhost:5000",
};

export default config;
