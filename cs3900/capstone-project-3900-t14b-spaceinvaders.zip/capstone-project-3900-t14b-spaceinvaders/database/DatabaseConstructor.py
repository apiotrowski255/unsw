# Author: Zijian Yue
# Date: 5/3/2022


# This file is used to construct the database for the proejct
# Note: this file should not be seen as part of the project.
# Its purpose is to provide a scaffold to construct database, and a record of how our database is constructed
# Furthermore, this file does not provide interface for back-end to interact with the database

import sqlite3

# Connection to a SQLite database
conn = sqlite3.connect("DataBase.db")

# Create Cursor to controll the database
cursor = conn.cursor()

# EveryTime when DatabaseConstrutor is excueted, it will create a new dataBase(by clear the previous database)
cursor.execute("DROP TABLE IF EXISTS STATS")
cursor.execute("DROP TABLE IF EXISTS USERS")
cursor.execute("DROP TABLE IF EXISTS BOOKS")
cursor.execute("DROP TABLE IF EXISTS COLLECTIONS")
cursor.execute("DROP TABLE IF EXISTS READ")
cursor.execute("DROP TABLE IF EXISTS INCLUDE")
cursor.execute("DROP TABLE IF EXISTS OWN")
cursor.execute("DROP TABLE IF EXISTS FOLLOW")
cursor.execute("DROP TABLE IF EXISTS POSTS")
cursor.execute("DROP TABLE IF EXISTS COMMENTS")
cursor.execute("DROP TABLE IF EXISTS REPORT")

# Create entity tables

# Create stats table
create_stats_table = '''CREATE TABLE STATS(
                        UID_COUNTER TEXT,
                        BID_COUNTER TEXT,
                        CID_COUNTER TEXT,
                        COLLECTION_LIMIT TEXT,
                        PID_COUNTER TEXT,
                        RID TEXT
                    )
                    '''
cursor.execute(create_stats_table)

# Create user table 
create_users_table = '''CREATE TABLE USERS(
                            UID TEXT PRIMARY KEY,
                            ROLE TEXT(5), 
                            PASSWORD TEXT,
                            USERNAME TEXT(30),
                            BIRTHDAY TEXT(10), 
                            SELF_INTRODUCTION TEXT,
                            EMAIL TEXT(40),
                            PICTURE TEXT,
                            STATUS TEXT(9),
                            GOAL TEXT,
                            ADDED_TIME TEXT
                    )'''
cursor.execute(create_users_table)

# End of sprint1 section

# Create books table
create_books_table = '''CREATE TABLE BOOKS(
                        BID TEXT PRIMARY KEY,
                        BOOKNAME TEXT,
                        AUTHOR TEXT,
                        YEAR TEXT,
                        COUNTRY TEXT,
                        PUBLISHERS TEXT,
                        SUMMARY TEXT,
                        RATING TEXT(4),
                        PICTURE TEXT,
                        TAGS TEXT,
                        ADDED_TIME TEXT
                    )'''
cursor.execute(create_books_table)

# Create collections table
create_collections_table = '''CREATE TABLE COLLECTIONS(
                        CID TEXT PRIMARY KEY,
                        COLLECTION_NAME TEXT,
                        PICTURE TEXT,
                        COMMENTS TEXT,
                        TIME_CREATED TEXT,
                        TAGS TEXT
                    )'''
cursor.execute(create_collections_table)

# Create Posts table
create_posts_table = '''CREATE TABLE POSTS(
                                PID TEXT PRIMARY KEY,
                                UID TEXT,
                                TITLE TEXT,
                                CONTENT TEXT,
                                COMMENT_ID_COUNTER TEXT,
                                TIME_CREATED TEXT,
                                EDITED TEXT,
                                TIME_EDITED TEXT,
                                FOREIGN KEY(UID) REFERENCES USERS(UID)
                        )'''
cursor.execute(create_posts_table)

# Create comment table
create_comments_table = '''CREATE TABLE COMMENTS(
                                COMMENT_ID TEXT,
                                UID TEXT,
                                PID TEXT,
                                CONTENT TEXT,
                                TIME_CREATED TEXT,
                                EDITED TEXT,
                                TIME_EDITED TEXT,
                                FOREIGN KEY(UID) REFERENCES USERS(UID),
                                FOREIGN KEY(PID) REFERENCES POSTS(PID)
                        )'''
cursor.execute(create_comments_table)

# Create relationship tables

# Create read table
# Last time read format: SS/MM//HH/DD/MM/YYYY
# Total reading time in hours(>= 10000 hours ---> show words)
create_read_table = '''CREATE TABLE READ(
                            UID TEXT,
                            BID TEXT,
                            COMMENT TEXT, 
                            RATING TEXT(4),
                            LAST_TIME_READ TEXT(20),
                            TOTAL_READING_TIME TEXT(5),
                            FOREIGN KEY(UID) REFERENCES USERS(UID),
                            FOREIGN KEY(BID) REFERENCES BOOKS(BID)
                    )'''
cursor.execute(create_read_table)

# Create include table
create_include_table = '''CREATE TABLE INCLUDE(
                            CID TEXT,
                            BID TEXT,
                            ADDED_TIME TEXT,
                            FOREIGN KEY(CID) REFERENCES COLLECTIONS(CID),
                            FOREIGN KEY(BID) REFERENCES BOOKS(BID)
                    )'''
cursor.execute(create_include_table)

# Create own table
create_own_table = '''CREATE TABLE OWN(
                            CID TEXT,
                            UID TEXT,
                            FOREIGN KEY(CID) REFERENCES COLLECTIONS(CID),
                            FOREIGN KEY(UID) REFERENCES USERS(UID)
                    )'''
cursor.execute(create_own_table)


# Create table follow 
create_follow_table = '''CREATE TABLE FOLLOW(
                            UID TEXT,
                            FOLLOWING_ID TEXT,
                            FOLLOWING_TIME TEXT, 
                            FOREIGN KEY(UID) REFERENCES USERS(UID),
                            FOREIGN KEY(FOLLOWING_ID) REFERENCES USERS(UID)
                    )'''
cursor.execute(create_follow_table)


# Create table report
create_table_report = '''CREATE TABLE REPORT(
                            RID TEXT PRIMARY KEY,
                            REPORTING_UID TEXT,
                            REPORTED_UID TEXT,
                            REASON TEXT, 
                            REPORTING_TIME TEXT,
                            ADMIN_MESSAGE TEXT,
                            REPORTED_BID TEXT,
                            REPORTED_POST_ID TEXT,
                            REPORTED_COMMENT_ID TEXT,
                            FOREIGN KEY(REPORTING_UID) REFERENCES USERS(UID),
                            FOREIGN KEY(REPORTED_UID) REFERENCES USERS(UID)
                    )'''
cursor.execute(create_table_report)

# End of table construction

# Insert values
# Give init to the stats table
init_stats_table = '''INSERT INTO STATS
                      (UID_COUNTER, BID_COUNTER, CID_COUNTER, COLLECTION_LIMIT, PID_COUNTER, RID)
                      VALUES
                      ('1', '1', '1', '20', '1', '1')
                   '''
cursor.execute(init_stats_table)
conn.commit()

# Closr the connection
cursor.close()
    

print("database construction completed successfully!")