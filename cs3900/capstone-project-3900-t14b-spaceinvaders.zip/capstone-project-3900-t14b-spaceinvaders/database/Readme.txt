Please make sure you use python 3.7 to run the code
Please also make sure you have sqlit3 installed in your OS

1. DatabaseManager.py: provide a class called DatabaseManager which contains methods to interact with database
2. DatabaseConstructor.py: For creating tables in the database
    Note: DatabaseConstructor.py can(should) be used to re-build the database
3. DatabaseManagerUtility.py: provide util functions for DatabaseManager.py
6. DataBase.db: sqlit3 databse file
