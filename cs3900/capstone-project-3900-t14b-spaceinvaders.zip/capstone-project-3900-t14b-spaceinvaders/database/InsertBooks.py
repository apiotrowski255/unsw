# Author: Hugh Ebeling
# Date: 28/03/2022
import csv
import sqlite3

sql = """
        INSERT into BOOKS (BID, BOOKNAME, AUTHOR, YEAR, COUNTRY, PUBLISHERS, SUMMARY, RATING, PICTURE, TAGS)
        VALUES
        """
conn = sqlite3.connect("DataBase.db", check_same_thread = False)
cursor = conn.cursor()
with open('data.csv', 'r', newline='') as csvfile:
    reader = csv.reader(csvfile, delimiter=' ',
                        quotechar='|', quoting=csv.QUOTE_MINIMAL)

    for line in reader:
        line[9] = str(line[9][2:-2])
        new_sql = sql + str(tuple(line))
        if '\\' in new_sql:
            print('slash found')
        else:
            cursor.execute(new_sql)
    conn.commit()
