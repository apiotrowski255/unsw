# Author: Zijian Yue
# Date: 19/3/2022


# BooksTableManager
# provide queries realted to books table to the database manager

import sqlite3
import time

class BooksTableManager:
    def __init__(self, conn : sqlite3.Connection, cursor : sqlite3.Cursor):
        self.conn = conn
        self.cursor = cursor


    # create a book, and add this book to the database
    def book_create_new_book(self, bookname:str, author:str, year:str, country:str, publishers:str, summary:str, picture:str, tags:str):
        # check if this book already existed
        if self.check_book_exist(bookname, author, year, country, publishers) != None:
            return "Book already exists"

        # process the data, make sure all the strings are quoted
        bid = '"' + self.book_get_next_bid() + '"'
        bookname = "'" + bookname + "'"
        author = "'" + author + "'"
        year = "'" + year + "'"
        country = "'" + country + "'"
        publishers = "'" + publishers + "'"
        summary = "'" + summary + "'"
        picture = "'" + picture + "'"
        tags = '"' + tags + '"'
        timestamp = '"' + time.strftime("%Y/%m/%d") + '"'
    
        # fill book's infromation to the table
        create_book_msg = '''INSERT INTO BOOKS
                                (BID, BOOKNAME, AUTHOR, YEAR, COUNTRY, PUBLISHERS, SUMMARY, RATING, PICTURE, TAGS, ADDED_TIME) 
                                VALUES 
                                ({}, {},{},{},{},{},{},{},{},{},{})
                           '''.format(bid, bookname, author, year, country, publishers, summary, '"-1"' , picture, tags, timestamp)
        cursor = self.conn.cursor()
        cursor.execute(create_book_msg)
        self.conn.commit()

        # if the book is successfully added
        # update the stats table
        # retrive the total number of existed books
        cursor.execute("SELECT BID_COUNTER FROM STATS")
        num_str = cursor.fetchall()
        book_number = int(num_str[0][0]) + 1

        # store the new bid(the bid for the very nect added book) back
        cursor.execute("UPDATE STATS SET BID_COUNTER = {}".format(str(book_number)))
        self.conn.commit()
        cursor.close()
        # if the book is successfully created return a msg
        return "Book is successfully added"


    # Note: fieled must be all capital
    # formula input_list = [field, new_value]
    def book_update_book_table(self, bid:str, field:str, new_value:str):
        # turn the given field to upper cases to match with the db
        field = field.upper()

        # if the user does not exists in the database, return false
        if self.book_table_search("BID", bid) == None:
            return "Book does not exists"

        # if the given field is wrong
        if field not in ("BOOKNAME", "AUTHOR", "YEAR", "COUNTRY", "PUBLISHERS", "SUMMARY", "RATING", "PICTURE", "TAGS"):
            return "Field does not exist or trying to change the bid"

        # retive the book info
        info_tuple = self.book_table_search("BID", bid)
        # create a dictonary keyed by field
        dict = {
            "BOOKNAME" : info_tuple[1],
            "AUTHOR" : info_tuple[2],
            "YEAR" : info_tuple[3],
            "COUNTRY" : info_tuple[4],
            "PUBLISHERS" : info_tuple[5],
        }
        # new creat new info with the given key and new_value
        dict[field] = new_value
        # check with the existed books
        if field == "BOOKNAME" or field == "AUTHOR" or field == "YEAR" or field == "COUNTRY" or field == "PUBLISHERS":
            if self.check_book_exist(dict["BOOKNAME"], dict["AUTHOR"], dict["YEAR"], dict["COUNTRY"], dict["PUBLISHERS"]) != None:
                return "Updating failed, the updated book has collisions with other books"
        
        # process the data, make sure all the strings are quoted
        new_value = '"' + new_value + '"'
        bid = "'" + bid + "'"
        msg = """UPDATE BOOKS SET {} = {} WHERE BID = {}""".format(field, new_value, bid)
        cursor = self.conn.cursor()
        # update the data to the presistent database
        cursor.execute(msg)
        self.conn.commit()
        cursor.close()
        # if no exceptions occurs, return True
        return "Update is successful"


    # return the total number of books in the database 
    def book_get_total_number(self):
        cursor = self.conn.cursor()
        cursor.execute("SELECT COUNT(BID) FROM Books")
        msg = cursor.fetchall()
        cursor.close()
        return int(msg[0][0])


    # get the next bid
    def book_get_next_bid(self):
        cursor = self.conn.cursor()
        cursor.execute("SELECT BID_COUNTER FROM STATS")
        msg = cursor.fetchall()
        cursor.close()
        return msg[0][0]


    # get books have avg rate 4 ~ 5
    def book_get_four_five(self):
        cursor = self.conn.cursor()
        query = '''SELECT * FROM BOOKS WHERE CAST(RATING AS INTEGER) >= 4'''
        cursor.execute(query)
        msg = cursor.fetchall()
        cursor.close()
        return msg


    # update and caculate the ratings
    def book_update_the_rating(self, bid):
        #process the data
        returned_bid = bid
        bid = "'" + bid + "'"
        cursor = self.conn.cursor()
        # caculate the average rating based on the given bid
        cursor.execute("SELECT RATING FROM READ WHERE BID = {}".format(bid))
        ratings = cursor.fetchall()
        cursor.execute("SELECT COUNT(RATING) FROM READ WHERE BID = {}".format(bid))
        total_number = float(cursor.fetchall()[0][0])

        if total_number == 0.0:
            return "No enough ratings"

        # caculate the average
        sum = 0
        for item in ratings:
            sum += float(item[0])
        avg_rating = str(sum / total_number)[0:4]
        cursor.close()
        #update the average to the corresponding book
        return self.book_update_book_table(returned_bid, "RATING", avg_rating)


    # return all infromation related to the book with the given bid
    def check_book_exist(self, bookname:str, author:str, year:str, country:str, publisher:str):
        # process the given keys
        bookname = "'" + bookname + "'"
        author = "'" + author + "'"
        year = "'" + year + "'"
        country = "'" + country + "'"
        publisher = "'" + publisher + "'"
        cursor = self.conn.cursor()
        # check is the book with given keys existed
        cursor.execute('''SELECT *  
                            FROM BOOKS 
                            WHERE BOOKNAME = {} AND AUTHOR = {} 
                            AND YEAR = {} AND COUNTRY = {} 
                            AND PUBLISHERS = {} 
        '''.format(bookname, author, year, country, publisher) 
        )
        msg = cursor.fetchall()
        cursor.close()
        # if the item does not exist return None
        if len(msg) == 0:
            return None

        # else return a tuple contains all infromation to this book
        return msg[0]


    # return all infromation related to the book with the given field and key
    def book_table_search(self, colounm_name:str, key:str):
        key = '"' + key + '"'
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM BOOKS WHERE {} = {} ".format( colounm_name, key) )
        msg = cursor.fetchall()
        cursor.close()
        # if the item does not exist return None
        if len(msg) == 0:
            return None
        # else return a tuple contains all users infromation
        return msg[0]


    # retrieve list of random books in database
    def book_get_random(self, booknum:int):
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM BOOKS ORDER BY RANDOM() LIMIT {}".format(booknum))
        msg = cursor.fetchall()
        cursor.close()
        return msg

    # get all the books which contain the tag
    def book_get_books_by_tag(self, query_tag:str):
        # select bid, uid, rating columns from READ table
        #format string for sql query
        tags = "'%" + query_tag + "%'"

        query = '''SELECT * FROM BOOKS
                    WHERE TAGS LIKE {}
                    ORDER BY CAST(RATING AS NUMERIC) DESC
        '''.format(tags)
        cursor = self.conn.cursor()
        cursor.execute(query)
        
        msg = cursor.fetchall()
        cursor.close()
        # if the item does not exist return None
        if len(msg) == 0:
            return None

        # else return a tuple contains all information to this book
        return msg