# Author: Zijian Yue
# Date: 5/3/2022


# all the Util functions for DatabaseManager.py should go here
from datetime import date

class DatabaseManagerUtility:
    def __init__(self):
        pass

    def AgeCaculation(self, User_birthday:str):
        # return the age of the user
        current_time = (date.today().strftime("%d/%m/%Y")).split('/')
        year = int(current_time[2])
        month = int(current_time[1])
        day = int(current_time[0])

        # '01-01-0001' d/m/y
        birthyear = int(User_birthday[6:10])
        birthmonth = int(User_birthday[3:5])
        birthday = int(User_birthday[0:2])
        
        # check the user's birthday has been passed or not
        if birthmonth > month or(birthmonth == month and birthday > day):
            return year - birthyear - 1

        return year - birthyear
    
    
    pass



