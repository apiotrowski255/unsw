# Author: Zijian Yue, James Saludes
# Date: 19/3/2022


# StatsAndSearchManager
# provide queries realted to Stats table and gerneral search to all tables

import sqlite3


class StatsAndSearchManager:
    def __init__(self, conn : sqlite3.Connection, cursor : sqlite3.Cursor):
        self.conn = conn
        self.cursor = cursor


    # gerneral search function 
    def general_search(self, table_name:str, colounm_name:str, key:str):
        # return all infromation related to the user with the given uid
        cursor = self.conn.cursor()
        key = "'" + key + "'"
        cursor.execute("SELECT * FROM {} WHERE {} = {} ".format(table_name, colounm_name, key) )
        msg = cursor.fetchall()
        # if the item does not exist return None
        if len(msg) == 0:
            return None
        # else return a tuple contains all users infromation
        cursor.close()
        return msg[0]

        # gerneral search function 
    def general_multipe_search(self, table_name:str, colounm_name:str, key:str):
        # return all infromation related to the user with the given uid
        key = "'" + key + "'"
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM {} WHERE {} = {} ".format(table_name, colounm_name, key) )
        msg = cursor.fetchall()
        # if the item does not exist return None
        if len(msg) == 0:
            return None
        # else return a tuple contains all users infromation
        cursor.close()
        return msg


    # udpate a field in stats table
    def stat_update_stat_value(self, field:str, new_value:str ):
        new_value = '"' + new_value + '"'
        cursor = self.conn.cursor()
        msg = """UPDATE STATS SET {} = {}""".format(field, new_value)
        # update the data to the presistent database
        cursor.execute(msg)
        self.conn.commit()
        cursor.close()


    # Search if string is in column name of database
    def string_search(self, table_name:str, column_name:list, key:str):
        if len(column_name) < 1:
            return "error"

        #add wildcard operator
        key = "'%" + key + "%'"

        # play around the string cat
        msg = "SELECT * FROM {} WHERE ".format(table_name)
        for colounms in column_name:
            msg += "{} LIKE {} OR ".format(colounms, key)
        cursor = self.conn.cursor()
        cursor.execute(msg[0:-3])
        msg = cursor.fetchall()
        cursor.close()
        # if the item does not exist return None
        if len(msg) == 0:
            return None
        # else return a tuple contains all users infromation
        return msg 
    
    
    # return all records stored in a table
    def general_return_a_table(self, table_name:str):
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM {}".format(table_name) )
        msg = cursor.fetchall()
        cursor.close()
        return msg
