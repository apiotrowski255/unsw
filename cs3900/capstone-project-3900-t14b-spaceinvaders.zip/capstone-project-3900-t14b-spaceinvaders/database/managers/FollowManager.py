# Author: Zijian Yue
# Date: 19/3/2022


# BooksTableManager
# provide queries realted to books table to the database manager

import sqlite3
import time

class FollowManager:
    
    def __init__(self, conn : sqlite3.Connection, cursor : sqlite3.Cursor):
        self.conn = conn
        self.cursor = cursor
        
    
    # for an user to follow another user
    def follow_other_people(self, uid_user:str, uid_following:str):
        
        # process data
        uid_user = "'" + uid_user + "'"
        uid_following = "'" + uid_following + "'"
        timestamp = '"' + time.strftime("%Y/%m/%d") + '"'
        
        # check on the constrains
        if uid_user == uid_following:
            return "users cannot follow themselves"
        
        self.cursor.execute("SELECT * FROM USERS WHERE UID = {}".format(uid_user))
        msg = self.cursor.fetchall()
        if len(msg) == 0:
            return "user id does not exist"
        
        self.cursor.execute("SELECT * FROM USERS WHERE UID = {}".format(uid_following))
        msg = self.cursor.fetchall()
        if len(msg) == 0:
            return "uid_following does not exist"
        
        self.cursor.execute("SELECT * FROM FOLLOW WHERE UID = {} AND FOLLOWING_ID = {}".format(uid_user, uid_following))
        msg = self.cursor.fetchall()
        if len(msg) != 0:
            return "This user has been follwed"
        
        # insert data into the table
        msg = '''INSERT INTO FOLLOW
                 (UID, FOLLOWING_ID, FOLLOWING_TIME) 
                 VALUES 
                 ({},{},{})
              '''.format(uid_user, uid_following, timestamp)
                           
        self.cursor.execute(msg)
        self.conn.commit()
        
    
    # for an user to unfollow another user
    def unfollow_other_people(self, uid_user:str, uid_following:str):
        
        # search the record first
        self.cursor.execute("SELECT * FROM FOLLOW WHERE UID = {} AND FOLLOWING_ID = {}".format(uid_user, uid_following))
        msg = self.cursor.fetchall()
        if len(msg) == 0:
            return "The record does not exist"
        
        # process data
        uid_user = "'" + uid_user + "'"
        uid_following = "'" + uid_following + "'"
        
        # insert data into the table
        msg = '''DELETE FROM FOLLOW
                 WHERE UID = {} AND FOLLOWING_ID = {}
              '''.format(uid_user, uid_following)
                           
        self.cursor.execute(msg)
        self.conn.commit()

    def follow_check_following(self, uid_user:str, uid_following:str):
        # process data
        uid_user = "'" + uid_user + "'"
        uid_following = "'" + uid_following + "'"

        # search the record first
        self.cursor.execute("SELECT * FROM FOLLOW WHERE UID = {} AND FOLLOWING_ID = {}".format(uid_user, uid_following))
        msg = self.cursor.fetchall()
        if len(msg) == 0:
            return False

        return True


    def follow_check_following(self, uid_user:str, uid_following:str):
        # process data
        uid_user = "'" + uid_user + "'"
        uid_following = "'" + uid_following + "'"

        # search the record first
        self.cursor.execute("SELECT * FROM FOLLOW WHERE UID = {} AND FOLLOWING_ID = {}".format(uid_user, uid_following))
        msg = self.cursor.fetchall()
        if len(msg) == 0:
            return False

        return True