# Author: Zijian Yue
# Date: 8/4/2022


# UsersTableManager
# provide queries realted to Users table to the database manager

import sqlite3
import time 

class PostsTableManager:
    def __init__(self, conn : sqlite3.Connection, cursor : sqlite3.Cursor):
        self.conn = conn
        self.cursor = cursor


    # create a new post in the database
    def posts_create_new_post(self, uid:str, title:str, content:str):
        
        # process data
        uid = "'" + uid + "'"
        title = "'" + title + "'"
        content = "'" + content + "'"
        
        # check uid exists
        self.cursor.execute("SELECT * FROM USERS WHERE UID = {}".format(uid))
        msg = self.cursor.fetchall()
        if msg is None:
            return "User does not exist"
        
        # get pid and timestamp
        pid = "'" + self.local_get_next_pid() + "'"
        timestamp = '"' + time.strftime("%d-%m-%YT%H:%M:%S") + '"'
        
        create_posts_msg = '''INSERT INTO POSTS
                                (UID, PID, TITLE, CONTENT, COMMENT_ID_COUNTER, TIME_CREATED, EDITED, TIME_EDITED) 
                                VALUES 
                                ({},{},{},{},{},{},{},{})
                           '''.format(uid, pid, title, content, "'1'", timestamp, "'no'", "'none'")
        self.cursor.execute(create_posts_msg)
        self.conn.commit()
        
        
    # update the post    
    def posts_update_post(self, pid:str, uid:str, new_content:str):
        
        # auth user
        msg = self.local_auth_user(uid, pid)
        if msg != "passed":
            return msg
        
        # process data
        uid = "'" + uid + "'"
        pid = "'" + pid + "'"
        
        # update the content
        new_content = "'" + new_content + "'"
        timestamp = '"' + time.strftime("%d-%m-%YT%H:%M:%S") + '"'
        self.cursor.execute("UPDATE POSTS SET CONTENT = {} WHERE PID = {}".format(new_content, pid))
        self.cursor.execute("UPDATE POSTS SET EDITED = {} WHERE PID = {}".format("'yes'", pid))
        self.cursor.execute("UPDATE POSTS SET TIME_EDITED = {} WHERE PID = {}".format(timestamp, pid))
        self.conn.commit()
        
        return "success"

    
    # delete a post
    def posts_delete_a_post(self, uid:str, pid:str):
        
        # auth user
        msg = self.local_auth_user(uid, pid)
        if msg != "passed":
            return msg
        
        # process data
        uid = "'" + uid + "'"
        pid = "'" + pid + "'"
       
        # delete the posts and all the assciated comments
        self.cursor.execute("DELETE FROM POSTS WHERE PID = {}".format(pid))
        self.cursor.execute("DELETE FROM COMMENTS WHERE PID = {}".format(pid))
        self.conn.commit()
        
        return "success"
    
    # return the total number of active posts
    def posts_get_total_number(self):
        self.cursor.execute("SELECT COUNT(PID) FROM POSTS")
        msg = self.cursor.fetchall()
        return int(msg[0][0])
    
           
    # get the next aviliable pid for the post
    def local_get_next_pid(self):
        self.cursor.execute("SELECT PID_COUNTER FROM STATS")
        msg = self.cursor.fetchall()
        new_pid_counter = int(msg[0][0]) + 1

        # store the new value back
        self.cursor.execute("UPDATE STATS SET PID_COUNTER = {}".format(str(new_pid_counter)))
        self.conn.commit()
        
        return msg[0][0]
    
    
    # authenticate an user
    def local_auth_user(self, uid:str, pid:str):
       
        # process data
        uid = "'" + uid + "'"
        pid = "'" + pid + "'"
        
        # check uid exists
        self.cursor.execute("SELECT * FROM USERS WHERE UID = {}".format(uid))
        msg = self.cursor.fetchall()
        if len(msg) == 0:
            return "User does not exist"
        
        # check pid exists
        self.cursor.execute("SELECT * FROM POSTS WHERE PID = {}".format(pid))
        msg = self.cursor.fetchall()
        if len(msg) == 0:
            return "Post does not exist"
        
        # check uid is the owner of pid
        self.cursor.execute("SELECT * FROM POSTS WHERE PID = {} AND UID = {}".format(pid, uid))
        msg = self.cursor.fetchall()
        if len(msg) == 0:
            return "User does not own this post"
        
        return "passed"