# Author: Zijian Yue
# Date: 19/3/2022


# ReadsTableManager
# provide queries realted to reads table to the database manager

import sqlite3


class ReadTableManager:
    def __init__(self, conn : sqlite3.Connection, cursor : sqlite3.Cursor):
        self.conn = conn
        self.cursor = cursor


    # create a record, and add this record to the database
    #last_time_read : "%d/%m/%Y %H:%M:%S"
    def read_create_new_record(self, uid:str, bid:str, comment:str, rating:str, last_time_read:str, total_reading_time:str):
        # check if this record already existed
        if self.read_get_a_record(uid, bid) != None:
            return "Record already exists"

        # process the data, make sure all the strings are quoted
        uid = "'" + uid + "'"
        bid  = "'" + bid + "'"
        comment = "'" + comment + "'"
        last_time_read = "'" + last_time_read + "'"
        total_reading_time = "'" + total_reading_time + "'"


        # fill book's infromation to the table
        create_read_msg = '''INSERT INTO READ
                                (UID, BID, COMMENT, RATING, LAST_TIME_READ, TOTAL_READING_TIME)
                                VALUES
                                ({},{},{},{},{},{})
                           '''.format(uid, bid, comment, rating, last_time_read, total_reading_time)

        self.cursor.execute(create_read_msg)
        self.conn.commit()

        # if the book is successfully created return a msg
        return "Record is successfully added"


    # Note: filed must be all capital
    # formula input_list = [field, new_value]
    def read_update_read_table(self, uid:str, bid:str, field:str, new_value:str):
        # turn the given field to upper cases to match with the db
        field = field.upper()

        # if the record does not exists in the database, return false
        if self.read_get_a_record(uid,bid) == None:
            return "Record does not exists"

        # if the given field is wrong
        if field not in ("COMMENT", "RATING", "LAST_TIME_READ", "TOTAL_READING_TIME"):
            return "Field does not exist or attmeping to change key(uid) or key(bid)"

        # process the data, make sure all the strings are quoted
        new_value = '"' + new_value + '"'

        msg = """UPDATE READ SET {} = {} WHERE UID = {} AND BID = {}""".format(field, new_value, uid, bid)

        # update the data to the presistent database
        self.cursor.execute(msg)
        self.conn.commit()

        # if no exceptions occurs, return True
        return "Update is successful"


    # return the total number of records related to one book in the database
    def read_get_users_by_book(self, bid):
        bid = "'" + bid + "'"
        self.cursor.execute("SELECT UID FROM READ WHERE BID = {}".format(bid))
        msg = self.cursor.fetchall()
        return self.local_DBtuple_to_str(msg)


    # return all the books the given user is reading
    def read_get_books_by_user(self, uid):
        uid = "'" + uid + "'"
        self.cursor.execute("SELECT BID FROM READ WHERE UID = {}".format(uid))
        msg = self.cursor.fetchall()
        return self.local_DBtuple_to_str(msg)


    # return overall reading time
    def read_get_total_reading_time(self):
        self.cursor.execute("SELECT SUM(TOTAL_READING_TIME) FROM READ")
        msg = self.cursor.fetchall()
        return int(msg[0][0])


    # get all rating info from READ
    def read_get_all_rating(self):
        # select bid, uid, rating columns from READ table
        query = '''SELECT BID, UID, RATING FROM READ '''
        self.cursor.execute(query)

        msg = self.cursor.fetchall()

        # if the item does not exist return None
        if len(msg) == 0:
            return None

        # else return a tuple contains all information to this book
        return msg


    # search for a reading record using uid and bid
    def read_get_a_record(self, uid:str , bid:str):
        # process the given keys
        uid = "'" + uid + "'"
        bid = "'" + bid + "'"

        # check is the book with given keys existed
        self.cursor.execute('''SELECT *
                            FROM READ
                            WHERE UID = {} AND BID = {}
        '''.format(uid, bid)
        )
        msg = self.cursor.fetchall()

        # if the item does not exist return None
        if len(msg) == 0:
            return None

        # else return a tuple contains all information to this book
        return msg[0]


    # turning tuple to a string
    def local_DBtuple_to_str(self, DBtuple:tuple):
        return_list = []
        for tup in DBtuple:
            return_list.append(tup[0])
        return return_list


    # get all rating info from READ
    def read_get_all_rating_tags(self, query_tags:str):
        # select bid, uid, rating columns from READ table
        #format string for sql query
        tags = "'%" + query_tags + "%'"

        query = '''SELECT READ.BID, READ.UID, READ.RATING FROM READ
                    INNER JOIN BOOKS ON BOOKS.BID = READ.BID
                    WHERE TAGS LIKE {}
        '''.format(tags)
        self.cursor.execute(query)

        msg = self.cursor.fetchall()

        # if the item does not exist return None
        if len(msg) == 0:
            return None

        # else return a tuple contains all information to this book
        return msg


    # get all ratings from followed users
    def read_get_all_rating_followedusers(self, uid:str):
        # select bid, uid, rating columns from READ table
        uid = "'" + uid + "'"

        query = ''' SELECT READ.BID, READ.UID, READ.RATING
                    FROM USERS
                    INNER JOIN FOLLOW ON USERS.UID = FOLLOW.UID
                    INNER JOIN READ ON READ.UID = FOLLOW.FOLLOWING_ID
                    WHERE USERS.UID = {}
        '''.format(uid)
        self.cursor.execute(query)
        msg = self.cursor.fetchall()

        # if the item does not exist return None
        if len(msg) == 0:
            return None

        # else return a tuple contains all information to this book
        return msg

    # get latest read / reviewed book ids from a user
    def read_get_latest_reviews(self, uid:str, bookcount:int):
        # select bid, uid, rating columns from READ table
        uid = "'" + uid + "'"

        query = ''' SELECT READ.BID, READ.UID, READ.RATING
                    FROM READ
                    WHERE READ.UID = {}
                    ORDER BY READ.LAST_TIME_READ DESC
                    LIMIT ({})
        '''.format(uid, bookcount)
        self.cursor.execute(query)
        msg = self.cursor.fetchall()

        # if the item does not exist return None
        if len(msg) == 0:
            return None

        # else return a tuple contains all information to this book
        return msg
