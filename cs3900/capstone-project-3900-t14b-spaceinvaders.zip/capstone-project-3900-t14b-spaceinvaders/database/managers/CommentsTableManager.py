# Author: Zijian Yue
# Date: 08/4/2022


# UsersTableManager
# provide queries realted to Users table to the database manager

import sqlite3
import time 

class CommentsTableManager:
    def __init__(self, conn : sqlite3.Connection, cursor : sqlite3.Cursor):
        self.conn = conn
        self.cursor = cursor

    def comments_create_new_comment(self, uid:str, pid:str, content:str):
        
        # process data
        comment_id = "'" + self.local_get_next_comid(pid) + "'"
        timestamp = '"' + time.strftime("%d-%m-%YT%H:%M:%S") + '"'
        uid = "'" + uid + "'"
        pid = "'" + pid + "'"
        content = "'" + content + "'"
        
        # check uid exists
        self.cursor.execute("SELECT * FROM USERS WHERE UID = {}".format(uid))
        msg = self.cursor.fetchall()
        if msg is None:
            return "User does not exist"
        
        # check the pid exists
        self.cursor.execute("SELECT * FROM POSTS WHERE PID = {}".format(pid))
        msg = self.cursor.fetchall()
        if msg is None:
            return "Post does not exist"

        
        create_comments_msg = '''INSERT INTO COMMENTS
                                (UID, PID, COMMENT_ID, CONTENT, TIME_CREATED, EDITED, TIME_EDITED) 
                                VALUES 
                                ({},{},{},{},{},{},{})
                           '''.format(uid, pid, comment_id, content, timestamp, "'no'", "'none'")
        self.cursor.execute(create_comments_msg)
        self.conn.commit()
        
        return "success"
    
    
    # delete a comment
    def comments_update_a_comment(self, uid:str, comment_id:str, pid:str, new_content:str):
        # auth user
        msg = self.local_auth_user(uid, comment_id, pid)
        if msg != "passed":
            return msg
        
        # process data
        uid = "'" + uid + "'"
        pid = "'" + pid + "'"
        comment_id = "'" + comment_id + "'"
        new_content = "'" + new_content + "'"
        timestamp = '"' + time.strftime("%d-%m-%YT%H:%M:%S") + '"'
        
        # update the comment table
        self.cursor.execute("UPDATE COMMENTS SET CONTENT = {} WHERE COMMENT_ID = {} AND PID = {} AND UID = {}".format(new_content, comment_id, pid, uid))
        self.cursor.execute("UPDATE COMMENTS SET EDITED = {} WHERE COMMENT_ID = {} AND PID = {} AND UID = {}".format("'yes'", comment_id, pid, uid))
        self.cursor.execute("UPDATE COMMENTS SET TIME_EDITED = {} WHERE COMMENT_ID = {} AND PID = {} AND UID = {}".format(timestamp, comment_id, pid, uid))
        self.conn.commit()
        
        return "success"
    
    # delete a comment
    def comments_delete_a_comment(self, uid:str, comment_id:str, pid:str):
        # auth user
        msg = self.local_auth_user(uid, comment_id, pid)
        if msg != "passed":
            return msg
        
        # process data
        uid = "'" + uid + "'"
        pid = "'" + pid + "'"
        comment_id = "'" + comment_id + "'"
        
        # delete the comment in the post
        self.cursor.execute("DELETE FROM COMMENTS WHERE PID = {} AND COMMENT_ID = {} AND UID = {}".format(pid, comment_id, uid))
        self.conn.commit()
        
        return "success" 
    
    # return the total number of comments in the database
    def comments_get_total_number(self):
        self.cursor.execute("SELECT COUNT(COMMENT_ID) FROM COMMENTS")
        msg = self.cursor.fetchall()
        return int(msg[0][0])
    
    
    # return the total number of comments in a post
    def comments_number_comments_from_post(self, pid:str):
        # process data
        pid = "'" + pid + "'"
        
        self.cursor.execute("SELECT COUNT(COMMENT_ID) FROM COMMENTS WHERE PID = {}".format(pid))
        msg = self.cursor.fetchall()
        return int(msg[0][0])
        
        
    # get the next aviliable com_id for the comment
    def local_get_next_comid(self, pid:str):
        # process data
        pid = "'" + pid + "'"
        self.cursor.execute("SELECT COMMENT_ID_COUNTER FROM POSTS WHERE PID = {}".format(pid))
        msg = self.cursor.fetchall()
        new_comid_counter = int(msg[0][0]) + 1

        # store the new value back
        self.cursor.execute("UPDATE POSTS SET COMMENT_ID_COUNTER = {} WHERE PID = {}".format(str(new_comid_counter), pid) )
        self.conn.commit()
        
        return msg[0][0]
    
    
    # authenticate an user
    def local_auth_user(self, uid:str, comment_id:str, pid:str):
        
        # process data
        uid = "'" + uid + "'"
        pid = "'" + pid + "'"
        comment_id = "'" + comment_id + "'"
        
        # check uid exists
        self.cursor.execute("SELECT * FROM USERS WHERE UID = {}".format(uid))
        msg = self.cursor.fetchall()
        if len(msg) == 0:
            return "User does not exist"
        
        # check pid exists
        self.cursor.execute("SELECT * FROM POSTS WHERE PID = {}".format(pid))
        msg = self.cursor.fetchall()
        if len(msg) == 0:
            return "Post does not exist"
        
        # check comid exists
        self.cursor.execute("SELECT * FROM COMMENTS WHERE PID = {} AND COMMENT_ID = {}".format(pid, comment_id))
        msg = self.cursor.fetchall()
        if len(msg) == 0:
            return "Comment does not exists in the post"
        
        # check uid is the owner of the comment
        self.cursor.execute("SELECT * FROM COMMENTS WHERE PID = {} AND COMMENT_ID = {} AND UID = {}".format(pid, comment_id, uid))
        msg = self.cursor.fetchall()
        if len(msg) == 0:
            return "User do not own this comment"
        
        return "passed"
        


