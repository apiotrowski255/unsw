# Author: Zijian Yue
# Date: 12/04/2022

# Report table manager
# provide queries realted to report table to the database manager

import sqlite3
import time

class ReportTableManager:
    
    def __init__(self, conn : sqlite3.Connection, cursor : sqlite3.Cursor):
        self.conn = conn
        self.cursor = cursor
        
    
    # for an user to report a review
    def report_review(self, reporting_uid:str, reported_uid:str, reported_bid:str, reason:str):
        # process data
        reporting_uid = "'" + reporting_uid + "'"
        reported_uid = "'" + reported_uid + "'"
        reason = "'" + reason + "'"
        reported_bid = "'" + reported_bid + "'"
        
        # checkthe contrain
        msg = self.local_check_constrain(reporting_uid, reported_uid)
        if msg != "passed":
            return msg
        
        # prevent the user from spamming the system
        # check the user is reporting the same user for comments
        self.cursor.execute("SELECT * FROM REPORT WHERE REPORTING_UID = {} AND REPORTED_UID = {} AND REPORTED_BID = {}".format(reporting_uid, reported_uid, reported_bid))
        msg = self.cursor.fetchall()
        if len(msg) != 0:
            return "reporting id has already reported the same review"
        
        # create the case
        self.local_create_case(reporting_uid, reported_uid, reason, reported_bid, "''", "''")
        
        return "success"
        
        
    # for an user to report another user including the admin
    def report_post_comment(self, reporting_uid:str, reported_uid:str, reason:str, reported_postid:str, reported_commentid:str):
        
        # process data
        reporting_uid = "'" + reporting_uid + "'"
        reported_uid = "'" + reported_uid + "'"
        reason = "'" + reason + "'"
        reported_postid = "'" + reported_postid + "'"
        reported_commentid = "'" + reported_commentid + "'"
        
        # check the constain
        msg = self.local_check_constrain(reporting_uid, reported_uid)
        if msg != "passed":
            return msg
        
        # prevent the user from spamming the system
        # check the user is reporting the same user for comments
        self.cursor.execute("SELECT * FROM REPORT WHERE REPORTING_UID = {} AND REPORTED_UID = {} AND REPORTED_POST_ID = {} AND REPORTED_COMMENT_ID = {}".format(reporting_uid, reported_uid, reported_postid, reported_commentid))
        msg = self.cursor.fetchall()
        if len(msg) != 0:
            return "reporting id has already reported reproted id"
        
        # create the case
        self.local_create_case(reporting_uid, reported_uid, reason, "''", reported_postid, reported_commentid)
        
        return "Success"
        
        
    # for admin to process the report
    def report_process_case(self, admin_uid:str, rid:str, msg:str):
        
        admin_uid = "'" + admin_uid + "'"
        rid = "'" + rid + "'"
        message = "'" + msg + "'"
        
        # check the the given admin id is admin
        self.cursor.execute("SELECT * FROM USERS WHERE UID = {}".format(admin_uid))
        msg = self.cursor.fetchall()
        if len(msg) == 0:
            return "Admin does not exist"
        elif msg[0][1] != "admin":
            return "No permission to process"
        
        # check the rid exists
        self.cursor.execute("SELECT * FROM REPORT WHERE RID = {}".format(rid))
        msg = self.cursor.fetchall()
        if len(msg) == 0:
            return "reporting case does not exist"
        
        # update the status of the case
        self.cursor.execute("UPDATE REPORT SET ADMIN_MESSAGE = {} WHERE RID = {}".format(message, rid))
        self.conn.commit()
        
        return "Success"
        
        
    # get the next aviliable rid for the report cases
    def local_get_next_rid(self):
        self.cursor.execute("SELECT RID FROM STATS")
        msg = self.cursor.fetchall()
        new_rid = int(msg[0][0]) + 1

        # store the new value back
        self.cursor.execute("UPDATE STATS SET RID = {}".format(str(new_rid)))
        self.conn.commit()
        
        return msg[0][0]
    
    
    # check constrains
    def local_check_constrain(self, reporting_uid:str, reported_uid:str):
        # check on the constrains
        if reporting_uid == reported_uid:
            return "users cannot report themselves"
        
        # check the reporting id exists
        self.cursor.execute("SELECT * FROM USERS WHERE UID = {}".format(reporting_uid))
        msg = self.cursor.fetchall()
        if len(msg) == 0:
            return "reporting_uid does not exist"
        
        # check the reported id exists
        self.cursor.execute("SELECT * FROM USERS WHERE UID = {}".format(reported_uid))
        msg = self.cursor.fetchall()
        if len(msg) == 0:
            return "reported_uid does not exist"
        
        return "passed"
    
    
    # create a new case
    def local_create_case(self, reporting_uid:str, reported_uid:str, reason:str, reported_bid:str, reported_postid:str, reported_commentid:str):
        # insert data into the table
        timestamp = '"' + time.strftime("%d-%m-%YT%H:%M:%S") + '"'
        rid = "'" + self.local_get_next_rid() + "'"
        msg = '''INSERT INTO REPORT
                 (RID, REPORTING_UID, REPORTED_UID, REASON, REPORTING_TIME, ADMIN_MESSAGE, REPORTED_BID, REPORTED_POST_ID, REPORTED_COMMENT_ID) 
                 VALUES 
                 ({},{},{},{},{},{},{},{},{})
              '''.format(rid, reporting_uid, reported_uid, reason, timestamp, "''", reported_bid, reported_postid, reported_commentid)
        
        self.cursor.execute(msg)
        self.conn.commit()