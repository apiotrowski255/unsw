# Author: Zijian Yue
# Date: 19/3/2022


# UsersTableManager
# provide queries realted to Users table to the database manager

import sqlite3
import time 

class UsersTableManager:
    def __init__(self, conn : sqlite3.Connection, cursor : sqlite3.Cursor):
        self.conn = conn
        self.cursor = cursor


    # create a new user, and add this user to the database
    def user_create_new_user(self, username:str, password:str, birthday:str ,profile_pic:str, role:str, email:str, self_intro:str):
        # use username to check
        if self.users_table_search("USERNAME", username) != None:
            return "Username already exists"

        # process the data, make sure all the strings are quoted
        uid = '"' + self.user_get_next_uid() + '"'
        username = '"' + username + '"'
        password = '"' + password + '"'
        birthday = '"' + birthday + '"'
        profile_pic = '"' + profile_pic + '"'
        email = '"' + email + '"'
        self_intro = '"' + self_intro + '"'
        timestamp = '"' + time.strftime("%Y/%m/%d") + '"'
        # we assume the first user needs to be admin
        if uid == '"1"':
            role = "'admin'"
        else:
            role = '"' + role + '"'
        
        # fill user's infromation to the table
        create_users_msg = '''INSERT INTO USERS
                                (UID, ROLE, PASSWORD, USERNAME, BIRTHDAY, SELF_INTRODUCTION, EMAIL, PICTURE, STATUS, ADDED_TIME) 
                                VALUES 
                                ({},{},{},{},{},{},{},{},{},{})
                           '''.format(uid, role, password, username, 
                                      birthday, self_intro, email, profile_pic, '"online"', timestamp)
        self.cursor.execute(create_users_msg)
        self.conn.commit()

        # if the user is successfully added
        # update the stats table
        # retrive the total number of registered users
        self.cursor.execute("SELECT UID_COUNTER FROM STATS")
        num_str = self.cursor.fetchall()
        user_number = int(num_str[0][0]) + 1

        # store the new value back
        self.cursor.execute("UPDATE STATS SET UID_COUNTER = {}".format(str(user_number)))
        self.conn.commit()

        # if the user is successfully created return True
        return "User is successfully added"


    # Note: filed must be all capital
    # formula input_list = [field, new_value]
    def user_update_user_table(self, uid:str, field:str, new_value:str):
        # turn the given field to upper cases to match with the db
        field = field.upper()

        # if the user does not exists in the database, return false
        if self.users_table_search("UID", uid) == None:
            return "User does not exists"

        if field not in ("ROLE","PASSWORD","USERNAME","BIRTHDAY","SELF_INTRODUCTION","EMAIL","PICTURE", "STATUS", "GOAL"):
            return "Field does not exist"

        # if the user wants to update username
        if field == "USERNAME":
            if self.users_table_search("USERNAME", new_value) != None:
                return "Username already exists"

        # process the data, make sure all the strings are quoted
        new_value = '"' + new_value + '"'

        msg = """UPDATE USERS SET {} = {} WHERE UID = {}""".format(field, new_value, uid)

        # update the data to the presistent database
        self.cursor.execute(msg)
        self.conn.commit()

        # if no exceptions occurs, return True
        return "Update is successful"


    # return the total number of registered users
    def user_get_total_number(self):
        self.cursor.execute("SELECT COUNT(UID) FROM USERS")
        msg = self.cursor.fetchall()
        return int(msg[0][0])


    # return the total number of registered users
    def user_get_next_uid(self):
        self.cursor.execute("SELECT UID_COUNTER FROM STATS")
        msg = self.cursor.fetchall()
        return msg[0][0]


    # return all infromation related to the user with the given field and key
    def users_table_search(self, colounm_name:str, key:str):
        key = "'" + key + "'"
        self.cursor.execute("SELECT * FROM USERS WHERE {} = {} ".format( colounm_name, key) )
        msg = self.cursor.fetchall()
        # if the item does not exist return None
        if len(msg) == 0:
            return None
        # else return a tuple contains all users infromation
        return msg[0]
