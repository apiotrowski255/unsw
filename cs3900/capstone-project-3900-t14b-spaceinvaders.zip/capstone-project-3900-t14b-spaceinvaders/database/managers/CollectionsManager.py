# Author: Zijian Yue
# Date: 19/3/2022


# UsersTableManager
# provide queries realted to Users table to the database manager

import sqlite3
import time


class CollectionsManager:
    def __init__(self, conn : sqlite3.Connection, cursor : sqlite3.Cursor):
        self.conn = conn
    

    # create a new collection and link this new collection to both user and books 
    def collections_create_and_link_new_collection(self, uid:str, collection_name:str, picture:str, comments:str, tags:str, list_bids:list):
        # check does the given user exceed the maximum number of books
        cursor = self.conn.cursor()
        cursor.execute("SELECT COLLECTION_LIMIT FROM STATS")
        msg = cursor.fetchall()
        hard_limit = int(msg[0][0])

        current_collections = self.collections_search_collections("UID", uid)

        if current_collections == None:
            current_collections = []
            
        # count from zero
        if len(current_collections) >= hard_limit:
            return "Exceed the maximum number of collections the user create"

        # create a unlinked collection
        new_cid = self.local_create_new_collection(collection_name, picture, comments, tags)
        # linke the connection with uid 
        create_users_msg = '''INSERT INTO OWN
                                (CID, UID) 
                                VALUES 
                                ({},{})
                           '''.format(new_cid, "'" + uid + "'")
        cursor.execute(create_users_msg)
        self.conn.commit()

        # link the connection with books
        self.collections_add_new_books(new_cid, list_bids)

        return "Create is successful"
    
        
    # delete existing collection
    def collections_delete_collection(self, cid:str):
        # process the data
        cid = "'" + cid + "'"
        cursor = self.conn.cursor()
        # checking collection has been deleted
        cursor.execute(
                '''SELECT COUNT(*)
                   FROM COLLECTIONS
                   WHERE CID = {};
                '''.format(cid)
        )
        msg = cursor.fetchall()
        if msg == 0:
            return "Error: Collection does not exist"

        # delete specified collection in the database
        cursor.execute(
                '''DELETE
                   FROM COLLECTIONS
                   WHERE CID = {};
                '''.format(cid)
        )
        cursor.execute(
                '''DELETE
                   FROM OWN
                   WHERE CID = {};
                '''.format(cid)
        )
        cursor.execute(
                '''DELETE
                   FROM INCLUDE
                   WHERE CID = {};
                '''.format(cid)
        ) 
        msg = cursor.fetchall()
        self.conn.commit()
        cursor.close()

    # add new books to a collection
    def collections_add_new_books(self, cid:str, list_bids:list):
        # process the data
        cid = '"' + cid + '"'
        timestamp = '"' + time.strftime("%Y/%m/%d") + '"'
        cursor = self.conn.cursor()
        # add each of the book inside the list_bids into the include table
        for bid in list_bids:
            
            # process data
            bid = '"' + bid + '"'
            
            # check the book exists
            msg = "SELECT * FROM BOOKS WHERE BID = {}".format(bid)
            cursor.execute(msg)
            msg = cursor.fetchall()
            # if the books does not exists
            if len(msg) == 0:
                return "Failed, book id does not exists"
            
            # check the book already exists
            msg = "SELECT * FROM INCLUDE WHERE CID = {} AND BID = {}".format(cid, bid)
            cursor.execute(msg)
            msg = cursor.fetchall()
            # if the book has not been included
            if len(msg) == 0:
                cursor.execute(
                    '''INSERT INTO INCLUDE
                                (CID, BID, ADDED_TIME) 
                                VALUES 
                                ({},{},{})
                    '''.format(cid, bid, timestamp)
                )
        self.conn.commit()
        cursor.close()

    # Note: filed must be all capital
    # formula input_list = [field, new_value]
    def collections_update_collection_table(self, cid:str, field:str, new_value:str):
        # turn the given field to upper cases to match with the db
        field = field.upper()

        # if the user does not exists in the database, return false
        if self.local_collections_table_search("CID", cid) == None:
            return "Collection does not exists"

        if field not in ("ROLE", "COLLECTION_NAME", "PICTURE", "COMMENTS", "TAGS"):
            return "Field does not exist"

        # process the data, make sure all the strings are quoted
        new_value = '"' + new_value + '"'

        msg = """UPDATE COLLECTIONS SET {} = {} WHERE CID = {}""".format(field, new_value, cid)
        cursor = self.conn.cursor()
        # update the data to the presistent database
        cursor.execute(msg)
        self.conn.commit()
        cursor.close()

        # if no exceptions occurs, return True
        return "Update is successful"
    
    
    # delete a book in a collection
    def collections_delete_books(self, cid:str, bids:list):
        # process data
        cid = "'" + cid + "'"
        cursor = self.conn.cursor()
        for bid in bids:
            # process data
            bid = "'" + bid + "'"    
            
            # check the book exists
            msg = "SELECT * FROM INCLUDE WHERE CID = {} AND BID = {}".format(cid, bid)
            cursor.execute(msg)
            msg = cursor.fetchall()
            if len(msg) == 0:
                return "Failed book id does not exists"
        
            # if the book exists in the collection, delete it
            msg = "DELETE FROM INCLUDE WHERE CID = {} AND BID = {}".format(cid, bid)
            cursor.execute(msg)
            
        self.conn.commit()
        cursor.close()


    # return the total number of collections created 
    def collections_get_total_number(self):
        cursor = self.conn.cursor()
        cursor.execute("SELECT COUNT(CID) FROM COLLECTIONS")
        msg = cursor.fetchall()
        cursor.close()
        return int(msg[0][0])


    # return the collections based on uid,cid or bid
    def collections_search_collections(self, coloum_name:str, key:str):
        cursor = self.conn.cursor()
        # process the data
        key = '"' + key + '"'
        coloum_name = coloum_name.upper()
        msg = ""

        # check the field
        if coloum_name != "UID" and coloum_name != "CID" and coloum_name != "BID":
            return "Error, field must be bid,uid or cid"

        # search based on the given field and key
        if coloum_name == "UID":
            # search collection own by an user(given uid)
            cursor.execute(
                '''SELECT COLLECTIONS.*
                   FROM COLLECTIONS
                   INNER JOIN OWN
                   ON OWN.UID = {}
                   WHERE COLLECTIONS.CID = OWN.CID
                '''.format(key) 
            )
            msg = cursor.fetchall()
            
        elif coloum_name == "CID":
            # search one collection based on its cid
            cursor.execute("SELECT * FROM COLLECTIONS WHERE {} = {} ".format(coloum_name, key) )
            msg = cursor.fetchall()

        elif coloum_name == "BID":
            # search all collections that includes the given book
            cursor.execute(
                '''SELECT COLLECTIONS.*
                   FROM COLLECTIONS
                   INNER JOIN INCLUDE
                   ON INCLUDE.BID = {}
                   WHERE INCLUDE.CID = COLLECTIONS.CID
                '''.format(key) 
            )
            msg = cursor.fetchall()
        cursor.close()
        # if the item does not exist return None
        if len(msg) == 0:
            return None
        
        # else return a tuple contains all users infromation
        return msg


    # search the book and added time of a book given a collection
    def collections_search_book_and_added_time(self, cid:str):
        # process the data
        cid = "'" + cid + "'"
        cursor = self.conn.cursor()
        # search by joining the tables
        cursor.execute(
                '''SELECT BOOKS.*, INCLUDE.ADDED_TIME
                   FROM INCLUDE 
                   INNER JOIN BOOKS ON INCLUDE.BID = BOOKS.BID
                   WHERE INCLUDE.CID = {};
                '''.format(cid) 
        )

        msg = cursor.fetchall()
        cursor.close()
        # if the item does not exist return None
        if len(msg) == 0:
            return None
     
        # else return a tuple contains all users information
        return msg
    
    
    # search and evaluate tags for a collection
    def collections_get_tag(self, cid:str):
        # process the data
        cid = "'" + cid + "'"
        cursor = self.conn.cursor()
        # check the cid exists
        cursor.execute("SELECT * FROM COLLECTIONS WHERE CID = {}".format(cid))
        msg = cursor.fetchall()
        # if the item does not exist return error msg
        if len(msg) == 0:
            return "No such collection"
    
        # do a query to search all tags of the books in the collection
        cursor.execute(''' SELECT TAGS 
                                FROM BOOKS
                                INNER JOIN INCLUDE ON INCLUDE.CID = {}
                                WHERE BOOKS.BID = INCLUDE.BID
        '''.format(cid))
        tuple_tags = cursor.fetchall()
        cursor.close()
        return self.local_evaluate_the_tags(tuple_tags)

    
    # count total number of books in a collection
    def collections_bookcount(self, cid:str):
        # process the data
        cid = "'" + cid + "'"
        cursor = self.conn.cursor()
        #count by joining the tables
        cursor.execute(
                '''SELECT COUNT(BID)
                   FROM INCLUDE 
                   WHERE CID = {}
                '''.format(cid) 
        )
        msg = cursor.fetchall()[0]
        cursor.close()
        # return book count
        return msg
         
        
#####################################################################################################################################################################

    # create a new collection, and add this collection to the database
    def local_create_new_collection(self, collection_name:str, picture:str, comments:str ,tags:str):
        # the user are allowed to create identical collections, just make sure the user have a name for this collection
        if(collection_name == None or collection_name == ""):
            return "Failed to create collection, as there isn't a name"

        # process the data, make sure all the strings are quoted
        returned_cid = self.local_collections_get_next_cid()
        cid = '"' + returned_cid + '"'
        collection_name = '"' + collection_name + '"'
        picture = '"' + picture + '"'
        comments = '"' + comments + '"'
        tags = '"' + tags + '"'
        timestamp = '"' + time.strftime("%Y/%m/%d") + '"'

        # fill collection's infromation to the table
        create_users_msg = '''INSERT INTO COLLECTIONS
                                (CID, COLLECTION_NAME, PICTURE, COMMENTS, TIME_CREATED, TAGS) 
                                VALUES 
                                ({}, {},{},{},{},{})
                           '''.format(cid, collection_name, picture, comments, timestamp, tags)
        cursor = self.conn.cursor()
        cursor.execute(create_users_msg)
        self.conn.commit()

        # if the collection is successfully created
        # update the stats table
        # retrive the total number of registered users
        cursor.execute("SELECT CID_COUNTER FROM STATS")
        num_str = cursor.fetchall()
        user_number = int(num_str[0][0]) + 1

        # store the new value back
        cursor.execute("UPDATE STATS SET CID_COUNTER = {}".format(str(user_number)))
        self.conn.commit()

        cursor.close()
        # if the user is successfully created return True
        return returned_cid


    # return the next aviliable cid to be assigned to a new created collection
    def local_collections_get_next_cid(self):
        cursor = self.conn.cursor()
        cursor.execute("SELECT CID_COUNTER FROM STATS")
        msg = cursor.fetchall()
        cursor.close()
        return msg[0][0]


    # return all information related to the a collection with the given field and key
    def local_collections_table_search(self, column_name:str, key:str):
        key = "'" + key + "'"
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM COLLECTIONS WHERE {} = {} ".format( column_name, key) )
        msg = cursor.fetchall()
        cursor.close()
        # if the item does not exist return None
        if len(msg) == 0:
            return None
        # else return a tuple contains all users information
        return msg[0]
    
    
    # evaluate the tags
    # ("romance + drama", "fantasy", )
    def local_evaluate_the_tags(self, tuple_tags):
        dict_tags = {}
        list_input_tags = list(tuple_tags)
        
        
        for tags in list_input_tags:
            # "break" the tag
            list_tags = tags[0].split('+')
            for one_tag in list_tags:
                if one_tag in dict_tags:
                    dict_tags[one_tag] += 1
                else:
                    dict_tags[one_tag] = 1
                    
        if len(dict_tags) < 3:
            return list(dict_tags.keys())
        else:
            return list(sorted(dict_tags, key=dict_tags.get, reverse=True)[0:3])