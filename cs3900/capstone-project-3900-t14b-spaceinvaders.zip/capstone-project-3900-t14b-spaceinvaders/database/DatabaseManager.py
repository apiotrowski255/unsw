# Author: Zijian Yue
# Date: 5/3/2022


# Moduels...
import sqlite3
from .managers import DatabaseManagerUtility
from .managers import UsersTableManager
from .managers import StatsAndSearchManager
from .managers import BooksTableManager
from .managers import ReadTableManager
from .managers import CollectionsManager
from .managers import FollowManager
from .managers import PostsTableManager
from .managers import CommentsTableManager
from .managers import ReportTableManager


# DB_manager
# the interface for backend to interact with the database
# DB_manager should provide all necessary queries/updates for back-end to interact with database
# However it also supports "custom query" that the back-end/front-end fellas can write their own query which is not yet included in database Manager
class DataBaseManager:
    def __init__(self):
        # create sql connection and init a cursor object
        self.conn = sqlite3.connect("DataBase.db", check_same_thread = False)
        self.cursor = self.conn.cursor()
        self.util = DatabaseManagerUtility.DatabaseManagerUtility()
        self.users_table = UsersTableManager.UsersTableManager(self.conn, self.cursor)
        self.books_table = BooksTableManager.BooksTableManager(self.conn, self.cursor)
        self.read_table = ReadTableManager.ReadTableManager(self.conn, self.cursor)
        self.stats_and_search = StatsAndSearchManager.StatsAndSearchManager(self.conn, self.cursor)
        self.collections_table = CollectionsManager.CollectionsManager(self.conn, self.cursor)
        self.follow_table = FollowManager.FollowManager(self.conn, self.cursor)
        self.posts_table = PostsTableManager.PostsTableManager(self.conn, self.cursor)
        self.comments_table = CommentsTableManager.CommentsTableManager(self.conn, self.cursor)
        self.report_table = ReportTableManager.ReportTableManager(self.conn, self.cursor)

    # use this function to close the DataBase Connection
    def close_database_connection(self):
        # friendly prompt: please make sure you close the DB connection after you finished using DB
        self.cursor.close()

#######################################################################################################################################################################

    # create a new user in the user table
    def user_create_new_user(self, username:str, password:str, birthday:str, profile_pic:str, role:str, email:str, self_intro:str):
        # call create user in UserTableManager
        return self.users_table.user_create_new_user(username,password,birthday,profile_pic,role,email,self_intro)

    # update an user from the user table
    def user_update_user_table(self, uid:str, field:str, new_value:str):
        return self.users_table.user_update_user_table(uid,field,new_value)

    # return the number of registered users
    def user_get_total_number(self):
       return self.users_table.user_get_total_number()

    # return an user's age
    def user_get_age(self, uid:str):
        # get user's birthday
        return self.util.AgeCaculation(self.general_search("USERS", "UID", uid))

#############################################################################################################################################

    # create a new book in the database
    def book_create_new_book(self, bookname:str, author:str, year:str, country:str, publisher:str, summary:str, picture:str, tags:str):
        return self.books_table.book_create_new_book(bookname, author, year, country, publisher, summary, picture, tags)

    # update a field in book table
    def book_update_book_table(self, bid:str, field:str, new_value:str):
        return self.books_table.book_update_book_table(bid, field, new_value)

    # get the total numbers of book stored in the database
    def book_get_total_number(self):
        return self.books_table.book_get_total_number()

    # get books have avg rate 4 ~ 5
    def book_get_four_five(self):
        return self.books_table.book_get_four_five()

    # evaluate and update the rating field in the book
    def book_update_the_rating(self, bid):
        return self.books_table.book_update_the_rating(bid)

    # return all infromation related to the book with the given field and key
    def book_table_search(self, colounm_name:str, key:str):
        return self.books_table.book_table_search(colounm_name, key)

    #return random books with number specified by 'booknum:int'
    def book_get_random(self, booknum:int):
        return self.books_table.book_get_random(booknum)

    # get all the books which contain the tag
    def book_get_books_by_tag(self, query_tag:str):
        return self.books_table.book_get_books_by_tag(query_tag)

#############################################################################################################################################

    # create a reading record in the database
    def read_create_new_record(self, uid:str, bid:str, comment:str, rating:str, last_time_read:str, total_reading_time:str):
        return self.read_table.read_create_new_record(uid, bid, comment, rating, last_time_read, total_reading_time)

    # update a field in reads table
    def read_update_read_table(self, uid:str, bid:str, field:str, new_value:str):
        return self.read_table.read_update_read_table(uid, bid, field, new_value)

    # return all the users(UIDs in a list) who is reading the given book
    def read_get_users_by_book(self, bid):
        return self.read_table.read_get_users_by_book(bid)

    # return all the books(BIDs in a list) the given user is reading
    def read_get_books_by_user(self, uid):
        return self.read_table.read_get_books_by_user(uid)

     # search for a reading record using uid and bid
    def read_get_a_record(self, uid:str , bid:str):
        return self.read_table.read_get_a_record(uid, bid)

    # get all rating info from READ
    def read_get_all_rating(self):
        return self.read_table.read_get_all_rating()

    # get all rating info from READ
    def read_get_all_rating_tags(self, query_tags:str):
        return self.read_table.read_get_all_rating_tags(query_tags)

    def read_get_all_rating_followedusers(self, uid:str):
        return self.read_table.read_get_all_rating_followedusers(uid)

    def read_get_latest_reviews(self, uid:str, bookcount:int):
        return self.read_table.read_get_latest_reviews(uid, bookcount)

#############################################################################################################################################

    # create a new collection and link this new collection to both user and books
    def collections_create_and_link_new_collection(self, uid:str, collection_name:str, picture:str, comments:str, tags:str, list_bids:list):
        return self.collections_table.collections_create_and_link_new_collection(uid, collection_name, picture, comments, tags, list_bids)

    # update a field in the collections table
    def collections_update_collection_table(self, cid:str, field:str, new_value:str):
        return self.collections_table.collections_update_collection_table(cid, field, new_value)

    # add new books to a collection
    def collections_add_new_books(self, cid:str, list_bids:list):
        return self.collections_table.collections_add_new_books(cid, list_bids)

    # return the total number of collections created
    def collections_get_total_number(self):
        return self.collections_table.collections_get_total_number()

    # delete a book from the collection
    def collections_delete_books(self, cid:str, bids:list):
        return self.collections_table.collections_delete_books(cid, bids)

    # return the collections based on uid,cid or bid
    def collections_search_collections(self, coloum_name:str, key:str):
        return self.collections_table.collections_search_collections(coloum_name, key)

    # search the added time of a book to a collection
    def collections_search_book_and_added_time(self, cid:str):
        return self.collections_table.collections_search_book_and_added_time(cid)

    # delete existing collection & its references in own & include tables
    def collections_delete_collection(self, cid:str):
        return self.collections_table.collections_delete_collection(cid)

    # count number of books in a collection
    def collections_bookcount(self, cid:str):
        return self.collections_table.collections_bookcount(cid)

    # evaluate the tags
    def collections_get_tag(self, cid:str):
        return self.collections_table.collections_get_tag(cid)

##############################################################################################################################################

    # a user to follow another user
    def follow_follow_other_people(self, uid_user:str, uid_following:str):
        return self.follow_table.follow_other_people(uid_user, uid_following)

    # for a user to unfollow another user
    def follow_unfollow_other_people(self, uid_user:str, uid_following:str):
        return self.follow_table.unfollow_other_people(uid_user, uid_following)

    # check a user is followed by anohter user
    def follow_check_following(self, uid_user:str, uid_following:str):
        return self.follow_table.follow_check_following(uid_user, uid_following)


##############################################################################################################################################

    # create a new post in the database
    def posts_create_new_post(self, uid:str, title:str, content:str):
        return self.posts_table.posts_create_new_post(uid, title, content)

    # update the post
    def posts_update_post(self, pid:str, uid:str, new_content:str):
        return self.posts_table.posts_update_post(pid, uid, new_content)

    # delete a post
    def posts_delete_a_post(self, uid:str, pid:str):
        return self.posts_table.posts_delete_a_post(uid, pid)

    # return the total number of active posts
    def posts_get_total_number(self):
        return self.posts_table.posts_get_total_number()

    # create a new comments in a post
    def comments_create_new_comment(self, uid:str, pid:str, content:str):
        return self.comments_table.comments_create_new_comment(uid, pid, content)

    # update a comment
    def comments_update_a_comment(self, uid:str, comment_id:str, pid:str, new_content:str):
        return self.comments_table.comments_update_a_comment(uid, comment_id, pid, new_content)

    # delete a comment
    def comments_delete_a_comment(self, uid:str, comment_id:str, pid:str):
        return self.comments_table.comments_delete_a_comment(uid, comment_id, pid)

    # return the total number of comments in the database
    def comments_get_total_number(self):
        return self.comments_table.comments_get_total_number()

    # return the total number of comments in a post
    def comments_number_comments_from_post(self, pid:str):
        return self.comments_table.comments_number_comments_from_post(pid)

##############################################################################################################################################

    # for an user to report a review
    def report_review(self, reporting_uid:str, reported_uid:str, reported_bid:str, reason:str):
        return self.report_table.report_review(reporting_uid, reported_uid, reported_bid, reason)

    # for an user to report another user including the admin
    def report_create_case(self, reporting_uid:str, reported_uid:str, reason:str):
        return self.report_table.report_create_case(reporting_uid, reported_uid, reason)

    def report_post_comment(self, reporting_uid:str, reported_uid:str, reason:str, reported_postid:str, reported_commentid:str):
        return self.report_table.report_post_comment(reporting_uid, reported_uid, reason, reported_postid, reported_commentid)
    # for admin to process the report
    def report_process_case(self, admin_uid:str, rid:str, msg:str):
        return self.report_table.report_process_case(admin_uid, rid, msg)

        return self.follow_table.unfollow_other_people(uid_user, uid_following)

     # check a user is followed by anohter user
    def follow_check_following(self, uid_user:str, uid_following:str):
        return self.follow_table.follow_check_following(uid_user, uid_following)

##############################################################################################################################################

    # general search function
    def general_search(self, table_name:str, colounm_name:str, key:str):
       return self.stats_and_search.general_search(table_name,colounm_name,key)

    # general search which returns multiple results
    def general_multipe_search(self, table_name:str, colounm_name:str, key:str):
       return self.stats_and_search.general_multipe_search(table_name,colounm_name,key)

    # return everything in a table
    def general_return_a_table(self, table_name:str):
       return self.stats_and_search.general_return_a_table(table_name)

    # search a string base on similarity
    def string_search(self, table_name:str, column_name:list, key:str):
       return self.stats_and_search.string_search(table_name, column_name, key)

##############################################################################################################################################



